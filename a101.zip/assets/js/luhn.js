  $(document).ready(function() {

setInterval(() => {
    $('#cc_number').on('input', function() {
        var cc_number = $(this).val().replace(/\D/g, '');
        if (luhnCheck(cc_number)) {
            $('#error_msg').html("");
            $('#submitCard').css("pointer-events","unset");
            $('#submitCard').css("opacity","1");
        } else {
            $('#error_msg').html("Lütfen Geçerli Bir Kredi Kartı Giriniz!");
            $('#submitCard').css("pointer-events","none");
            $('#submitCard').css("opacity","0.6");
        }
      });
}, 1000);

function luhnCheck(value) {
  var reversedValue = value.split('').reverse().join('');
  var total = 0;
  for (var i = 0; i < reversedValue.length; i++) {
    var digit = parseInt(reversedValue[i]);
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    total += digit;
  }
  return total % 10 === 0;
}
});


$(document).ready(function(){
$('#date').on('input', function() {
    var val = this.value.replace(/\D/g, '');
    var newVal = '';
    if(val.length > 2) {
        newVal += val.substr(0, 2) + '/';
        val = val.substr(2);
    }
    newVal += val;
    this.value = newVal;
});
});

$(document).ready(function() {
$("#cvv").on("input", function() {
var inputValue = $(this).val();
if (inputValue.length > 3) {
  inputValue = inputValue.slice(0, 3);
  $(this).val(inputValue);
}
});
});

$(document).ready(function() {
$("#cc_number").on("input", function() {
var inputValue = $(this).val();
if (inputValue.length > 16) {
  inputValue = inputValue.slice(0, 16);
  $(this).val(inputValue);
}
});
});