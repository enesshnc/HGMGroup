<!-- saved from url=(0039)https://www.a101.com.tr/baskets/basket/ -->
<html lang="tr" data-gtm-vis-recent-on-screen-10681747_459="800" data-gtm-vis-first-on-screen-10681747_459="800"
  data-gtm-vis-total-visible-time-10681747_459="1000" data-gtm-vis-has-fired-10681747_459="1">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <style type="text/css" id="operaUserStyle"></style>
  <link href="https://cdn.personaclick.com/" rel="dns-prefetch">
  <link href="https://cdn.personaclick.com/" rel="preconnect">
  <link href="<?php echo base_url("assets/a101/")?>v3.js.indir" rel="preload" as="script">
  <script type="text/javascript" charset="UTF-8" async="" src="<?php echo base_url("assets/a101/")?>widgetIcon.min.js.indir"></script>
  <script type="text/javascript" charset="UTF-8" async="" src="<?php echo base_url("assets/a101/")?>state.js.indir"></script>
  <script async="" src="<?php echo base_url("assets/a101/")?>a101.com.tr"></script>
  <script type="text/javascript" async="" src="<?php echo base_url("assets/a101/")?>ec.js.indir"></script>
  <script type="text/javascript" async="" src="<?php echo base_url("assets/a101/")?>ld.js.indir"></script>
  <script type="text/javascript" async="" src="<?php echo base_url("assets/a101/")?>js"></script>
  <script async="" src="<?php echo base_url("assets/a101/")?>fbevents.js.indir"></script>
  <script type="text/javascript" async="" src="<?php echo base_url("assets/a101/")?>events.js.indir"></script>
  <script type="text/javascript" id="pfx_ap" async="" src="<?php echo base_url("assets/a101/")?>dynamic_click_tag.js.indir"></script>
  <script async="" src="<?php echo base_url("assets/a101/")?>tfa.js.indir" id="tb_tfa_script"></script>
  <script type="text/javascript" async="" src="<?php echo base_url("assets/a101/")?>tag.js.indir"></script>
  <script type="text/javascript" async="" src="<?php echo base_url("assets/a101/")?>insight.min.js.indir"></script>
  <script type="text/javascript" async="" src="<?php echo base_url("assets/a101/")?>hotjar-2486789.js.indir"></script>
  <script type="text/javascript" async="" src="<?php echo base_url("assets/a101/")?>analytics.js.indir"></script>
  <script type="text/javascript" id="Cookiebot" src="<?php echo base_url("assets/a101/")?>uc.js.indir"></script>
  <script type="text/javascript" async="" src="<?php echo base_url("assets/a101/")?>gtm.js.indir"></script>
  <script src="<?php echo base_url("assets/a101/")?>v3.js.indir" async=""></script>
  <style type="text/css">
    :root zeus-ad,
    :root topadblock,
    :root span[id^="ezoic-pub-ad-placeholder-"],
    :root guj-ad,
    :root gpt-ad,
    :root div[jsdata*="CarouselPLA-"][data-id^="CarouselPLA-"],
    :root div[id^="zergnet-widget"],
    :root div[id^="yandex_ad"],
    :root div[id^="vuukle-ad-"],
    :root div[id^="sticky_ad_"],
    :root div[id^="rc-widget-"],
    :root div[id^="lazyad-"],
    :root div[id^="gpt_ad_"],
    :root div[id^="ezoic-pub-ad-"],
    :root div[id^="div-gpt-"],
    :root div[id^="dfp-ad-"],
    :root div[id^="advads_ad_"],
    :root div[id^="adspot-"],
    :root div[id^="ads300_250-widget-"],
    :root div[id^="ads300_100-widget-"],
    :root div[id^="ads250_250-widget-"],
    :root div[id^="adrotate_widgets-"],
    :root div[id^="adngin-"],
    :root div[id^="_vdo_ads_player_ai_"],
    :root div[id*="ScriptRoot"],
    :root div[id*="MarketGid"],
    :root div[data-native_ad],
    :root div[data-insertion],
    :root div[data-id-advertdfpconf],
    :root div[data-google-query-id],
    :root hl-adsense,
    :root div[data-contentexchange-widget],
    :root div[data-content="Advertisement"],
    :root div[data-alias="300x250 Ad 2"],
    :root div[data-alias="300x250 Ad 1"],
    :root div[data-adzone],
    :root div[data-adunit-path],
    :root div[data-ad-wrapper],
    :root div[data-ad-targeting],
    :root div[data-ad-placeholder],
    :root div[class^="native-ad-"],
    :root div[data-dfp-id],
    :root div[class^="kiwi-ad-wrapper"],
    :root div[class^="Adstyled__AdWrapper-"],
    :root div[aria-label="Ads"],
    :root display-ads,
    :root display-ad-component,
    :root aside[id^="adrotate_widgets-"],
    :root article.ad,
    :root ark-top-ad,
    :root app-advertisement,
    :root app-ad,
    :root amp-fx-flying-carpet,
    :root amp-embed[type="taboola"],
    :root amp-connatix-player,
    :root amp-ad-custom,
    :root ad-shield-ads,
    :root a[onmousedown^="this.href='https://paid.outbrain.com/network/redir?"][target="_blank"]+.ob_source,
    :root a[onmousedown^="this.href='https://paid.outbrain.com/network/redir?"][target="_blank"],
    :root a[onmousedown^="this.href='http://paid.outbrain.com/network/redir?"][target="_blank"]+.ob_source,
    :root a[href^="https://yogacomplyfuel.com/"],
    :root div[class^="Display_displayAd"],
    :root a[href^="https://www.bang.com/?aff="],
    :root a[href^="https://www.sheetmusicplus.com/?aff_id="],
    :root a[href^="https://bngpt.com/"],
    :root a[href^="https://www.sheetmusicplus.com/"][href*="?aff_id="],
    :root a[href^="https://www.purevpn.com/"][href*="&utm_source=aff-"],
    :root a[href^="https://www.mypornstarcams.com/landing/click/"],
    :root a[href^="https://financeads.net/tc.php?"],
    :root a[href^="https://www.mrskin.com/tour"],
    :root a[href^="https://www.kingsoffetish.com/tour?partner_id="],
    :root a[href^="https://www.infowarsstore.com/"]>img,
    :root a[href^="https://t.grtyi.com/"],
    :root a[href^="https://www.highperformancecpmgate.com/"],
    :root a[href^="https://www.highcpmrevenuenetwork.com/"],
    :root a[href^="https://www.get-express-vpn.com/offer/"],
    :root a[href^="https://www.financeads.net/tc.php?"],
    :root a[href^="https://www.brazzersnetwork.com/landing/"],
    :root a[href^="https://www.adxsrve.com/"],
    :root [data-template-type="nativead"],
    :root a[href^="https://www.adultempire.com/"][href*="?partner_id="],
    :root a[href^="https://webroutetrk.com/"],
    :root a[href^="https://twinrdsyn.com/"],
    :root a[href^="https://tsartech.g2afse.com/"],
    :root [href^="https://www.mypatriotsupply.com/"]>img,
    :root a[href^="https://trk.softonixs.xyz/"],
    :root a[href^="https://trk.nfl-online-streams.club/"],
    :root a[href^="https://tracking.avapartner.com/"],
    :root a[href^="https://track.afcpatrk.com/"],
    :root a[href^="https://track.adform.net/"],
    :root a[href^="https://torguard.net/aff.php"]>img,
    :root div[data-adname],
    :root a[href^="https://thechleads.pro/"],
    :root [data-role="tile-ads-module"],
    :root a[href^="https://adsrv4k.com/"],
    :root a[href^="https://go.xlviirdr.com"],
    :root a[href^="https://thaudray.com/"],
    :root a[href^="https://www.5mno3.com/"],
    :root a[href^="https://taghaugh.com/"],
    :root [href^="https://zstacklife.com/"] img,
    :root a[href^="https://t.aslnk.link/"],
    :root a[href^="https://t.adating.link/"],
    :root a[href^="https://go.trackitalltheway.com/"],
    :root [href^="https://track.fiverr.com/visit/"]>img,
    :root a[href^="https://syndication.exoclick.com/"],
    :root a[href^="https://syndication.dynsrvtbg.com/"],
    :root a[href^="https://streamate.com/landing/click/"],
    :root a[href^="https://ad.doubleclick.net/"],
    :root a[href^="https://static.fleshlight.com/images/banners/"],
    :root a[href^="https://go.strpjmp.com/"],
    :root a[href^="https://refpa4903566.top/"],
    :root a[href^="https://prf.hn/click/"][href*="/camref:"]>img,
    :root a[href^="https://serve.awmdelivery.com/"],
    :root a[href^="https://prf.hn/click/"][href*="/adref:"]>img,
    :root [href^="https://r.kraken.com/"],
    :root a[href^="https://mmwebhandler.aff-online.com/"],
    :root a[href^="https://www.bet365.com/"][href*="affiliate="],
    :root a[href^="https://pb-track.com/"],
    :root a[href^="https://paid.outbrain.com/network/redir?"],
    :root div[id^="ad_position_"],
    :root a[href^="https://ovb.im/"],
    :root div[id^="ad-div-"],
    :root a[href^="https://newbinotracs.com/"],
    :root a[href^="https://natour.naughtyamerica.com/track/"],
    :root [href^="https://stvkr.com/"],
    :root a[href^="https://mediaserver.entainpartners.com/renderBanner.do?"],
    :root [href^="https://www.herbanomic.com/"]>img,
    :root a[href^="https://maymooth-stopic.com/"],
    :root a[href^="https://loboclick.com"],
    :root [href^="https://routewebtk.com/"],
    :root a[href^="https://see.kmisln.com/"],
    :root a[href^="https://a.bestcontentweb.top/"],
    :root a[href^="https://lobimax.com/"],
    :root a[href^="https://lead1.pl/"],
    :root a[href^="https://refpa.top/"],
    :root a[href^="https://landing.brazzersnetwork.com/"],
    :root a[href^="https://ads.leovegas.com/redirect.aspx?"],
    :root a[href^="https://land.brazzersnetwork.com/landing/"],
    :root a[href^="https://juicyads.in/"],
    :root a[href^="https://itubego.com/video-downloader/?affid="],
    :root a[href^="https://iqbroker.com/"][href*="?aff="],
    :root a[href^="https://incisivetrk.cvtr.io/click?"],
    :root [data-revive-zoneid],
    :root a[href^="https://googleads.g.doubleclick.net/pcs/click"],
    :root a[href^="https://clk.wrenchsound.store/"],
    :root a[href^="https://go.zybrdr.com"],
    :root [href^="http://join.michelle-austin.com/"],
    :root a[href^="https://go.xxxiijmp.com"],
    :root a[href^="https://go.xtbaffiliates.com/"],
    :root a[href^="https://ismlks.com/"],
    :root a[href^="//a.bestcontentfare.top/"],
    :root [href^="https://www.mypillow.com/"]>img,
    :root a[href^="https://azpresearch.club/"],
    :root a[href^="https://go.xlirdr.com"],
    :root [data-css-class="dfp-inarticle"],
    :root .card-captioned.crd>.crd--cnt>.s2nPlayer,
    :root a[href^="https://go.tmrjmp.com"],
    :root a[href^="https://go.skinstrip.net"][href*="?campaignId="],
    :root a[href^="https://go.markets.com/visit/?bta="],
    :root a[href^="https://billing.purevpn.com/aff.php"]>img,
    :root a[href^="https://go.hpyrdr.com/"],
    :root a[href^="https://go.goaserv.com/"],
    :root a[href^="https://track.wg-aff.com"],
    :root a[href^="https://go.ebrokerserve.com/"],
    :root a[href^="https://go.dmzjmp.com"],
    :root a[href^="https://twinrdsrv.com/"],
    :root a[href^="https://go.admjmp.com/"],
    :root a[href^="https://www.nutaku.net/signup/landing/"],
    :root [href^="https://kingered-banctours.com/"],
    :root a[href^="https://get.surfshark.net/aff_c?"][href*="&aff_id="]>img,
    :root a-ad,
    :root a[href^="https://affiliate.rusvpn.com/click.php?"],
    :root a[href^="https://geniusdexchange.com/"],
    :root a[href^="https://frameworkdeserve.com/"],
    :root a[href^="https://flirtandsweets.life/"],
    :root a[href^="https://www.mrskin.com/account/"],
    :root bottomadblock,
    :root a[href^="https://fertilitycommand.com/"],
    :root [data-freestar-ad],
    :root a[href^="https://fc.lc/ref/"],
    :root div[data-native-ad],
    :root a[href^="https://engine.trackingdesks.com/"],
    :root [href^="https://totlnkcl.com/"],
    :root a[href^="https://www.adskeeper.com"],
    :root a[data-redirect^="https://paid.outbrain.com/network/redir?"],
    :root [href^="https://www.reimageplus.com/"],
    :root a[href^="https://engine.phn.doublepimp.com/"],
    :root a[href^="https://engine.blueistheneworanges.com/"],
    :root a[href^="https://wantopticalfreelance.com/"],
    :root a[href^="https://dl-protect.net/"],
    :root a[href^="https://clixtrac.com/"],
    :root a[href^="https://mediaserver.gvcaffiliates.com/renderBanner.do?"],
    :root a[href^="https://join.dreamsexworld.com/"],
    :root a[href^="https://click.linksynergy.com/fs-bin/"],
    :root AD-TRIPLE-BOX,
    :root a[href^="https://click.hoolig.app/"],
    :root a[href^="https://track.totalav.com/"],
    :root img[src^="https://images.purevpnaffiliates.com"],
    :root a[href^="https://porntubemate.com/"],
    :root a[href^="http://www.gfrevenge.com/landing/"],
    :root a[href^="https://clickadilla.com/"],
    :root a[href^="https://click.dtiserv2.com/"],
    :root a[href^="https://go.xlvirdr.com"],
    :root a[href^="https://claring-loccelkin.com/"],
    :root [class^="s2nPlayer"],
    :root a[href^="https://chaturbate.jjgirls.com/?track="],
    :root a[href^="https://www.nudeidols.com/cams/"],
    :root a[href^="https://chaturbate.com/in/?track="],
    :root a[href^="https://www.onlineusershielder.com/"],
    :root a[href^="https://chaturbate.com/in/?tour="],
    :root a[href^="https://cams.imagetwist.com/in/?track="],
    :root a[href^="https://cam4com.go2cloud.org/"],
    :root a[href^="https://bongacams2.com/track?"],
    :root a[href^="https://bluedelivery.pro/"],
    :root #topstuff>#tads,
    :root a[href^="https://black77854.com/"],
    :root a[href^="https://ndt5.net/"],
    :root a[href^="https://batheunits.com/"],
    :root a[target="_blank"][onmousedown="this.href^='http://paid.outbrain.com/network/redir?"],
    :root a[href^="https://banners.livepartners.com/"],
    :root a[href^="https://adultfriendfinder.com/go/page/landing"],
    :root a[href^="https://www.sugarinstant.com/?partner_id="],
    :root a[href^="https://m.do.co/c/"]>img,
    :root [href="https://masstortfinancing.com"] img,
    :root a[href^="https://bongacams10.com/track?"],
    :root a[href^="https://albionsoftwares.com/"],
    :root a[href^="https://t.hrtye.com/"],
    :root a[href^="https://go.etoro.com/"]>img,
    :root a[href^="https://join.sexworld3d.com/track/"],
    :root a[href^="https://intenseaffiliates.com/redirect/"],
    :root a[href^="https://aweptjmp.com/"],
    :root a[href^="https://ads.ad4game.com/"],
    :root [id^="google_ads_iframe"],
    :root a[href^="https://syndication.optimizesrv.com/"],
    :root a[href^="https://affpa.top/"],
    :root a[href^="https://adnetwrk.com/"],
    :root a[href^="https://adjoincomprise.com/"],
    :root [href^="http://misslinkvocation.com/"],
    :root a[href^="https://adclick.g.doubleclick.net/"],
    :root a[href^="https://adswick.com/"],
    :root a[href^="https://a.bestcontentoperation.top/"],
    :root [data-m-ad-id],
    :root a[href^="https://a-ads.com/"],
    :root [href="https://ourgoldguy.com/contact/"] img,
    :root a[href^="https://brightadnetwork.com/"],
    :root [href^="https://www.avantlink.com/click.php"] img,
    :root a[href^="http://www.onwebcam.com/random?t_link="],
    :root a[href^="https://awentw.com/"],
    :root a[href^="https://www.googleadservices.com/pagead/aclk?"],
    :root a[href^="http://www.mrskin.com/tour"],
    :root a[href^="https://agacelebir.com/"],
    :root a[href^="https://spygasm.com/track?"],
    :root a[href^="http://d2.zedo.com/"],
    :root a[href^="http://www.friendlyduck.com/AF_"],
    :root a[href^="https://ad.kubiccomps.icu/"],
    :root a[href^="http://trk.globwo.online/"],
    :root a[href^="https://prf.hn/click/"][href*="/creativeref:"]>img,
    :root a[href^="http://www.adultempire.com/unlimited/promo?"][href*="&partner_id="],
    :root a[href^="http://traffic.tc-clicks.com/"],
    :root a[href^="http://tour.mrskin.com/"],
    :root a[href^="https://join.virtualtaboo.com/track/"],
    :root a[href^="https://funkydaters.com/"],
    :root [id^="ad_sky"],
    :root a[href^="http://https://www.get-express-vpn.com/offer/"],
    :root div[id^="google_dfp_"],
    :root a[href^="http://googleads.g.doubleclick.net/pcs/click"],
    :root .rc-cta[data-target],
    :root [href^="http://go.cm-trk2.com/"],
    :root a[href^="http://click.payserve.com/"],
    :root a[href^="https://porngames.adult/?SID="],
    :root [href^="http://clicks.totemcash.com/"],
    :root a[href^="https://ad.zanox.com/ppc/"]>img,
    :root a[href^="https://misspkl.com/"],
    :root a[href^="https://landing1.brazzersnetwork.com"],
    :root #slashboxes>.deals-rail,
    :root [href^="http://globsads.com/"],
    :root [href^="https://www.brighteonstore.com/products/"] img,
    :root a[href^="http://bc.vc/?r="],
    :root a[href^="https://mityneedn.com/"],
    :root [href^="http://homemoviestube.com/"],
    :root a[href^="http://ad.doubleclick.net/"],
    :root a[href^="https://a2.adform.net/"],
    :root a[href^="http://static.fleshlight.com/images/banners/"],
    :root a[href^="https://a.adtng.com/"],
    :root a[href^="//pubads.g.doubleclick.net/"],
    :root a[href^="https://go.nordvpn.net/aff"]>img,
    :root [data-d-ad-id],
    :root a[href*=".engine.adglare.net/"],
    :root [data-dynamic-ads],
    :root a[data-widget-outbrain-redirect^="http://paid.outbrain.com/network/redir?"],
    :root [data-ad-width],
    :root [href^="https://join.playboyplus.com/track/"],
    :root a[data-url^="http://paid.outbrain.com/network/redir?"]+.author,
    :root a[href^="https://axdsz.pro/"],
    :root a[href^="http://bodelen.com/"],
    :root a[data-oburl^="https://paid.outbrain.com/network/redir?"],
    :root [href^="https://cpa.10kfreesilver.com/"],
    :root a[href^="https://a.bestcontentfood.top/"],
    :root a[href^="https://reinstandpointdumbest.com/"],
    :root a[data-obtrack^="http://paid.outbrain.com/network/redir?"],
    :root a[href^="http://wct.link/"],
    :root [href^="https://goldforyourfuture.com/clk.trk"] img,
    :root [href^="https://infinitytrk.com/"],
    :root [onclick^="location.href='http://www.reimageplus.com"],
    :root .commercial-unit-mobile-top .jackpot-main-content-container>.UpgKEd+.nZZLFc>.vci,
    :root [id^="section-ad-banner"],
    :root .commercial-unit-mobile-top>div[data-pla="1"],
    :root a[href^="https://go.julrdr.com/"],
    :root .trc_rbox_div .syndicatedItemUB,
    :root [href^="https://zone.gotrackier.com/"],
    :root [href^="https://www.targetingpartner.com/"],
    :root [href^="https://detachedbates.com/"],
    :root a[href^="https://fourwhenstatistics.com/"],
    :root [href^="https://www.restoro.com/"],
    :root a[href^="https://fastestvpn.com/lifetime-special-deal?a_aid="],
    :root a[href^="https://tour.mrskin.com/"],
    :root div[id^="ad-position-"],
    :root a[href^="http://adultfriendfinder.com/go/page/landing"],
    :root a[href^="http://affiliate.glbtracker.com/"],
    :root a[href^="https://leg.xyz/?track="],
    :root div[id^="crt-"][style],
    :root a[href^="http://adultgames.xxx/"],
    :root a[href^="https://traffic.bannerator.com/"],
    :root [href^="https://shiftnetwork.infusionsoft.com/go/"]>img,
    :root a[onmousedown^="this.href='http://paid.outbrain.com/network/redir?"][target="_blank"],
    :root [href^="https://secure.bmtmicro.com/servlets/"],
    :root a[href^="https://losingoldfry.com/"],
    :root .scroll-fixable.rail-right>.deals-rail,
    :root a[href^="https://oackoubs.com/"],
    :root a[href^="https://awptjmp.com/"],
    :root a[href^="https://go.goasrv.com/"],
    :root .commercial-unit-mobile-top>.v7hl4d,
    :root [href^="http://mypillow.com/"]>img,
    :root a[href^="http://bongacams.com/track?"],
    :root a[href^="https://fleshlight.sjv.io/"],
    :root [data-ad-manager-id],
    :root a[href^="https://promo-bc.com/"],
    :root a[href^="https://clicks.pipaffiliates.com/"],
    :root [href^="https://noqreport.com/"]>img,
    :root a[href^="https://go.hpyjmp.com"],
    :root ADS-RIGHT,
    :root [href^="https://mystore.com/"]>img,
    :root [href^="https://mypatriotsupply.com/"]>img,
    :root [href^="https://mylead.global/stl/"]>img,
    :root #leader-companion>a[href],
    :root a[href^="https://transfer.xe.com/signup/track/redirect?"],
    :root .vid-present>.van_vid_carousel__padding,
    :root a[href^="https://go.xxxijmp.com"],
    :root [href^="https://istlnkcl.com/"],
    :root [href^="https://www.hostg.xyz/"]>img,
    :root .section-subheader>.section-hotel-prices-header,
    :root [href^="https://go.affiliatexe.com/"],
    :root [href^="https://go.4rabettraff.com/"],
    :root a[href^="https://tm-offers.gamingadult.com/"],
    :root [href^="https://charmingdatings.life/"],
    :root [href^="https://glersakr.com/"],
    :root ins.adsbygoogle,
    :root a[href^="https://1startfiledownload1.com/"],
    :root .trc_rbox_border_elm .syndicatedItem,
    :root a[href^="http://www.onclickmega.com/jump/next.php?"],
    :root a[href^="http://adf.ly/?id="],
    :root a[href^="https://wittered-mainging.com/"],
    :root [href^="https://engine.gettopple.com/"],
    :root a[href^="https://go.gldrdr.com/"],
    :root [data-id^="div-gpt-ad"],
    :root [href^="https://awbbjmp.com/"],
    :root a[href^="https://k2s.cc/pr/"],
    :root [href^="https://affect3dnetwork.com/track/"],
    :root a[href^="https://camfapr.com/landing/click/"],
    :root [href="//sexcams.plus/"],
    :root a[href^="https://go.currency.com/"],
    :root [href^="http://www.mypillow.com/"]>img,
    :root div[id^="div-ads-"],
    :root [href^="https://rapidgator.net/article/premium/ref/"],
    :root [href^="https://join3.bannedsextapes.com"],
    :root div[data-spotim-slot],
    :root [href^="https://antiagingbed.com/discount/"]>img,
    :root a[href^="https://go.247traffic.com/"],
    :root [href^="https://join.girlsoutwest.com/"],
    :root [href^="http://trafficare.net/"],
    :root a[href^="https://tc.tradetracker.net/"]>img,
    :root a[href^="https://adserver.adreactor.com/"],
    :root [href^="http://join.shemalesfromhell.com/"],
    :root [id^="ad_slider"],
    :root a[href^="http://www.adultdvdempire.com/?partner_id="][href*="&utm_"],
    :root [href^="http://join.shemale.xxx/"],
    :root [href^="https://ilovemyfreedoms.com/landing-"],
    :root a[href^="https://ads.betfair.com/redirect.aspx?"],
    :root [href^="http://www.fleshlightgirls.com/"],
    :root [href^="http://join.trannies-fuck.com/"],
    :root .trc_rbox .syndicatedItem,
    :root a[href^="http://cam4com.go2cloud.org/aff_c?"],
    :root a[href^="https://cpmspace.com/"],
    :root [href^="https://freecourseweb.com/"]>.sitefriend,
    :root a[href^="https://thefacux.com/"],
    :root a[href^="https://ads.planetwin365affiliate.com/redirect.aspx?"],
    :root [href^="http://join.rodneymoore.com/"],
    :root a[href^="https://www.privateinternetaccess.com/"]>img,
    :root a[href*=".trust.zone"],
    :root [href^="https://shrugartisticelder.com"],
    :root [href^="https://go.xlrdr.com"],
    :root [name^="google_ads_iframe"],
    :root a[href^="https://go.xxxjmp.com"],
    :root [data-desktop-ad-id],
    :root [href^="https://wct.link/"],
    :root div[recirculation-ad-container],
    :root [href^="https://traffserve.com/"],
    :root #kt_player>a[target="_blank"],
    :root [href="https://www.masstortfinancing.com/"]>img,
    :root .ob_container .item-container-obpd,
    :root [id^="div-gpt-ad"],
    :root [href^="https://mypillow.com/"]>img,
    :root [href^="https://ad.admitad.com/"],
    :root a[href^="https://u.expresstech.io/"],
    :root [href="https://jdrucker.com/gold"]>img,
    :root [href^="https://v.investologic.co.uk/"],
    :root [href^="https://cipledecline.buzz/"],
    :root a[href^="https://track.ultravpn.com/"],
    :root [href^="https://goldcometals.com/clk.trk"],
    :root [href^="https://fancentro.com/"],
    :root [data-mobile-ad-id],
    :root a[href^="http://tc.tradetracker.net/"]>img,
    :root a[href^="https://www.geekbuying.com/dynamic-ads/"],
    :root a[href^="http://affiliates.thrixxx.com/"],
    :root #searchResultsList>div>div[onclick$="'inline.ad'});"],
    :root a[href^="https://trk.sportsflix4k.club/"],
    :root a[href^="https://go.xlivrdr.com"],
    :root [data-ez-name],
    :root [onclick*="content.ad/"],
    :root AMP-AD,
    :root [data-ad-cls],
    :root a[href^="https://www.goldenfrog.com/vyprvpn?offer_id="][href*="&aff_id="],
    :root [id^="ad-wrap-"],
    :root div[id^="taboola-stream-"],
    :root [href^="https://go.astutelinks.com/"],
    :root [class^="amp-ad-"],
    :root [href^="https://affiliate.fastcomet.com/"]>img,
    :root [class^="adDisplay-module"],
    :root a[href^="http://go.xtbaffiliates.com/"],
    :root .grid>.container>#aside-promotion,
    :root DFP-AD,
    :root AD-SLOT,
    :root .ob_dual_right>.ob_ads_header~.odb_div,
    :root [href^="https://click2cvs.com/"],
    :root .trc_related_container div[data-item-syndicated="true"],
    :root [href^="http://join.shemalepornstar.com/"],
    :root a[href^="https://go.xlviiirdr.com"],
    :root .trc_rbox_div .syndicatedItem,
    :root div[data-adunit],
    :root app-large-ad,
    :root [href^="https://turtlebids.irauctions.com/"] img,
    :root a[href^="https://iactrivago.ampxdirect.com/"],
    :root a[href^="https://a.medfoodhome.com/"],
    :root [data-ad-module],
    :root a[href^="https://go.cmtaffiliates.com/"],
    :root [data-name="adaptiveConstructorAd"],
    :root [href^="https://optimizedelite.com/"]>img,
    :root [href^="https://trackfin.asia/"],
    :root .plistaList>.plista_widget_underArticle_item[data-type="pet"],
    :root a[href*="//lkstrck2.com/"],
    :root .plistaList>.itemLinkPET,
    :root [href^="https://safer-redirection.com"],
    :root atf-ad-slot,
    :root .commercial-unit-mobile-top .jackpot-main-content-container>.UpgKEd+.nZZLFc>div>.vci,
    :root a[href^="http://partners.etoro.com/"],
    :root [data-advadstrackid],
    :root #atvcap+#tvcap>.mnr-c>.commercial-unit-mobile-top,
    :root a[href^="https://traffdaq.com/"],
    :root [class^="div-gpt-ad"],
    :root a[href^="https://bs.serving-sys.com"],
    :root [href^="http://residenceseeingstanding.com/"],
    :root [href^="https://www.cloudways.com/en/?id"],
    :root a[href^="https://refpazkjixes.top/"],
    :root #mgb-container>#mgb,
    :root a[href^="https://join.virtuallust3d.com/"],
    :root #taw>.med+div>#tvcap>.mnr-c:not(.qs-ic)>.commercial-unit-mobile-top,
    :root [data-adblockkey] {
      display: none !important;
    }
  </style>
  <meta http-equiv="origin-trial"
    content="A727AcAeLCei/ZogJHBlJUS63SxP6AeIROo7qXrkjrxkoxBu0eSSmypAHmGYwk4HjBMQp5nxCFODzfVnUIe31AQAAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjg4MDgzMTk5LCJpc1RoaXJkUGFydHkiOnRydWV9">
  <meta http-equiv="origin-trial"
    content="A727AcAeLCei/ZogJHBlJUS63SxP6AeIROo7qXrkjrxkoxBu0eSSmypAHmGYwk4HjBMQp5nxCFODzfVnUIe31AQAAAB7eyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjg4MDgzMTk5LCJpc1RoaXJkUGFydHkiOnRydWV9">
  <script type="text/javascript" async="" src="<?php echo base_url("assets/a101/")?>f.txt"></script>
  <style type="text/css" id="CookieConsentStateDisplayStyles">
    .cookieconsent-optin,
    .cookieconsent-optin-preferences,
    .cookieconsent-optin-statistics,
    .cookieconsent-optin-marketing {
      display: block;
      display: initial;
    }

    .cookieconsent-optout-preferences,
    .cookieconsent-optout-statistics,
    .cookieconsent-optout-marketing,
    .cookieconsent-optout {
      display: none;
    }
  </style>
</head>

<body class="page-inner">
  <div class="added-to-basket js-basket-dropdown js-header-basket-box clearfix" id="js-modal-basket">
    <div class="message">
      <i class="icon-check"></i>
      <span class="text">
        <span class="js-basket-modal-quantity"></span> adet ürün eklediniz <br class="visible-xs">
        (Toplam <span class="js-basket-quantity">1</span> ürün)
      </span>
    </div>
    <div class="left-side">
      <div class="product-line js-added-product-item"></div>
      <script type="text/javascript" async="" src="<?php echo base_url("assets/a101/")?>recaptcha__tr.js.indir"
        crossorigin="anonymous"
        integrity="sha384-VOs5t7/ULiMnyyvshlxA8BS9VCyPkxjsMSGeoMbx7JQn3cTX63gCD4iN0ZBdcjwq"></script>
      <script id="productDetailModalAddedItem" type="text/x-ejs-template">
      <% if (product) { %>
        <div class="column">
          <img loading="lazy"
              src="<%= product.productimage_set[0].image.substr(0, product.productimage_set[0].image.match('\.[^.]*$').index)+'_size120x120_cropCenter'+ product.productimage_set[0].image.match('\.[^.]*$')[0]%>"
            alt="<%= product.name %>"
          />
        </div>
        <div class="column">
          <a href="<%= product.absolute_url %>" class="name" title="<%= product.name %>"><%= product.name %></a>
          <div class="sku"> Ürün kodu: <%= product.sku %></div>
            <div class="prices">
              <% if (product.retail_price != product.price) { %>
                <span class="old">₺<%= new Intl.NumberFormat('tr-tr', { minimumFractionDigits: 2 }).format(Number(product.retail_price)) %></span>
              <% } %>
              <span class="current">₺<%= new Intl.NumberFormat('tr-tr', { minimumFractionDigits: 2 }).format(Number(product.price)) %></span>
            </div>
        </div>
      <% } %>
    </script>

      <div id="js-hidden-if-kurban">






        <script class="analytics-data" type="text/json">
  {
    "widget_items": {
      "type": "Choosen Products",
      "data": {
        "cartId": "",
        "products": [

        ]
      }
    }
  }
</script>





      </div>
    </div>
    <div class="right-side">
      <div class="summary">
        <table>
          <tbody>
            <tr>
              <td>Ürünlerin Toplamı</td>
            </tr>
          </tbody>
        </table>
        <table class="js-header-basket-discounts">
        </table>
        <table>
          <tbody>
            <tr class="total">
              <td>Toplam</td>
            </tr>
          </tbody>
        </table>
      </div>
      <a href="https://www.a101.com.tr/baskets/basket/" class="button white cblack block" title="Sepeti Görüntüle"
        rel="nofollow">Sepeti Görüntüle</a>
      <hr class="clearfix">
      <a href="https://www.a101.com.tr/orders/checkout/" class="button green block" title="Sepeti Onayla"
        rel="nofollow">Sepeti Onayla</a>
      <a href="https://www.a101.com.tr/baskets/basket/#" class="go-to-shop" onclick="$.magnificPopup.close()"
        title="Alışverişe devam et">Alışverişe devam et</a>
    </div>
  </div>
  <div class="check-phone-popup js-check-phone-number hidden">
    <div class="popup-content">
      <a href="https://www.a101.com.tr/baskets/basket/#" class="close js-close">
        <em class="icon-close"></em>
      </a>
      <div class="desc">
        Sistemimizde cep telefon numaranız kayıtlı değildir. Sizlere daha iyi hizmet verebilmemiz için <b>Hesabım</b>
        sayfasından cep telefon numaranızı kaydedebilirsiniz.
      </div>
    </div>
  </div>



  <meta http-equiv="X-UA-Compatible" content="IE-EmulateIE7">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="facebook-domain-verification" content="mnorx7zxd5dkdp5zy6a0eo80v3qrf9">
  <meta id="viewport" name="viewport" content="width=1200">








  <title>Sepetim - A101</title>
  <meta name="description"
    content="8000&#39;den fazla mağazası ve binlerce ürün seçeneği ile a101, alışveriş sepetinizde büyük avantajları sizlerle buluşturuyor!">



  <link rel="canonical" href="https://www.a101.com.tr/baskets/basket/">






  <meta name="robots" content="noindex">




  <link href="<?php echo base_url("assets/a101/")?>style.css" rel="stylesheet" type="text/css">
  <link href="https://ayb.akinoncdn.com/static_omnishop/ayb835/assets/img/favicon.ico" rel="shortcut icon">

  <script type="text/javascript">
    var GLOBALS = {
      csrf_token: "<input type='hidden' name='csrfmiddlewaretoken' value='S4gob2jJXkSyVZuoVhjKfEhw0RruE5DNUhhPoosiencMNegI2DtLGmV8AcAtDM0C' />",
      analyticsContainers: { "containerId": "GTM-WGSGG57" },
      THUMBNAIL_ACTIVE: true,
      THUMBNAIL_OPTIONS: { "product-list__big": { "width": 587, "quality": 60, "crop": "center", "height": 587 }, "category-detail": { "width": 870, "quality": 60, "height": 317 }, "email-thumbnail": { "width": 80, "quality": 60, "crop": "center", "height": 80 }, "product_basket_thumb_image": { "width": 120, "quality": 60, "height": 120 }, "discount-product-list": { "width": 190, "quality": 100, "crop": "center", "height": 190 }, "product-content-variant-image": { "width": 70, "quality": 60, "crop": "center", "height": 70 }, "product-detail__slider_display": { "width": 780, "quality": 60, "crop": "center", "height": 780 }, "product-detail__slider_zoom": { "width": 1400, "quality": 60, "crop": "center", "height": 1400 }, "product-detail__slider_thumbnail": { "width": 150, "quality": 60, "crop": "center", "height": 150 }, "category-detail__sub-category-banner": { "width": 270, "quality": 60, "height": 335 }, "autocomplete": { "width": 40, "quality": 60, "height": 40 }, "category-detail__campaign-banner": { "width": 420, "quality": 60, "height": 210 }, "product-map-image": { "width": 60, "quality": 60, "crop": "center", "height": 60 }, "product-list": { "width": 250, "quality": 100, "crop": "center", "height": 250 } },
      DEFAULT_COUNTRY: { 'pk': 1 },
      isUserLoggin: false,
      userPhone: '',
      sendTime: '',
      phoneLogin: '',
      isAutoSetShippingOption: false,
      isPaymentTabRunningFromSlug: true,
      disableAutoSelectOneAddress: true,
      userEmail: '',
      userName: '',
      userSurname: '',

      page: 'basket',

    };
  </script>
  <script src="<?php echo base_url("assets/a101/")?>api.js.indir"></script>
  <link rel="preconnect" href="https://cdn-ayb.akinon.net/">
  <link rel="preconnect" href="https://www.google.com/">
  <link rel="preconnect" href="https://ag.gbc.criteo.com/">
  <link rel="preconnect" href="https://www.google-analytics.com/">
  <link rel="preconnect" href="https://www.google.com.tr/">
  <link rel="preconnect" href="https://stats.g.doubleclick.net/">
  <link rel="preload" href="https://ayb.akinoncdn.com/static_omnishop/ayb835/dist/panton-regular-webfont.woff2"
    as="font" type="font/woff2" crossorigin="">
  <link rel="preload" href="https://ayb.akinoncdn.com/static_omnishop/ayb835/dist/panton-bold-webfont.woff2" as="font"
    type="font/woff2" crossorigin="">
  <link rel="preload" href="https://ayb.akinoncdn.com/static_omnishop/ayb835/dist/a101_tradegothic-bold-webfont.woff2"
    as="font" type="font/woff2" crossorigin="">
  <link rel="preload" href="https://ayb.akinoncdn.com/static_omnishop/ayb835/dist/a101_tradegothic-bold-webfont.woff2"
    as="font" type="font/woff2" crossorigin="">
  <link rel="preload" href="https://ayb.akinoncdn.com/static_omnishop/ayb835/dist/panton-extrabold-webfont.woff2"
    as="font" type="font/woff2" crossorigin="">
  <link rel="preload" href="https://ayb.akinoncdn.com/static_omnishop/ayb835/dist/panton-blackcaps-webfont.woff2"
    as="font" type="font/woff2" crossorigin="">
  <link rel="preload" href="https://ayb.akinoncdn.com/static_omnishop/ayb835/dist/icomoon.ttf" as="font" type="font/ttf"
    crossorigin="">

  <script src="<?php echo base_url("assets/a101/")?>cookie-seal.js.indir"></script>


  <script>
    (function () {
      window.personaclick = window.personaclick || function () {
        (window.personaclick.q = window.personaclick.q || []).push(arguments)
      };
      var c = "//cdn.personaclick.com",
        v = "/v3.js",
        s = {
          link: [{
            href: c,
            rel: "dns-prefetch"
          }, {
            href: c,
            rel: "preconnect"
          }, {
            href: c + v,
            rel: "preload",
            as: "script"
          }],
          script: [{
            src: c + v,
            async: ""
          }]
        };
      Object.keys(s).forEach(function (c) {
        s[c].forEach(function (d) {
          var e = document.createElement(c),
            a;
          for (a in d) e.setAttribute(a, d[a]);
          document.head.appendChild(e)
        })
      });
    })();
    personaclick("init", "c8b6a5946225d5fbdc1570119c3aab");

  </script>


  <script class="analytics-data" type="text/json">
    {
        "user": {
          "type": "identify",
          "data": {
            "id":"None",
            "user":{
              "name": " ",
              "email": "d41d8cd98f00b204e9800998ecf8427e",
              "signupDate": "",
              "permission": "no",
              "smsPermission": "no"
            }
          }
        },
        "page": {
          "type": "page Viewed",
          "data": ""
        }
      }
    </script>

  <section class="js-main-wrapper">




    <header class="page-header js-header-container hide-on-app">




      <div class="mobile-app-banner-wrapper js-mobile-app-detect hidden">
        <div class="js-close-btn app-close-btn">
          <i class="icon-close"></i>
        </div>
        <div class="app-info-banner">
          <div class="baner-logo">
            <img loading="lazy" src="<?php echo base_url("assets/a101/")?>8eb6fcd1-45a2-454d-9f97-a6894082cb79.png" alt="A101">
          </div>
          <div class="banner-text">
            <span class="description">Daha iyi bir deneyim için</span>
            <span class="title">A101</span>
            <img loading="lazy" src="<?php echo base_url("assets/a101/")?>6a3a95a3-65f9-4ec1-a253-814ae27b2bcb.png" alt="A101">
          </div>
        </div>
        <div class="app-store-link">
          <a class="cart-cta button green js-ios hidden"
            href="https://itunes.apple.com/tr/app/a101/id1131194413?l=tr&amp;mt=8" title="Uygulamada Aç">
            Uygulamada Aç
          </a>
          <a class="cart-cta button green js-android hidden"
            href="https://play.google.com/store/apps/details?id=org.studionord.a101&amp;hl=tr" title="Uygulamada Aç">
            Uygulamada Aç
          </a>
        </div>
      </div>

      <div class="header-desktop container hidden-xs">
        <div class="header-body">
          <div class="header-logo">
            <a href="https://www.a101.com.tr/" class="logo" title="A101">
              <img loading="lazy" src="<?php echo base_url("assets/a101/")?>3bc03305-83be-4f0b-a9ed-8201d6fd5594.png" alt=""
                width="100" height="90">
            </a>
          </div>
          <div class="header-main">
            <div>
              <div class="header-top">
                <div class="row">
                  <div class="col-md-5 col-sm-4 col-xs-12">
                    <div class="call-us">








                      <div>
                        ₺250 ve üzeri siparişinize ücretsiz kargo!
                      </div>



                    </div>
                  </div>
                  <div class="col-md-7 col-sm-8">
                    <div class="menu">
                      <ul>
                        <li class="campaigns-button dropdown-button js-dropdown-button">
                          <a href="https://www.a101.com.tr/baskets/basket/#" title="Kampanyalar">
                            Kampanyalar
                            <svg width="11" height="6" viewBox="0 0 11 6" fill="none"
                              xmlns="http://www.w3.org/2000/svg">
                              <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M10.2084 1.1591L5.88734 5.48011C5.62218 5.74527 5.19227 5.74527 4.92711 5.48011L0.606096 1.1591C0.340937 0.893937 0.340937 0.464029 0.606096 0.19887C0.871255 -0.0662897 1.30116 -0.0662897 1.56632 0.19887L5.40723 4.03977L9.24813 0.198869C9.51329 -0.0662898 9.9432 -0.0662898 10.2084 0.198869C10.4735 0.464029 10.4735 0.893936 10.2084 1.1591Z"
                                fill="currentColor"></path>
                            </svg>
                          </a>








                          <ul class="header-campaigns">

                            <li>
                              <a href="https://www.a101.com.tr/aldin-aldin/">
                                <img src="<?php echo base_url("assets/a101/")?>d3eb7bf2-32d8-4b57-93f8-f0fc8eb7e93c.png" alt="">
                              </a>
                            </li>

                            <li>
                              <a href="https://www.a101.com.tr/haftanin-yildizlari/">
                                <img src="<?php echo base_url("assets/a101/")?>395f2ffa-5fde-4757-b255-8fe1abffbc06.jpg" alt="">
                              </a>
                            </li>

                            <li>
                              <a href="https://www.a101.com.tr/cok-al-az-ode/">
                                <img src="<?php echo base_url("assets/a101/")?>ff9d7ff1-8a49-40a4-a478-59f3344c11f7.jpg" alt="">
                              </a>
                            </li>

                            <li>
                              <a href="https://www.a101.com.tr/kampanyalar">
                                <img src="<?php echo base_url("assets/a101/")?>b357c626-a509-4ee6-9bec-6771b598cc04.png" alt="">
                              </a>
                            </li>

                          </ul>



                        </li>
                        <li>
                          <a href="https://www.a101.com.tr/hakkimizda" title="Hakkımızda">
                            Hakkımızda
                          </a>
                        </li>
                        <li>
                          <a href="https://www.a101.com.tr/kariyer" title="Kariyer" rel="nofollow">
                            Kariyer
                          </a>
                        </li>
                        <li>
                          <a href="https://www.a101.com.tr/kiralik-yeriniz-mi-var" title="Kiralık Yeriniz mi Var?"
                            rel="nofollow">
                            Kiralık Yeriniz mi Var?
                          </a>
                        </li>
                        <li>
                          <a href="https://www.a101.com.tr/bize-ulasin" title="Bize Ulaşın">
                            Bize Ulaşın
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div class="header">
                <div class="search-area js-search-area tooltip">
                  <form class="js-search-form" method="get" action="https://www.a101.com.tr/list/">
                    <input type="text" name="search_text"
                      class="js-search-input js-search-autocomplete personaclick-instant-search ui-autocomplete-input"
                      placeholder="Ürün, kategori veya marka arayın..." value="" autocomplete="off">
                    <button type="submit">
                      <em class="input-icon icon-search"></em>
                    </button>

                    <div class="search-autocomplete js-autocomplete">
                      <div class="content">
                        <a href="https://www.a101.com.tr/baskets/basket/#" class="close js-autocomplete-close"
                          title="Kapat">
                          <em class="icon-close"></em>
                        </a>
                        <div class="list">
                          <div class="title">Kategoriler</div>
                          <ul class="js-autocomplete-categories">
                          </ul>
                        </div>
                        <div class="products">
                          <div class="title">Ürünler</div>
                          <ul class="js-autocomplete-products">
                          </ul>
                          <div class="clear"></div>
                        </div>
                        <div class="see-all">
                          <a href="https://www.a101.com.tr/baskets/basket/#" class="js-see-all" title="Tüm Ürünler">
                            Tüm <span></span> Ürünleri
                            <em class="icon-chevron_right"></em>
                          </a>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>

                <div class="menu">
                  <ul>
                    <li>
                      <a href="https://www.a101.com.tr/online-alisveris" title="Online Alışveriş">
                        <svg width="26" height="33" viewBox="0 0 26 33" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M16.4434 6.99619H17.6964C19.5222 6.99826 21.0017 8.47789 21.0037 10.3037V12H19.0735L19.0735 10.3035C19.0727 9.54338 18.4567 8.9274 17.6966 8.92653H3.30732C2.54719 8.92751 1.93127 9.54355 1.93034 10.3037V21.4342C1.93266 23.4436 3.21175 25.1537 5 25.797V27.8105C2.1317 27.106 0.00349073 24.519 0 21.4341V10.3037C0.00196868 8.47789 1.48154 6.99826 3.30732 6.99619H4.62229V5.91166V5.90948C4.62289 2.64514 7.26961 -0.000601065 10.534 1.02428e-07C13.7983 0.000602015 16.444 2.64738 16.4434 5.91166V6.99619ZM10.5309 1.92952C8.33275 1.93056 6.55159 3.71342 6.55263 5.91166V6.99619H14.5131V5.91166V5.90784C14.512 3.70964 12.7292 1.92848 10.5309 1.92952Z"
                            fill="#59617C"></path>
                          <path
                            d="M16 33C15.9675 33 15.9345 32.9977 15.9013 32.9928C15.6462 32.9545 15.4355 32.7722 15.3613 32.5247L11.3613 19.1913C11.291 18.9567 11.3552 18.702 11.5287 18.5285C11.7025 18.355 11.9587 18.2905 12.1915 18.3612L25.5248 22.3612C25.7722 22.4353 25.9545 22.646 25.993 22.9012C26.0312 23.1567 25.9182 23.4113 25.7033 23.5545L22.3802 25.77L25.805 29.1952C26.0655 29.4557 26.0655 29.8775 25.805 30.1378L23.1383 32.8045C22.8778 33.065 22.456 33.065 22.1957 32.8045L18.7705 29.3797L16.555 32.7028C16.43 32.8903 16.2207 33 16 33V33ZM18.6667 27.6667C18.8428 27.6667 19.0123 27.7363 19.138 27.862L22.6667 31.3907L24.3905 29.6667L20.862 26.138C20.7207 25.9967 20.6503 25.7998 20.67 25.6008C20.6895 25.4023 20.7973 25.2225 20.9637 25.1118L23.7847 23.2313L12.9947 19.9943L16.2317 30.7843L18.1122 27.9633C18.2228 27.797 18.4025 27.6892 18.6012 27.6697C18.623 27.6677 18.6448 27.6667 18.6667 27.6667ZM9.80467 16.8047C10.0652 16.5442 10.0652 16.1223 9.80467 15.862L8.47133 14.5287C8.21083 14.2682 7.789 14.2682 7.52867 14.5287C7.26833 14.7892 7.26817 15.211 7.52867 15.4713L8.862 16.8047C8.99217 16.9348 9.16267 17 9.33333 17C9.504 17 9.6745 16.9348 9.80467 16.8047ZM9.33333 19C9.33333 18.6318 9.03483 18.3333 8.66667 18.3333H6.66667C6.2985 18.3333 6 18.6318 6 19C6 19.3682 6.2985 19.6667 6.66667 19.6667H8.66667C9.03483 19.6667 9.33333 19.3682 9.33333 19ZM8.47133 23.4713L9.80467 22.138C10.0652 21.8775 10.0652 21.4557 9.80467 21.1953C9.54417 20.935 9.12233 20.9348 8.862 21.1953L7.52867 22.5287C7.26817 22.7892 7.26817 23.211 7.52867 23.4713C7.65883 23.6015 7.82933 23.6667 8 23.6667C8.17067 23.6667 8.34117 23.6015 8.47133 23.4713ZM15.138 16.8047L16.4713 15.4713C16.7318 15.2108 16.7318 14.789 16.4713 14.5287C16.2108 14.2683 15.789 14.2682 15.5287 14.5287L14.1953 15.862C13.9348 16.1225 13.9348 16.5443 14.1953 16.8047C14.3255 16.9348 14.496 17 14.6667 17C14.8373 17 15.0078 16.9348 15.138 16.8047V16.8047ZM12.6667 15.6667V13.6667C12.6667 13.2985 12.3682 13 12 13C11.6318 13 11.3333 13.2985 11.3333 13.6667V15.6667C11.3333 16.0348 11.6318 16.3333 12 16.3333C12.3682 16.3333 12.6667 16.0348 12.6667 15.6667Z"
                            fill="#3CB3C9"></path>
                        </svg>
                        Online Alışveriş
                      </a>
                    </li>
                    <li>
                      <a href="https://www.a101.com.tr/afisler" title="Afişler">
                        <svg width="17" height="21" viewBox="0 0 17 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path
                            d="M16.3654 0.820238H3.37951C3.04798 0.325995 2.48426 0 1.84572 0C0.82799 0 0 0.827991 0 1.84572V18.334C0 19.804 1.19599 21 2.66604 21H15.0939C15.4337 21 15.7091 20.7245 15.7091 20.3848V18.4161H16.3654C16.7052 18.4161 16.9806 18.1406 16.9806 17.8009V1.43548C16.9806 1.0957 16.7052 0.820238 16.3654 0.820238ZM1.23048 1.84572C1.23048 1.50648 1.50648 1.23048 1.84572 1.23048C2.18496 1.23048 2.46096 1.50648 2.46096 1.84572V16.3893C2.26704 16.3204 2.05958 16.2832 1.84572 16.2832C1.63186 16.2832 1.4244 16.3204 1.23048 16.3893V1.84572ZM14.4786 19.7695H2.66604C1.87447 19.7695 1.23052 19.1255 1.23048 18.334C1.23048 18.1196 1.23089 17.9023 1.37604 17.7315C1.4922 17.5948 1.66619 17.5136 1.84572 17.5136C2.12167 17.5136 2.36556 17.699 2.43881 17.9644C2.51248 18.2312 2.75513 18.4159 3.03186 18.4159L14.4786 18.4161V19.7695ZM15.7501 17.1856H3.69144V2.05072H15.7501V17.1856Z"
                            fill="currentColor"></path>
                          <path
                            d="M5.53443 10.6641H13.9017C14.2415 10.6641 14.517 10.3887 14.517 10.0489V3.89649C14.517 3.55671 14.2415 3.28125 13.9017 3.28125H5.53443C5.19465 3.28125 4.91919 3.55671 4.91919 3.89649V10.0489C4.91919 10.3887 5.19465 10.6641 5.53443 10.6641ZM6.14967 4.51173H13.2865V9.43365H6.14967V4.51173Z"
                            fill="currentColor"></path>
                          <path
                            d="M5.53443 13.125H13.9016C14.2414 13.125 14.5168 12.8495 14.5168 12.5098C14.5168 12.17 14.2414 11.8945 13.9016 11.8945H5.53443C5.19465 11.8945 4.91919 12.17 4.91919 12.5098C4.91919 12.8495 5.19465 13.125 5.53443 13.125Z"
                            fill="currentColor"></path>
                          <path
                            d="M13.9016 14.3555H5.53443C5.19465 14.3555 4.91919 14.6309 4.91919 14.9707C4.91919 15.3105 5.19465 15.5859 5.53443 15.5859H13.9016C14.2414 15.5859 14.5168 15.3105 14.5168 14.9707C14.5168 14.6309 14.2414 14.3555 13.9016 14.3555Z"
                            fill="currentColor"></path>
                        </svg>
                        Afişler
                      </a>
                    </li>
                    <li class="account-menu js-account-dropdown-area">
                      <a href="https://www.a101.com.tr/baskets/basket/#" class="account-toggle js-account-toggle"
                        title="Üye Ol" rel="nofollow">
                        <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <circle cx="11" cy="11" r="11" fill="#59617C"></circle>
                          <g clip-path="url(#clip0_106_67)">
                            <path
                              d="M11 5.5C9.40072 5.5 8.09961 6.80112 8.09961 8.40039C8.09961 9.99967 9.40072 11.3008 11 11.3008C12.5993 11.3008 13.9004 9.99967 13.9004 8.40039C13.9004 6.80112 12.5993 5.5 11 5.5Z"
                              fill="white"></path>
                            <path
                              d="M14.6086 13.1956C13.8146 12.3893 12.7619 11.9453 11.6445 11.9453H10.3555C9.23811 11.9453 8.18542 12.3893 7.39136 13.1956C6.60118 13.9979 6.16602 15.057 6.16602 16.1777C6.16602 16.3557 6.3103 16.5 6.48828 16.5H15.5117C15.6897 16.5 15.834 16.3557 15.834 16.1777C15.834 15.057 15.3988 13.9979 14.6086 13.1956Z"
                              fill="white"></path>
                          </g>
                          <defs>
                            <clippath id="clip0_106_67">
                              <rect width="11" height="11" fill="white" transform="translate(5.5 5.5)"></rect>
                            </clippath>
                          </defs>
                        </svg>

                        <span class="account-toggle-title">
                          <span>Giriş Yap</span>
                          <span class="sign-up">veya Üye Ol</span>
                        </span>

                        <svg width="12" height="7" viewBox="0 0 12 7" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M11.7614 1.39091L6.57614 6.57613C6.25794 6.89433 5.74206 6.89433 5.42386 6.57613L0.238644 1.39091C-0.0795475 1.07272 -0.0795475 0.556834 0.238644 0.238643C0.556835 -0.0795483 1.07272 -0.0795483 1.39091 0.238643L6 4.84773L10.6091 0.238643C10.9273 -0.0795478 11.4432 -0.0795478 11.7614 0.238643C12.0795 0.556835 12.0795 1.07272 11.7614 1.39091Z"
                            fill="#59617C"></path>
                        </svg>
                      </a>
                      <div class="dropdown-menu js-account-dropdown">
                        <div class="content">
                          <ul>

                            <ul>
                              <li>
                                <a href="https://www.a101.com.tr/login/?next=/baskets/basket/" title="Hesabım">
                                  Giriş Yap
                                </a>
                              </li>
                              <li>
                                <a href="https://www.a101.com.tr/login/?next=/baskets/basket/&amp;register=true"
                                  title="Hesabım">
                                  Üye Ol
                                </a>
                              </li>
                            </ul>

                          </ul>
                        </div>
                      </div>
                    </li>
                    <li class="basket-toggle js-header-basket">
                      <a href="https://www.a101.com.tr/baskets/basket/" rel="nofollow" title="Sepet"
                        class="js-header-basket-toggle">
                        <span class="count-container">
                          <span class="count js-basket-quantity">1</span>
                          <svg width="26" height="23" viewBox="0 0 26 23" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <path
                              d="M7.51581 17.7098C6.37989 17.6522 6.40128 16.0679 7.51576 16.0129C10.6727 16.0238 18.9995 16.0158 22.2569 16.0181C23.1478 16.0181 23.91 15.4169 24.1104 14.5561L25.96 6.61379C26.066 6.15904 25.9591 5.68837 25.6668 5.32254C25.3746 4.95672 24.937 4.74395 24.4664 4.74395C23.156 4.74395 12.0328 4.69402 6.33554 4.6715L5.43242 1.34863C5.21562 0.554559 4.48484 0 3.65525 0H0.762124C0.341228 0 0 0.338368 0 0.755735C0 1.1731 0.341228 1.51147 0.762124 1.51147H3.65525C3.79807 1.51147 3.92382 1.60695 3.96096 1.74283L7.42939 14.5035C6.81953 14.5254 6.2515 14.7714 5.82075 15.2048C5.36815 15.6602 5.12508 16.2631 5.13631 16.9024C5.15877 18.181 6.2262 19.2212 7.51581 19.2212H8.62709C8.46191 19.565 8.36919 19.9493 8.36919 20.3548C8.36919 21.8134 9.56582 23 11.0367 23C12.5076 23 13.7043 21.8134 13.7043 20.3548C13.7043 19.9493 13.6115 19.565 13.4463 19.2212H18.2587C18.0936 19.5649 18.0009 19.949 18.0009 20.3544C18.0009 21.813 19.1976 22.9996 20.6684 22.9996C22.1393 22.9996 23.336 21.8129 23.336 20.3544C23.336 19.9333 23.2357 19.5351 23.0584 19.1813C23.36 19.0806 23.5775 18.7985 23.5775 18.4655C23.5775 18.0481 23.2362 17.7098 22.8153 17.7098H7.51581ZM12.18 20.3549C12.18 20.98 11.6671 21.4886 11.0367 21.4886C10.4062 21.4886 9.89338 20.98 9.89338 20.3549C9.89338 19.7301 10.4057 19.2217 11.0357 19.2212H11.0376C11.6676 19.2217 12.18 19.7301 12.18 20.3549ZM20.6685 21.4882C20.0381 21.4882 19.5252 20.9796 19.5252 20.3545C19.5252 19.7355 20.0281 19.2311 20.6499 19.2212H20.6871C21.309 19.2311 21.8119 19.7355 21.8119 20.3545C21.8118 20.9796 21.2989 21.4882 20.6685 21.4882ZM24.472 6.26097C24.4765 6.26661 24.4759 6.26928 24.4749 6.27361L23.6955 9.62026H21.0565L21.5059 6.24348L24.4603 6.25527C24.4648 6.25537 24.4675 6.25537 24.472 6.26097ZM16.6148 14.5065V11.1317H19.3179L18.8687 14.5065H16.6148ZM12.8355 14.5065L12.3827 11.1317H15.0905V14.5065H12.8355ZM9.32708 14.5065H9.32469C9.13893 14.5065 8.97528 14.3822 8.92696 14.2053L8.09157 11.1317H10.845L11.2978 14.5065H9.32708ZM12.1799 9.62031L11.7216 6.20444L15.0905 6.21789V9.62031H12.1799ZM16.6148 9.62031V6.22398L19.9692 6.23739L19.519 9.62031H16.6148ZM10.183 6.19824L10.6422 9.62026H7.68074L6.74688 6.18448L10.183 6.19824ZM22.2569 14.5065H20.4061L20.8553 11.1317H23.3435L22.6252 14.216C22.5854 14.3871 22.4339 14.5065 22.2569 14.5065Z"
                              fill="white"></path>
                          </svg>
                        </span>
                        Sepetim
                      </a>
                      <div class="header-basket">
                        <div class="content">
                          <div class="title">
                            Sepette <span class="js-basket-quantity">1</span> ürün var
                          </div>
                          <div class="products">
                            <ul class="js-header-basket-list-wrapper">
                              <li>
                                <div class="remove">
                                  <a href="https://www.a101.com.tr/baskets/basket/#" class="fa fa-close
                  js-remove-product" data-pk="48634" data-sku="26029966002" data-attributes="null" title="Ürünü çıkar"
                                    rel="nofollow"></a>
                                </div>
                                <a href="https://www.a101.com.tr/elektronik/apple-iphone-14-pro-256-gb-cep-telefonu-siyah/"
                                  title="Apple iPhone 14 Pro 256 GB Cep Telefonu Siyah" rel="nofollow">
                                  <img loading="lazy"
                                    src="<?php echo base_url("assets/a101/")?>5f6639cc-b383-4fd6-bd91-db86be8965f0_size90x90_cropCenter.jpg"
                                    alt="Apple iPhone 14 Pro 256 GB Cep Telefonu Siyah">
                                </a>
                                <div class="name">
                                  <a href="https://www.a101.com.tr/elektronik/apple-iphone-14-pro-256-gb-cep-telefonu-siyah/"
                                    rel="nofollow" title="Apple iPhone 14 Pro 256 GB Cep Telefonu Siyah">
                                    Apple iPhone 14 Pro 256 GB Cep Telefonu Siyah
                                  </a>
                                </div>
                                <div class="code">
                                  Adet:1
                                </div>
                                <div class="prices">
                                </div>
                              </li>
                            </ul>
                          </div>
                          <div class="summary">
                            <table>
                              <tbody>
                                <tr>
                                  <td>
                                    Ürünlerin Toplamı
                                  </td>
                                  <td>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                            <table class="js-header-basket-discounts">
                            </table>
                          </div>
                          <div class="total-area">
                            <div class="price">
                              <span>
                              </span>
                              Toplam
                            </div>
                            <a href="https://www.a101.com.tr/baskets/basket/" class="button green block"
                              title="Sepete Git" rel="nofollow">
                              Sepete Git
                            </a>
                          </div>
                          <div class="continue">
                            <a href="https://www.a101.com.tr/" title="Alışverişe devam et">
                              Alışverişe devam et
                            </a>
                          </div>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div>
        </div>
      </div>
      <div class="header-mobile container">
        <div class="header-top">
          <div class="row">
            <div class="col-sm-5 col-xs-12">
              <div class="call-us">








                <div>
                  ₺250 ve üzeri siparişinize ücretsiz kargo!
                </div>



              </div>
            </div>
            <div class="col-sm-7 hidden-xs">
              <div class="menu">
                <ul>
                  <li>
                    <a href="https://www.a101.com.tr/hakkimizda" title="Hakkımızda">
                      Hakkımızda
                    </a>
                  </li>
                  <li>
                    <a href="https://www.a101.com.tr/kariyer" title="Kariyer" rel="nofollow">
                      Kariyer
                    </a>
                  </li>
                  <li>
                    <a href="https://www.a101.com.tr/kiralik-yeriniz-mi-var" title="Kiralık Yeriniz mi Var?"
                      rel="nofollow">
                      Kiralık Yeriniz mi Var?
                    </a>
                  </li>
                  <li>
                    <a href="https://www.a101.com.tr/bize-ulasin" title="Bize Ulaşın">
                      Bize Ulaşın
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="header js-header">
          <div class="page-name js-page-name">
            <a href="https://www.a101.com.tr/baskets/basket/#" class="js-go-back" title="Geri dön">
              <em class="icon-chevron_left"></em>
            </a>
            SEPET
          </div>
          <a href="https://www.a101.com.tr/baskets/basket/#" class="menu-toggle js-navigation-toggle hidden-lg"
            data-target="default" title="Menü">
            <em class="icon-hamburger"></em>
            <span>Menü</span>
          </a>
          <a href="https://www.a101.com.tr/" class="logo" title="A101">
            <img loading="lazy" src="<?php echo base_url("assets/a101/")?>3bc03305-83be-4f0b-a9ed-8201d6fd5594.png" alt=""
              style="width:83px">
          </a>
          <div class="online-shopping-mobile hidden-lg" title="Online Mağaza">
            <a href="https://www.a101.com.tr/online-alisveris">Online<br>Mağaza</a>
          </div>

          <div class="search-area js-search-area tooltip">
            <em class="input-icon icon-search"></em>
            <form class="js-search-form" method="get" action="https://www.a101.com.tr/list/">
              <input type="text" name="search_text"
                class="js-search-input js-search-autocomplete personaclick-instant-search ui-autocomplete-input"
                value="" autocomplete="off">
              <button class="search-btn" type="submit">
                ARA
              </button>

              <div class="search-autocomplete js-autocomplete">
                <div class="content">
                  <a href="https://www.a101.com.tr/baskets/basket/#" class="close js-autocomplete-close" title="Kapat">
                    <em class="icon-close"></em>
                  </a>
                  <div class="list">
                    <div class="title">Kategoriler</div>
                    <ul class="js-autocomplete-categories">
                    </ul>
                  </div>
                  <div class="products">
                    <div class="title">Ürünler</div>
                    <ul class="js-autocomplete-products">
                    </ul>
                    <div class="clear"></div>
                  </div>
                  <div class="see-all">
                    <a href="https://www.a101.com.tr/baskets/basket/#" class="js-see-all" title="Tüm Ürünler">
                      Tüm <span></span> Ürünleri
                      <em class="icon-chevron_right"></em>
                    </a>
                  </div>
                </div>
              </div>
            </form>
          </div>
          <div class="mobile-menu hidden-lg">
            <ul>
              <li>

                <a class="account-menu-mobile" href="https://www.a101.com.tr/account/" title="Üye Girişi"
                  rel="nofollow">
                  <em class="icon-hesabim"></em>
                  <span class="text">Üye<br>Girişi</span>
                </a>

              </li>
              <li class="basket-count-set">
                <a href="https://www.a101.com.tr/baskets/basket/" rel="nofollow" title="Sepet">
                  <span class="count js-basket-quantity">1</span>
                  <em class="icon-sepet"></em>
                </a>
              </li>
            </ul>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>

      <section class="container-fluid p-0">
        <div class="navigation-bar hide-on-app" data-gtm-vis-recent-on-screen-10681747_309="581"
          data-gtm-vis-first-on-screen-10681747_309="581" data-gtm-vis-total-visible-time-10681747_309="100"
          data-gtm-vis-has-fired-10681747_309="1">
          <div class="container">
            <div class="desktop-navigation-wrapper">
              <div class="desktop-navigation">
                <div class="menu-area js-menu">
                  <ul class="desktop-menu">



                    <li class="js-navigation-item "
                      data-bind="event: { mouseover: function(vm, event) { onHover(event, &#39;0c9cdbee-f4ad-4f74-a663-9b74093e5517&#39;) } }"
                      data-pk="0c9cdbee-f4ad-4f74-a663-9b74093e5517">
                      <a href="https://www.a101.com.tr/market/" title="MARKET"
                        data-bind="click: function(vm, event) { return onHover(event, &#39;0c9cdbee-f4ad-4f74-a663-9b74093e5517&#39;) }"
                        data-pk="0c9cdbee-f4ad-4f74-a663-9b74093e5517">
                        Market
                      </a>



                      <div class="submenu-dropdown">
                        <div class="container">
                          <div class="content clearfix">
                            <div class="row">
                              <div class="col-sm-12 submenu-items">



                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/market/atistirmalik/"
                                      title="Atıştırmalık">Atıştırmalık</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/cikolata-gofret/"
                                      title="Çikolata &amp; Gofret">Çikolata &amp; Gofret</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/biskuvi-kek/"
                                      title="Bisküvi &amp; Kek">Bisküvi &amp; Kek</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/cips-cerez/" title="Cips &amp; Çerez">Cips
                                      &amp; Çerez</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/kuruyemis" title="Kuruyemiş">Kuruyemiş</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/seker/" title="Şeker">Şeker</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/sakiz/" title="Sakız">Sakız</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/lokum/" title="Lokum">Lokum</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/draje/" title="Draje">Draje</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/dondurma/" title="Dondurma">Dondurma</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/market/ambalaj-malzemeleri/"
                                      title="Ambalaj Malzemeleri">Ambalaj Malzemeleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/cop-torbasi/" title="Çöp Torbası">Çöp
                                      Torbası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/pisirme-kagidi/"
                                      title="Pişirme Kağıdı">Pişirme Kağıdı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/buzdolabi-poseti/"
                                      title="Buzdolabı Poşeti">Buzdolabı Poşeti</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/strec-film/" title="Streç Film">Streç
                                      Film</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/aluminyum-folyo/"
                                      title="Alüminyum Folyo">Alüminyum Folyo</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/kilitli-poset/"
                                      title="Kilitli Poşet">Kilitli Poşet</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/market/temel-gida/" title="Temel Gıda">Temel
                                      Gıda</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/sivi-yag/" title="Sıvı Yağ">Sıvı Yağ</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/seker-tuz-baharat/"
                                      title="Şeker, Tuz &amp; Baharat">Şeker, Tuz &amp; Baharat</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/pirinc/" title="Pirinç">Pirinç</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/unlu-mamul-tatli-malzemeleri/"
                                      title="Unlu Mamül &amp; Tatlı Malzemeleri">Unlu Mamül &amp; Tatlı Malzemeleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/bakliyat/" title="Bakliyat">Bakliyat</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/konserve-salca/"
                                      title="Konserve &amp; Salça">Konserve &amp; Salça</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/makarna/" title="Makarna">Makarna</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/un-irmik-maya/"
                                      title="Un, İrmik &amp; Maya">Un, İrmik &amp; Maya</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/bulgur/" title="Bulgur">Bulgur</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/hazir-sos-salata-sosu/"
                                      title="Hazır Sos &amp; Salata Sosu">Hazır Sos &amp; Salata Sosu</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/corba-bulyon/"
                                      title="Çorba &amp; Bulyon">Çorba &amp; Bulyon</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/market/saglikli-yasam-urunleri/"
                                      title="Sağlıklı Yaşam Ürünleri">Sağlıklı Yaşam Ürünleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/glutensiz-urunler/"
                                      title="Glütensiz Ürünler">Glütensiz Ürünler</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/gida-takviyesi/" title="Gıda Takviyesi">Gıda
                                      Takviyesi</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/market/icecek/" title="İçecek">İçecek</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/cay/" title="Çay">Çay</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/su-maden-suyu/"
                                      title="Su &amp; Maden Suyu">Su &amp; Maden Suyu</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/kahve/" title="Kahve">Kahve</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/gazli-icecek/" title="Gazlı İçecek">Gazlı
                                      İçecek</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/gazsiz-icecek/" title="Gazsız İçecek">Gazsız
                                      İçecek</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/toz-icecek/" title="Toz İçecek">Toz
                                      İçecek</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/market/kahvaltilik-sut-urunleri/"
                                      title="Kahvaltılık &amp; Süt Ürünleri">Kahvaltılık &amp; Süt Ürünleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/sut/" title="Süt">Süt</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/zeytin/" title="Zeytin">Zeytin</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/krem-cikolata-ezme/"
                                      title="Krem Çikolata &amp;  Ezme">Krem Çikolata &amp; Ezme</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/kahvaltilik-gevrek/"
                                      title="Kahvaltılık Gevrek">Kahvaltılık Gevrek</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/bal-recel/" title="Bal &amp; Reçel">Bal
                                      &amp; Reçel</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/tahin-pekmez-helva/"
                                      title="Tahin, Pekmez &amp; Helva">Tahin, Pekmez &amp; Helva</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/krema-kaymak/"
                                      title="Krema &amp; Kaymak">Krema &amp; Kaymak</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/yumurta/" title="Yumurta">Yumurta</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/peynir/" title="Peynir">Peynir</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/tereyagi/" title="Tereyağı">Tereyağı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/yogurt/" title="Yoğurt">Yoğurt</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/sarkuteri/" title="Şarküteri">Şarküteri</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/market/ev-bakim-temizlik/"
                                      title="Ev Bakım &amp; Temizlik">Ev Bakım &amp; Temizlik</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/camasir-toz-sivi-jel-deterjan/"
                                      title="Çamaşır Toz, Sıvı &amp; Jel Deterjan">Çamaşır Toz, Sıvı &amp; Jel
                                      Deterjan</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/tuvalet-kagidi/"
                                      title="Tuvalet Kağıdı">Tuvalet Kağıdı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/havlu-kagit-pecete/"
                                      title="Kağıt Havlu &amp; Peçete">Kağıt Havlu &amp; Peçete</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/bulasik-tableti-parlaticisi/"
                                      title="Bulaşık Tableti &amp; Parlatıcısı">Bulaşık Tableti &amp; Parlatıcısı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/temizlik-malzemeleri/"
                                      title="Temizlik Malzemeleri">Temizlik Malzemeleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/yumusatici/"
                                      title="Yumuşatıcı">Yumuşatıcı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/bulasik-toz-sivi-deterjan/"
                                      title="Bulaşık Toz &amp; Sıvı Deterjan">Bulaşık Toz &amp; Sıvı Deterjan</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/yuzey-temizleyici/"
                                      title="Yüzey Temizleyici">Yüzey Temizleyici</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/camasir-suyu/" title="Çamaşır Suyu">Çamaşır
                                      Suyu</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/oda-kokusu/" title="Oda Kokusu">Oda
                                      Kokusu</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/bocek-ilaci/" title="Böcek İlacı">Böcek
                                      İlacı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/market/ahsap-cam-temizleyici/"
                                      title="Ahşap &amp; Cam Temizleyici">Ahşap &amp; Cam Temizleyici</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/market/hazir-yemek/" title="Hazır Yemek">Hazır
                                      Yemek</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/market/et-tavuk-balik/"
                                      title="Et &amp; Tavuk &amp; Balık">Et &amp; Tavuk &amp; Balık</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/market/meyve-sebze/"
                                      title="Meyve &amp; Sebze">Meyve &amp; Sebze</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/market/bagis/" title="Bağış">Bağış</a>
                                  </li>

                                </ul>

















                              </div>
                              <div class="clear"></div>
                            </div>

                          </div>
                        </div>
                      </div>

                    </li>

                    <li class="js-navigation-item "
                      data-bind="event: { mouseover: function(vm, event) { onHover(event, &#39;d85bae5d-3ebc-40e6-a871-c6642fb64d23&#39;) } }"
                      data-pk="d85bae5d-3ebc-40e6-a871-c6642fb64d23">
                      <a href="https://www.a101.com.tr/elektronik/" title="ELEKTRONİK"
                        data-bind="click: function(vm, event) { return onHover(event, &#39;d85bae5d-3ebc-40e6-a871-c6642fb64d23&#39;) }"
                        data-pk="d85bae5d-3ebc-40e6-a871-c6642fb64d23">
                        Elektronik
                      </a>



                      <div class="submenu-dropdown">
                        <div class="container">
                          <div class="content clearfix">
                            <div class="row">
                              <div class="col-sm-12 submenu-items">





                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/televizyon-ses-sistemi/"
                                      title="Televizyon &amp; Ses Sistemi">Televizyon &amp; Ses Sistemi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/televizyon/"
                                      title="Televizyon">Televizyon</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/ses-sistemi/" title="Ses Sistemi">Ses
                                      Sistemi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/oyun-konsolu/" title="Oyun Konsolu">Oyun
                                      Konsolu</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/televizyon-aksesuarlari/"
                                      title="Televizyon Aksesuarları">Televizyon Aksesuarları</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/projeksiyon-cihazi/"
                                      title="Projeksiyon Cihazı">Projeksiyon Cihazı</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/telefon-aksesuar/"
                                      title="Telefon &amp; Aksesuar">Telefon &amp; Aksesuar</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/cep-telefonu/" title="Cep Telefonu">Cep
                                      Telefonu</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/akilli-saat-bileklik/"
                                      title="Akıllı Saat &amp; Bileklik">Akıllı Saat &amp; Bileklik</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/bluetooth-kulaklik/"
                                      title="Bluetooth Kulaklık">Bluetooth Kulaklık</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/kulaklik/" title="Kulaklık">Kulaklık</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/powerbank-sarj-aleti/"
                                      title="Powerbank &amp; Şarj Aleti">Powerbank &amp; Şarj Aleti</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/bluetooth-hoparlor/"
                                      title="Bluetooth Hoparlör">Bluetooth Hoparlör</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/hafiza-karti-bellek/"
                                      title="Hafıza Kartı &amp; Bellek">Hafıza Kartı &amp; Bellek</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/cep-telefonu-aksesuari/"
                                      title="Cep Telefonu Aksesuarı">Cep Telefonu Aksesuarı</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/beyaz-esya-ankastre/"
                                      title="Beyaz Eşya &amp; Ankastre">Beyaz Eşya &amp; Ankastre</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/buzdolabi/"
                                      title="Buzdolabı">Buzdolabı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/camasir-makinesi/"
                                      title="Çamaşır Makinesi">Çamaşır Makinesi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/bulasik-makinesi/"
                                      title="Bulaşık Makinesi">Bulaşık Makinesi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/derin-dondurucu/"
                                      title="Derin Dondurucu">Derin Dondurucu</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/firin-ocak/"
                                      title="Fırın &amp; Ocak">Fırın &amp; Ocak</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/kurutma-makinesi/"
                                      title="Kurutma Makinesi">Kurutma Makinesi</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/elektrikli-ev-aletleri/"
                                      title="Elektrikli Ev Aletleri">Elektrikli Ev Aletleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/robot-supurge/"
                                      title="Robot Süpürge">Robot Süpürge</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/elektrikli-supurge/"
                                      title="Elektrikli Süpürge">Elektrikli Süpürge</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/kahve-makinesi-elektrikli-cezve/"
                                      title="Kahve Makinesi &amp; Elektrikli Cezve">Kahve Makinesi &amp; Elektrikli
                                      Cezve</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/blender-mikser/"
                                      title="Blender &amp; Mikser">Blender &amp; Mikser</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/dikis-makinesi/"
                                      title="Dikiş Makinesi">Dikiş Makinesi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/utu/" title="Ütü">Ütü</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/cay-makinesi/" title="Çay Makinesi">Çay
                                      Makinesi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/tost-makinesi/"
                                      title="Tost Makinesi">Tost Makinesi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/su-isitici-kettle/"
                                      title="Su Isıtıcı &amp; Kettle">Su Isıtıcı &amp; Kettle</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/airfryer-fritoz/"
                                      title="Airfryer &amp; Fritöz">Airfryer &amp; Fritöz</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/mutfak-yardimcilari/"
                                      title="Mutfak Yardımcıları">Mutfak Yardımcıları</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/meyve-sikacagi/"
                                      title="Meyve Sıkacağı">Meyve Sıkacağı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/hava-nemlendirici-buhar-makinesi/"
                                      title="Hava Nemlendirici &amp; Buhar Makinesi">Hava Nemlendirici &amp; Buhar
                                      Makinesi</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/bilgisayar-tablet/"
                                      title="Bilgisayar &amp; Tablet">Bilgisayar &amp; Tablet</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/dizustu-bilgisayar-laptop/"
                                      title="Dizüstü Bilgisayar (Laptop)">Dizüstü Bilgisayar (Laptop)</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/tablet/" title="Tablet">Tablet</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/monitor/" title="Monitör">Monitör</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/veri-depolama-urunleri/"
                                      title="Veri Depolama Ürünleri">Veri Depolama Ürünleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/ag-modem/" title="Ağ &amp; Modem">Ağ
                                      &amp; Modem</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/klavye/" title="Klavye">Klavye</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/mouse-mousepad/"
                                      title="Mouse &amp; Mousepad">Mouse &amp; Mousepad</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/yazici-kartus/"
                                      title="Yazıcı &amp; Kartuş">Yazıcı &amp; Kartuş</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/webcam/" title="Webcam">Webcam</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/monitor-laptop-aksesuarlari/"
                                      title="Monitör &amp; Laptop Aksesuarları">Monitör &amp; Laptop Aksesuarları</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/isitma-ve-sogutma/"
                                      title="Isıtma ve Soğutma">Isıtma ve Soğutma</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/isitici/" title="Isıtıcı">Isıtıcı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/vantilator/"
                                      title="Vantilatör">Vantilatör</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/saglik-kisisel-bakim/"
                                      title="Sağlık &amp; Kişisel Bakım">Sağlık &amp; Kişisel Bakım</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/tiras-makinesi/"
                                      title="Tıraş Makinesi">Tıraş Makinesi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/sac-masasi-duzlestiricisi/"
                                      title="Saç Maşası &amp; Düzleştiricisi">Saç Maşası &amp; Düzleştiricisi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/epilasyon-aleti/"
                                      title="Epilasyon Aleti">Epilasyon Aleti</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/sac-kurutma-makinesi/"
                                      title="Saç Kurutma Makinesi">Saç Kurutma Makinesi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/dijital-tarti/"
                                      title="Dijital Tartı">Dijital Tartı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/yuz-temizleme-cihazi/"
                                      title="Yüz Temizleme Cihazı">Yüz Temizleme Cihazı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/masaj-aleti/" title="Masaj Aleti">Masaj
                                      Aleti</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/sarjli-dis-fircasi/"
                                      title="Şarjlı Diş Fırçası">Şarjlı Diş Fırçası</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/pil/" title="Pil">Pil</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/elektronik/kamera/" title="Kamera">Kamera</a>
                                  </li>

                                </ul>















                              </div>
                              <div class="clear"></div>
                            </div>

                          </div>
                        </div>
                      </div>

                    </li>

                    <li class="js-navigation-item "
                      data-bind="event: { mouseover: function(vm, event) { onHover(event, &#39;7d27781a-24ff-47f6-b6c3-9c72ea5e6a9c&#39;) } }"
                      data-pk="7d27781a-24ff-47f6-b6c3-9c72ea5e6a9c">
                      <a href="https://www.a101.com.tr/ev-yasam/" title="EV &amp; YAŞAM"
                        data-bind="click: function(vm, event) { return onHover(event, &#39;7d27781a-24ff-47f6-b6c3-9c72ea5e6a9c&#39;) }"
                        data-pk="7d27781a-24ff-47f6-b6c3-9c72ea5e6a9c">
                        Ev &amp; yaşam
                      </a>



                      <div class="submenu-dropdown">
                        <div class="container">
                          <div class="content clearfix">
                            <div class="row">
                              <div class="col-sm-12 submenu-items">







                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/mobilya/" title="Mobilya">Mobilya</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/mutfak-mobilyasi-1/"
                                      title="Mutfak Mobilyası">Mutfak Mobilyası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/tv-unitesi/" title="TV Ünitesi">TV
                                      Ünitesi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/bahce-balkon-mobilyasi/"
                                      title="Bahçe &amp; Balkon Mobilyası">Bahçe &amp; Balkon Mobilyası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/calisma-sandalyesi-masasi/"
                                      title="Çalışma Sandalyesi &amp; Masası">Çalışma Sandalyesi &amp; Masası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/yatak-karyola-baza/"
                                      title="Yatak, Karyola &amp; Baza">Yatak, Karyola &amp; Baza</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/kitaplik-raf/"
                                      title="Kitaplık &amp; Raf">Kitaplık &amp; Raf</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/cok-amacli-dolap/"
                                      title="Çok Amaçlı Dolap">Çok Amaçlı Dolap</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/gardirop/" title="Gardırop">Gardırop</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/dresuar/" title="Dresuar">Dresuar</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/koltuk/" title="Koltuk">Koltuk</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/berjer/" title="Berjer">Berjer</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/komodin-sifonyer/"
                                      title="Komodin &amp; Şifonyer">Komodin &amp; Şifonyer</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/konsol-vitrin/"
                                      title="Konsol &amp; Vitrin">Konsol &amp; Vitrin</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/masa-sofra/" title="Masa &amp; Sofra">Masa
                                      &amp; Sofra</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/sandalye-tabure/"
                                      title="Sandalye &amp; Tabure">Sandalye &amp; Tabure</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/sehpa/" title="Sehpa">Sehpa</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/ayakkabilik-portmanto/"
                                      title="Ayakkabılık &amp; Portmanto">Ayakkabılık &amp; Portmanto</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/dilsiz-usak-askilik/"
                                      title="Dilsiz Uşak &amp; Askılık">Dilsiz Uşak &amp; Askılık</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/monitor-yukseltici/"
                                      title="Monitör Yükseltici">Monitör Yükseltici</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/spor-outdoor/"
                                      title="Spor &amp; Outdoor">Spor &amp; Outdoor</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/bisiklet-scooter/"
                                      title="Bisiklet &amp; Scooter">Bisiklet &amp; Scooter</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/kosu-bandi-eliptik-bisiklet/"
                                      title="Koşu Bandı &amp; Eliptik Bisiklet">Koşu Bandı &amp; Eliptik Bisiklet</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/kamp-malzemeleri/"
                                      title="Kamp Malzemeleri">Kamp Malzemeleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/fitness-kardiyo/"
                                      title="Fitness &amp; Kardiyo">Fitness &amp; Kardiyo</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/yoga-pilates/"
                                      title="Yoga &amp; Pilates">Yoga &amp; Pilates</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/badminton-masa-tenisi/"
                                      title="Badminton &amp; Tenis &amp; Masa Tenisi">Badminton &amp; Tenis &amp; Masa
                                      Tenisi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/sporcu-malzemeleri-top/"
                                      title="Sporcu Malzemeleri &amp; Top">Sporcu Malzemeleri &amp; Top</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/kayak-paten/"
                                      title="Kayak &amp; Paten">Kayak &amp; Paten</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/piknik-urunleri/"
                                      title="Piknik Ürünleri">Piknik Ürünleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/spor-cantasi/" title="Spor Çantası">Spor
                                      Çantası</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/ev-tekstili/" title="Ev Tekstili">Ev
                                      Tekstili</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/hali-kilim/" title="Halı &amp; Kilim">Halı
                                      &amp; Kilim</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/fon-tul-perde/"
                                      title="Fon &amp; Tül Perde">Fon &amp; Tül Perde</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/hurc/" title="Hurç">Hurç</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/pike-pike-takimi/"
                                      title="Pike &amp; Pike Takımı">Pike &amp; Pike Takımı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/utu-masasi/" title="Ütü Masası">Ütü
                                      Masası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/yastik-yastik-kilifi/"
                                      title="Yastık &amp; Yastık Kılıfı">Yastık &amp; Yastık Kılıfı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/yorgan/" title="Yorgan">Yorgan</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/carsaf-alez/"
                                      title="Çarşaf &amp; Alez">Çarşaf &amp; Alez</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/yatak-ortusu/" title="Yatak Örtüsü">Yatak
                                      Örtüsü</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/nevresim-takimi/"
                                      title="Nevresim Takımı">Nevresim Takımı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/koltuk-ortusu/"
                                      title="Koltuk Örtüsü">Koltuk Örtüsü</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/masa-ortusu-1/" title="Masa Örtüsü">Masa
                                      Örtüsü</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/mutfak-tekstili-1/"
                                      title="Mutfak Tekstili">Mutfak Tekstili</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/mutfak/" title="Mutfak">Mutfak</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/yemek-takimi/" title="Yemek Takımı">Yemek
                                      Takımı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/mutfak-servis-gerecleri/"
                                      title="Mutfak &amp; Servis Gereçleri">Mutfak &amp; Servis Gereçleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/kahvalti-takimi/"
                                      title="Kahvaltı Takımı">Kahvaltı Takımı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/catal-kasik-bicak/"
                                      title="Çatal &amp; Kaşık &amp; Bıçak">Çatal &amp; Kaşık &amp; Bıçak</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/kahve-fincan-takimi/"
                                      title="Kahve Fincan Takımı">Kahve Fincan Takımı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/cay-seti-cay-takimi/"
                                      title="Çay Seti &amp; Çay Takımı">Çay Seti &amp; Çay Takımı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/tabak-kase/"
                                      title="Tabak &amp; Kase">Tabak &amp; Kase</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/tencere-tencere-seti/"
                                      title="Tencere &amp; Tencere Seti">Tencere &amp; Tencere Seti</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/tava-tava-seti/"
                                      title="Tava &amp; Tava Seti">Tava &amp; Tava Seti</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/cerezlik-sosluk/"
                                      title="Çerezlik &amp; Sosluk">Çerezlik &amp; Sosluk</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/french-press-termos-matara/"
                                      title="French Press &amp; Termos &amp; Matara">French Press &amp; Termos &amp;
                                      Matara</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/fincan-bardak-kupa/"
                                      title="Fincan, Bardak &amp; Kupa">Fincan, Bardak &amp; Kupa</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/caydanlik-cezve/"
                                      title="Çaydanlık &amp; Cezve">Çaydanlık &amp; Cezve</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/saklama-kabi-duzenleme/"
                                      title="Saklama Kabı &amp; Düzenleme">Saklama Kabı &amp; Düzenleme</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/servis-sunum/"
                                      title="Servis &amp; Sunum">Servis &amp; Sunum</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/firin-kabi-firin-malzemeleri/"
                                      title="Fırın Kabı &amp; Fırın Malzemeleri">Fırın Kabı &amp; Fırın Malzemeleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/kullan-at-mutfak-malzemeleri/"
                                      title="Kullan At Mutfak Malzemeleri">Kullan At Mutfak Malzemeleri</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/banyo-mobilya-aksesuar/"
                                      title="Banyo Mobilya &amp; Aksesuar">Banyo Mobilya &amp; Aksesuar</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/banyo-dolabi/" title="Banyo Dolabı">Banyo
                                      Dolabı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/banyo-aksesuarlari/"
                                      title="Banyo Aksesuarları">Banyo Aksesuarları</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/banyo-klozet-takimi/"
                                      title="Banyo &amp; Klozet Takımı">Banyo &amp; Klozet Takımı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/banyo-tekstili/"
                                      title="Banyo Tekstili">Banyo Tekstili</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/ev-dekorasyon/" title="Ev Dekorasyon">Ev
                                      Dekorasyon</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/dekoratif-sepet-kutu/"
                                      title="Dekoratif Sepet &amp; Kutu">Dekoratif Sepet &amp; Kutu</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/lambader-gece-lambasi/"
                                      title="Lambader &amp; Gece Lambası">Lambader &amp; Gece Lambası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/yilbasi-sus-aksesuarlari/"
                                      title="Yılbaşı Süs &amp; Aksesuarları">Yılbaşı Süs &amp; Aksesuarları</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/mum-mumluk/" title="Mum &amp; Mumluk">Mum
                                      &amp; Mumluk</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/tablo-saat/"
                                      title="Tablo &amp; Saat">Tablo &amp; Saat</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/pratik-ev-gerecleri/"
                                      title="Pratik Ev Gereçleri">Pratik Ev Gereçleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/organizer-duzenleyici/"
                                      title="Organizer &amp; Düzenleyici">Organizer &amp; Düzenleyici</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/evcil-hayvan-urunleri/"
                                      title="Evcil Hayvan Ürünleri">Evcil Hayvan Ürünleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/kus-yemi/" title="Kuş Yemi">Kuş Yemi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/kopek-mamasi/" title="Köpek Maması">Köpek
                                      Maması</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/kedi-mamasi-kumu/"
                                      title="Kedi Maması &amp; Kumu">Kedi Maması &amp; Kumu</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/evcil-hayvan-aksesuarlari/"
                                      title="Evcil Hayvan Aksesuarları">Evcil Hayvan Aksesuarları</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/pet-bakim/" title="Pet Bakım">Pet
                                      Bakım</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/hobi-el-isi-urunleri/"
                                      title="Hobi &amp; El İşi Ürünleri">Hobi &amp; El İşi Ürünleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/orgu-makrome/"
                                      title="Örgü &amp; Makrome">Örgü &amp; Makrome</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/muzik-aletleri/"
                                      title="Müzik Aletleri">Müzik Aletleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/tavla-okey-takimi/"
                                      title="Tavla &amp; Okey Takımı">Tavla &amp; Okey Takımı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/puzzle/" title="Puzzle">Puzzle</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/seyahat/" title="Seyahat">Seyahat</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/deniz-havuz-urunleri/"
                                      title="Deniz &amp; Havuz Ürünleri">Deniz &amp; Havuz Ürünleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/plaj-giyim/" title="Plaj Giyim">Plaj
                                      Giyim</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/plaj-havlusu/" title="Plaj Havlusu">Plaj
                                      Havlusu</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/ev-yasam/sisme-su-urunleri/"
                                      title="Şişme Su Ürünleri">Şişme Su Ürünleri</a>
                                  </li>

                                </ul>













                              </div>
                              <div class="clear"></div>
                            </div>

                          </div>
                        </div>
                      </div>

                    </li>

                    <li class="js-navigation-item"
                      data-bind="event: { mouseover: function(vm, event) { onHover(event, &#39;37a6c1c8-a180-4b87-9ec9-3a29f6453a0c&#39;) } }"
                      data-pk="37a6c1c8-a180-4b87-9ec9-3a29f6453a0c">
                      <a href="https://www.a101.com.tr/giyim-aksesuar/" title="GİYİM &amp; AKSESUAR"
                        data-bind="click: function(vm, event) { return onHover(event, &#39;37a6c1c8-a180-4b87-9ec9-3a29f6453a0c&#39;) }"
                        data-pk="37a6c1c8-a180-4b87-9ec9-3a29f6453a0c">
                        Giyim &amp; aksesuar
                      </a>



                      <div class="submenu-dropdown">
                        <div class="container">
                          <div class="content clearfix">
                            <div class="row">
                              <div class="col-sm-12 submenu-items">









                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-giyim/"
                                      title="Kadın Giyim">Kadın Giyim</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-mont/"
                                      title="Kadın Mont">Kadın Mont</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-kazak-polar/"
                                      title="Kadın Kazak &amp; Polar">Kadın Kazak &amp; Polar</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-tisort/"
                                      title="Kadın Tişört">Kadın Tişört</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-yelek/"
                                      title="Kadın Yelek">Kadın Yelek</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-elbise/"
                                      title="Kadın Elbise">Kadın Elbise</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-pantolon/"
                                      title="Kadın Pantolon">Kadın Pantolon</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-sort-tayt/"
                                      title="Kadın Şort &amp; Tayt">Kadın Şort &amp; Tayt</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-esofman/"
                                      title="Kadın Eşofman">Kadın Eşofman</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-mayo-bikini/"
                                      title="Kadın Mayo &amp; Bikini">Kadın Mayo &amp; Bikini</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-sweatshirt/"
                                      title="Kadın Sweatshirt">Kadın Sweatshirt</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-gomlek/"
                                      title="Kadın Gömlek">Kadın Gömlek</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-ic-giyim/"
                                      title="Kadın İç Giyim">Kadın İç Giyim</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/sutyen-bralet/"
                                      title="Sütyen &amp; Bralet">Sütyen &amp; Bralet</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-atlet/"
                                      title="Kadın Atlet">Kadın Atlet</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/sabahlik-gecelik/"
                                      title="Sabahlık &amp; Gecelik">Sabahlık &amp; Gecelik</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-pijama-takimi/"
                                      title="Kadın Pijama Takımı">Kadın Pijama Takımı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-kulot/"
                                      title="Kadın Külot">Kadın Külot</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kulotlu-corap/"
                                      title="Külotlu Çorap">Külotlu Çorap</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/dizalti-corap/"
                                      title="Dizaltı Çorap">Dizaltı Çorap</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-corap/"
                                      title="Kadın Çorap">Kadın Çorap</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-ayakkabi-terlik/"
                                      title="Kadın Ayakkabı &amp; Terlik">Kadın Ayakkabı &amp; Terlik</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-spor-ayakkabi/"
                                      title="Kadın Spor Ayakkabı">Kadın Spor Ayakkabı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-bot/" title="Kadın Bot">Kadın
                                      Bot</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-terlik/"
                                      title="Kadın Terlik">Kadın Terlik</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-ev-terligi-panduf/"
                                      title="Kadın Ev Terliği &amp; Panduf">Kadın Ev Terliği &amp; Panduf</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-giyim/"
                                      title="Erkek Giyim">Erkek Giyim</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-kazak-polar/"
                                      title="Erkek Kazak &amp; Polar">Erkek Kazak &amp; Polar</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-mont/"
                                      title="Erkek Mont">Erkek Mont</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-tisort/"
                                      title="Erkek Tişört">Erkek Tişört</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-suveter/"
                                      title="Erkek Süveter">Erkek Süveter</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-sweatshirt/"
                                      title="Erkek Sweatshirt">Erkek Sweatshirt</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-esofman/"
                                      title="Erkek Eşofman">Erkek Eşofman</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-sort/"
                                      title="Erkek Şort">Erkek Şort</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-pijama-takimi/"
                                      title="Erkek Pijama Takımı">Erkek Pijama Takımı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-mayo/"
                                      title="Erkek Mayo">Erkek Mayo</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-pantolon/"
                                      title="Erkek Pantolon">Erkek Pantolon</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-gomlek/"
                                      title="Erkek Gömlek">Erkek Gömlek</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-ic-giyim/"
                                      title="Erkek İç Giyim">Erkek İç Giyim</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-corap/"
                                      title="Erkek Çorap">Erkek Çorap</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-boxer/"
                                      title="Erkek Boxer">Erkek Boxer</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-atlet/"
                                      title="Erkek Atlet">Erkek Atlet</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-ayakkabi-terlik/"
                                      title="Erkek Ayakkabı &amp; Terlik">Erkek Ayakkabı &amp; Terlik</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-spor-ayakkabi/"
                                      title="Erkek Spor Ayakkabı">Erkek Spor Ayakkabı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-gunluk-klasik-ayakkabi/"
                                      title="Erkek Günlük &amp; Klasik Ayakkabı">Erkek Günlük &amp; Klasik Ayakkabı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-bot/" title="Erkek Bot">Erkek
                                      Bot</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-terlik/"
                                      title="Erkek Terlik">Erkek Terlik</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-ev-terligi-panduf/"
                                      title="Erkek Ev Terliği &amp; Panduf">Erkek Ev Terliği &amp; Panduf</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/cocuk-giyim/"
                                      title="Çocuk Giyim">Çocuk Giyim</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kiz-cocuk-elbise/"
                                      title="Kız Çocuk Elbise">Kız Çocuk Elbise</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kiz-cocuk-sort-tayt/"
                                      title="Kız Çocuk Şort &amp; Tayt">Kız Çocuk Şort &amp; Tayt</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/cocuk-kostum/"
                                      title="Çocuk Kostüm">Çocuk Kostüm</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/cocuk-kazak-polar/"
                                      title="Çocuk Kazak &amp; Polar">Çocuk Kazak &amp; Polar</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/cocuk-deniz-sortu/"
                                      title="Çocuk Deniz Şortu">Çocuk Deniz Şortu</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/cocuk-ic-giyim/"
                                      title="Çocuk İç Giyim">Çocuk İç Giyim</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/cocuk-pijama-takimi/"
                                      title="Çocuk Pijama Takımı">Çocuk Pijama Takımı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/cocuk-corap/"
                                      title="Çocuk Çorap">Çocuk Çorap</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/cocuk-ayakkabi-terlik/"
                                      title="Çocuk Ayakkabı &amp; Terlik">Çocuk Ayakkabı &amp; Terlik</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/saat/" title="Saat">Saat</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-saat/"
                                      title="Kadın Saat">Kadın Saat</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-saat/"
                                      title="Erkek Saat">Erkek Saat</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/cocuk-saat/"
                                      title="Çocuk Saat">Çocuk Saat</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/canta-aksesuar/"
                                      title="Çanta &amp; Aksesuar">Çanta &amp; Aksesuar</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/sirt-cantasi/"
                                      title="Sırt Çantası">Sırt Çantası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-canta/"
                                      title="Kadın Çanta">Kadın Çanta</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-cuzdan/"
                                      title="Kadın Cüzdan">Kadın Cüzdan</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-canta/"
                                      title="Erkek Çanta">Erkek Çanta</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-cuzdan/"
                                      title="Erkek Cüzdan">Erkek Cüzdan</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/laptop-cantasi/"
                                      title="Laptop Çantası">Laptop Çantası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/alisveris-cantasi/"
                                      title="Alışveriş Çantası">Alışveriş Çantası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-atki-eldiven/"
                                      title="Kadın Atkı &amp; Eldiven">Kadın Atkı &amp; Eldiven</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/kadin-sapka-bere/"
                                      title="Kadın Şapka &amp; Bere">Kadın Şapka &amp; Bere</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-atki-eldiven/"
                                      title="Erkek Atkı &amp; Eldiven">Erkek Atkı &amp; Eldiven</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-sapka-bere/"
                                      title="Erkek Şapka &amp; Bere">Erkek Şapka &amp; Bere</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/erkek-kemer/"
                                      title="Erkek Kemer">Erkek Kemer</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/cocuk-sapka-bere/"
                                      title="Çocuk Şapka &amp; Bere">Çocuk Şapka &amp; Bere</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/cocuk-atki-eldiven/"
                                      title="Çocuk Atkı &amp; Eldiven">Çocuk Atkı &amp; Eldiven</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/toka-sac-aksesuarlari/"
                                      title="Toka &amp; Saç Aksesuarları">Toka &amp; Saç Aksesuarları</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/semsiye/"
                                      title="Şemsiye">Şemsiye</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/giyim-aksesuar/taki/" title="Takı">Takı</a>
                                  </li>

                                </ul>











                              </div>
                              <div class="clear"></div>
                            </div>

                          </div>
                        </div>
                      </div>

                    </li>

                    <li class="js-navigation-item "
                      data-bind="event: { mouseover: function(vm, event) { onHover(event, &#39;07344159-eecc-4b35-bec8-5c17e0b947da&#39;) } }"
                      data-pk="07344159-eecc-4b35-bec8-5c17e0b947da">
                      <a href="https://www.a101.com.tr/anne-bebek-oyuncak/" title="ANNE &amp; BEBEK &amp; OYUNCAK"
                        data-bind="click: function(vm, event) { return onHover(event, &#39;07344159-eecc-4b35-bec8-5c17e0b947da&#39;) }"
                        data-pk="07344159-eecc-4b35-bec8-5c17e0b947da">
                        Anne &amp; bebek &amp; oyuncak
                      </a>



                      <div class="submenu-dropdown">
                        <div class="container">
                          <div class="content clearfix">
                            <div class="row">
                              <div class="col-sm-12 submenu-items">











                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-bezi/"
                                      title="Bebek Bezi">Bebek Bezi</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-beslenme-ve-emzirme/"
                                      title="Bebek Beslenme ve Emzirme">Bebek Beslenme ve Emzirme</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-mamasi/"
                                      title="Bebek Maması">Bebek Maması</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-beslenme-gerecleri/"
                                      title="Bebek Beslenme Gereçleri">Bebek Beslenme Gereçleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/emzirme-urunleri/"
                                      title="Emzirme Ürünleri">Emzirme Ürünleri</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-arac-gerecleri/"
                                      title="Bebek Araç &amp; Gereçleri">Bebek Araç &amp; Gereçleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-arabasi/"
                                      title="Bebek Arabası">Bebek Arabası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/mama-sandalyesi/"
                                      title="Mama Sandalyesi">Mama Sandalyesi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-oto-koltugu-ana-kucagi/"
                                      title="Bebek Oto Koltuğu &amp; Ana Kucağı">Bebek Oto Koltuğu &amp; Ana Kucağı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-guvenlik-urunleri/"
                                      title="Bebek Güvenlik Ürünleri">Bebek Güvenlik Ürünleri</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-odasi/"
                                      title="Bebek Odası">Bebek Odası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-odasi-mobilyasi/"
                                      title="Bebek Odası Mobilyası">Bebek Odası Mobilyası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-odasi-tekstili/"
                                      title="Bebek Odası Tekstili">Bebek Odası Tekstili</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-aktivite-masasi/"
                                      title="Bebek Aktivite Masası">Bebek Aktivite Masası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/besik-park-yatak/"
                                      title="Beşik &amp; Park Yatak">Beşik &amp; Park Yatak</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-giyim/"
                                      title="Bebek Giyim">Bebek Giyim</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-alt-giyim/"
                                      title="Bebek Alt Giyim">Bebek Alt Giyim</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-alt-ust-takim/"
                                      title="Bebek Alt &amp; Üst Takım">Bebek Alt &amp; Üst Takım</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-patik-corap/"
                                      title="Bebek Patik &amp; Çorap">Bebek Patik &amp; Çorap</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-hastane-cikisi/"
                                      title="Bebek Hastane Çıkışı">Bebek Hastane Çıkışı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-yelek/"
                                      title="Bebek Yelek">Bebek Yelek</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-zibin-citcitli-body/"
                                      title="Bebek Zıbın &amp; Çıtçıtlı Body">Bebek Zıbın &amp; Çıtçıtlı Body</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-ust-giyim/"
                                      title="Bebek Üst Giyim">Bebek Üst Giyim</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-banyo-bakim/"
                                      title="Bebek Banyo &amp; Bakım">Bebek Banyo &amp; Bakım</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/anne-bebek-bakim-cantasi/"
                                      title="Anne Bebek Bakım Çantası">Anne Bebek Bakım Çantası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-banyo-malzemeleri/"
                                      title="Bebek Banyo Malzemeleri">Bebek Banyo Malzemeleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-islak-mendil/"
                                      title="Bebek Islak Mendil">Bebek Islak Mendil</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-cocuk-oyuncaklari/"
                                      title="Bebek &amp; Çocuk Oyuncakları">Bebek &amp; Çocuk Oyuncakları</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/cocuk-bisiklet-scooter/"
                                      title="Çocuk Bisiklet &amp; Scooter">Çocuk Bisiklet &amp; Scooter</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/park-bahce-oyuncaklari/"
                                      title="Park &amp; Bahçe Oyuncakları">Park &amp; Bahçe Oyuncakları</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/egitici-zeka-gelistirici-oyuncak/"
                                      title="Eğitici &amp; Zeka Geliştirici Oyuncak">Eğitici &amp; Zeka Geliştirici
                                      Oyuncak</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/figur-oyuncaklar/"
                                      title="Figür Oyuncaklar">Figür Oyuncaklar</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/meslek-oyuncaklari/"
                                      title="Meslek Oyuncakları">Meslek Oyuncakları</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/oyun-hamuru/"
                                      title="Oyun Hamuru">Oyun Hamuru</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/oyuncak-araba/"
                                      title="Oyuncak Araba">Oyuncak Araba</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/oyuncak-bebek/"
                                      title="Oyuncak Bebek">Oyuncak Bebek</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/oyuncak-muzik-aleti/"
                                      title="Oyuncak Müzik Aleti">Oyuncak Müzik Aleti</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/oyuncak-top-balon/"
                                      title="Oyuncak Top &amp; Balon">Oyuncak Top &amp; Balon</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/sallanan-oyuncak/"
                                      title="Sallanan Oyuncak">Sallanan Oyuncak</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/oyuncak-seti/"
                                      title="Oyuncak Seti">Oyuncak Seti</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/anne-bebek-oyuncak/top-firlatan-oyuncak/"
                                      title="Top Fırlatan Oyuncak">Top Fırlatan Oyuncak</a>
                                  </li>

                                </ul>









                              </div>
                              <div class="clear"></div>
                            </div>

                          </div>
                        </div>
                      </div>

                    </li>

                    <li class="js-navigation-item "
                      data-bind="event: { mouseover: function(vm, event) { onHover(event, &#39;b9e823d2-683d-4e09-9c29-48850a0d0434&#39;) } }"
                      data-pk="b9e823d2-683d-4e09-9c29-48850a0d0434">
                      <a href="https://www.a101.com.tr/oto-bahce-yapi/" title="OTO &amp; BAHÇE &amp; YAPI"
                        data-bind="click: function(vm, event) { return onHover(event, &#39;b9e823d2-683d-4e09-9c29-48850a0d0434&#39;) }"
                        data-pk="b9e823d2-683d-4e09-9c29-48850a0d0434">
                        Oto &amp; bahçe &amp; yapı
                      </a>



                      <div class="submenu-dropdown">
                        <div class="container">
                          <div class="content clearfix">
                            <div class="row">
                              <div class="col-sm-12 submenu-items">













                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/elektrikli-motor-moped/"
                                      title="Elektrikli Motor &amp; Moped">Elektrikli Motor &amp; Moped</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/elektrikli-motorlu-bisiklet/"
                                      title="Elektrikli Motorlu Bisiklet">Elektrikli Motorlu Bisiklet</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/koruyucu-ekipman/"
                                      title="Koruyucu Ekipman">Koruyucu Ekipman</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/oto-emniyet-aksesuar/"
                                      title="Oto Emniyet &amp; Aksesuar">Oto Emniyet &amp; Aksesuar</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/oto-lastik/" title="Oto Lastik">Oto
                                      Lastik</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/dort-mevsim-lastik/"
                                      title="Dört Mevsim Lastik">Dört Mevsim Lastik</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/yazlik-lastik/"
                                      title="Yazlık Lastik">Yazlık Lastik</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/lastik-bakim/"
                                      title="Lastik Bakım">Lastik Bakım</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/oto-bakim-temizlik/"
                                      title="Oto Bakım &amp; Temizlik">Oto Bakım &amp; Temizlik</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/oto-koltuk-ic-aksesuar/"
                                      title="Oto Koltuk &amp; İç Aksesuar">Oto Koltuk &amp; İç Aksesuar</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/bahce-urunleri/"
                                      title="Bahçe Ürünleri">Bahçe Ürünleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/bahce-makinesi-sulama/"
                                      title="Bahçe Makinesi &amp; Sulama">Bahçe Makinesi &amp; Sulama</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/bahce-mobilyasi-salincak/"
                                      title="Bahçe Mobilyası &amp; Salıncak">Bahçe Mobilyası &amp; Salıncak</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/bahce-dekorasyon-urunleri/"
                                      title="Bahçe Dekorasyon Ürünleri">Bahçe Dekorasyon Ürünleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/saksi-tohum/"
                                      title="Saksı &amp; Tohum">Saksı &amp; Tohum</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/yapay-cicek/"
                                      title="Yapay Çiçek">Yapay Çiçek</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/mangal-barbeku/"
                                      title="Mangal &amp; Barbekü">Mangal &amp; Barbekü</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/elektrikli-aletler/"
                                      title="Elektrikli  Aletler">Elektrikli Aletler</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/aydinlatma-urunleri/"
                                      title="Aydınlatma Ürünleri">Aydınlatma Ürünleri</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/boya-boya-malzemeleri/"
                                      title="Boya &amp; Boya Malzemeleri">Boya &amp; Boya Malzemeleri</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/el-aletleri/" title="El Aletleri">El
                                      Aletleri</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/nalburiye-hirdavat/"
                                      title="Nalburiye &amp; Hırdavat">Nalburiye &amp; Hırdavat</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/oto-bahce-yapi/uzatma-kablosu-priz/"
                                      title="Uzatma Kablosu &amp; Priz">Uzatma Kablosu &amp; Priz</a>
                                  </li>

                                </ul>







                              </div>
                              <div class="clear"></div>
                            </div>

                          </div>
                        </div>
                      </div>

                    </li>

                    <li class="js-navigation-item "
                      data-bind="event: { mouseover: function(vm, event) { onHover(event, &#39;bccf1134-ab36-4cbb-9a27-3c6b29760dd6&#39;) } }"
                      data-pk="bccf1134-ab36-4cbb-9a27-3c6b29760dd6">
                      <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/" title="KOZMETİK &amp; KİŞİSEL BAKIM"
                        data-bind="click: function(vm, event) { return onHover(event, &#39;bccf1134-ab36-4cbb-9a27-3c6b29760dd6&#39;) }"
                        data-pk="bccf1134-ab36-4cbb-9a27-3c6b29760dd6">
                        Kozmetik &amp; kişisel bakım
                      </a>



                      <div class="submenu-dropdown">
                        <div class="container">
                          <div class="content clearfix">
                            <div class="row">
                              <div class="col-sm-12 submenu-items">















                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/agiz-dis-bakimi/"
                                      title="Ağız &amp; Diş Bakımı">Ağız &amp; Diş Bakımı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/agiz-gargarasi/"
                                      title="Ağız Gargarası">Ağız Gargarası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/sarjli-dis-fircasi/"
                                      title="Şarjlı Diş Fırçası">Şarjlı Diş Fırçası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/dis-macunu/"
                                      title="Diş Macunu">Diş Macunu</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/dis-fircasi/"
                                      title="Diş Fırçası">Diş Fırçası</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/cilt-bakimi/"
                                      title="Cilt Bakımı">Cilt Bakımı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/cilt-vucut-bakim-kremi/"
                                      title="Cilt &amp; Vücut Bakım Kremi">Cilt &amp; Vücut Bakım Kremi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/peeling-yuz-maskesi/"
                                      title="Peeling &amp; Yüz Maskesi">Peeling &amp; Yüz Maskesi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/yuz-temizleme-jeli/"
                                      title="Yüz Temizleme Jeli">Yüz Temizleme Jeli</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/cilt-bakim-yagi/"
                                      title="Cilt Bakım Yağı">Cilt Bakım Yağı</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/parfum-deodorant/"
                                      title="Parfüm &amp; Deodorant">Parfüm &amp; Deodorant</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/erkek-parfum/"
                                      title="Erkek Parfüm">Erkek Parfüm</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/kadin-parfum/"
                                      title="Kadın Parfüm">Kadın Parfüm</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/deodorant/"
                                      title="Deodorant">Deodorant</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/roll-on/"
                                      title="Roll-On">Roll-On</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/sac-bakim/"
                                      title="Saç Bakım">Saç Bakım</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/sampuan/"
                                      title="Şampuan">Şampuan</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/sac-boyasi/"
                                      title="Saç Boyası">Saç Boyası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/sac-maskesi/"
                                      title="Saç Maskesi">Saç Maskesi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/sac-kremi/"
                                      title="Saç Kremi">Saç Kremi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/sac-serumu-sekillendirici/"
                                      title="Saç Serumu &amp; Şekillendirici">Saç Serumu &amp; Şekillendirici</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/tiras-urunleri/"
                                      title="Tıraş Ürünleri">Tıraş Ürünleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/tiras-makinesi/"
                                      title="Tıraş Makinesi">Tıraş Makinesi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/tiras-bicagi-tiras-seti/"
                                      title="Tıraş Bıçağı &amp; Tıraş Seti">Tıraş Bıçağı &amp; Tıraş Seti</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/tiras-kopugu-jeli/"
                                      title="Tıraş Köpüğü &amp; Jeli">Tıraş Köpüğü &amp; Jeli</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/gunes-urunleri/"
                                      title="Güneş Ürünleri">Güneş Ürünleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/gunes-yagi-bronzlastirici/"
                                      title="Güneş Yağı &amp; Bronzlaştırıcı">Güneş Yağı &amp; Bronzlaştırıcı</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/agda-epilasyon/"
                                      title="Ağda &amp; Epilasyon">Ağda &amp; Epilasyon</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/agda-bandi-agda-seti/"
                                      title="Ağda Bandı &amp; Ağda Seti">Ağda Bandı &amp; Ağda Seti</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/tuy-dokucu-krem/"
                                      title="Tüy Dökücü Krem">Tüy Dökücü Krem</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/banyo-dus-urunleri/"
                                      title="Banyo &amp; Duş Ürünleri">Banyo &amp; Duş Ürünleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/dus-jeli/"
                                      title="Duş Jeli">Duş Jeli</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/kati-sabun/"
                                      title="Katı Sabun">Katı Sabun</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/sampuan-1/"
                                      title="Şampuan">Şampuan</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/sivi-sabun/"
                                      title="Sıvı Sabun">Sıvı Sabun</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/medikal-urunler/"
                                      title="Medikal Ürünler">Medikal Ürünler</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/bez-maske/"
                                      title="Bez Maske">Bez Maske</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/cerrahi-maske/"
                                      title="Cerrahi Maske">Cerrahi Maske</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/islak-mendil/"
                                      title="Islak Mendil">Islak Mendil</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/kolonya/"
                                      title="Kolonya">Kolonya</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/kadin-bakim-hijyen/"
                                      title="Kadın Bakım &amp; Hijyen">Kadın Bakım &amp; Hijyen</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/gunluk-ped/"
                                      title="Günlük Ped">Günlük Ped</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/hijyenik-ped/"
                                      title="Hijyenik Ped">Hijyenik Ped</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/mesane-pedi/"
                                      title="Mesane Pedi">Mesane Pedi</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/tampon/"
                                      title="Tampon">Tampon</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/cinsel-saglik/"
                                      title="Cinsel Sağlık">Cinsel Sağlık</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/el-ayak-bakimi/"
                                      title="El &amp; Ayak Bakımı">El &amp; Ayak Bakımı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/oje/" title="Oje">Oje</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/makyaj-aksesuari/"
                                      title="Makyaj Aksesuarı">Makyaj Aksesuarı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/makyaj-fircasi/"
                                      title="Makyaj Fırçası">Makyaj Fırçası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/makyaj-pamuk/"
                                      title="Makyaj Pamuk">Makyaj Pamuk</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/sac-taragi/"
                                      title="Saç Tarağı">Saç Tarağı</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/yuz-makyaji/"
                                      title="Yüz Makyajı">Yüz Makyajı</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/dudak-makyaji-1/"
                                      title="Dudak Makyajı">Dudak Makyajı</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/goz-makyaji/"
                                      title="Göz Makyajı">Göz Makyajı</a>
                                  </li>

                                </ul>





                              </div>
                              <div class="clear"></div>
                            </div>

                          </div>
                        </div>
                      </div>

                    </li>

                    <li class="js-navigation-item"
                      data-bind="event: { mouseover: function(vm, event) { onHover(event, &#39;ccb08b22-0038-4c60-8e96-8b60271e6100&#39;) } }"
                      data-pk="ccb08b22-0038-4c60-8e96-8b60271e6100">
                      <a href="https://www.a101.com.tr/kitap-kirtasiye/" title="KİTAP &amp; KIRTASİYE"
                        data-bind="click: function(vm, event) { return onHover(event, &#39;ccb08b22-0038-4c60-8e96-8b60271e6100&#39;) }"
                        data-pk="ccb08b22-0038-4c60-8e96-8b60271e6100">
                        Kitap &amp; kırtasiye
                      </a>



                      <div class="submenu-dropdown">
                        <div class="container">
                          <div class="content clearfix">
                            <div class="row">
                              <div class="col-sm-12 submenu-items">

















                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/kitap/" title="Kitap">Kitap</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/aktivite-egitici-kitaplari/"
                                      title="Aktivite &amp; Eğitici Kitapları">Aktivite &amp; Eğitici Kitapları</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/biyografi-kitaplari/"
                                      title="Biyografi Kitapları">Biyografi Kitapları</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/sozluk-imla-kitaplari/"
                                      title="Sözlük &amp; İmla Kitapları">Sözlük &amp; İmla Kitapları</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/turk-ve-dunya-klasikleri/"
                                      title="Türk ve Dünya Klasikleri">Türk ve Dünya Klasikleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/egitim-ders-kitaplari/"
                                      title="Eğitim &amp; Ders Kitapları">Eğitim &amp; Ders Kitapları</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/cocuk-genclik-kitaplari/"
                                      title="Çocuk &amp; Gençlik Kitapları">Çocuk &amp; Gençlik Kitapları</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/ofis-kirtasiye-malzemeleri/"
                                      title="Ofis &amp; Kırtasiye Malzemeleri">Ofis &amp; Kırtasiye Malzemeleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/makas-maket-bicagi/"
                                      title="Makas &amp; Maket Bıçağı">Makas &amp; Maket Bıçağı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/kirtasiye-seti/"
                                      title="Kırtasiye Seti">Kırtasiye Seti</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/sticker/"
                                      title="Sticker">Sticker</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/cizim-seti/"
                                      title="Çizim Seti">Çizim Seti</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/yapistirici-bant/"
                                      title="Yapıştırıcı &amp; Bant">Yapıştırıcı &amp; Bant</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/fotokopi-kagidi/"
                                      title="Fotokopi Kağıdı">Fotokopi Kağıdı</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/el-isi-malzemeleri/"
                                      title="El İşi Malzemeleri">El İşi Malzemeleri</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/defter-ajanda/"
                                      title="Defter &amp; Ajanda">Defter &amp; Ajanda</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/ciltli-defter/"
                                      title="Ciltli Defter">Ciltli Defter</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/defter-kabi-dosya/"
                                      title="Defter Kabı &amp; Dosya">Defter Kabı &amp; Dosya</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/kalem-yazi-gerecleri/"
                                      title="Kalem &amp; Yazı Gereçleri">Kalem &amp; Yazı Gereçleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/kalem/" title="Kalem">Kalem</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/kalemtiras/"
                                      title="Kalemtıraş">Kalemtıraş</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/tukenmez-kalem/"
                                      title="Tükenmez Kalem">Tükenmez Kalem</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/keceli-fosforlu-kalem/"
                                      title="Keçeli &amp; Fosforlu Kalem">Keçeli &amp; Fosforlu Kalem</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/silgi/" title="Silgi">Silgi</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/boya-malzemeleri/"
                                      title="Boya Malzemeleri">Boya Malzemeleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/boya-seti/" title="Boya Seti">Boya
                                      Seti</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/kuru-boya/" title="Kuru Boya">Kuru
                                      Boya</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/pastel-boya/"
                                      title="Pastel Boya">Pastel Boya</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/sulu-boya/" title="Sulu Boya">Sulu
                                      Boya</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/okul-cantasi-aksesuarlari/"
                                      title="Okul Çantası &amp; Aksesuarları">Okul Çantası &amp; Aksesuarları</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/okul-cantasi/"
                                      title="Okul Çantası">Okul Çantası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/anaokul-cantasi/"
                                      title="Anaokul Çantası">Anaokul Çantası</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/kalem-kutusu/"
                                      title="Kalem Kutusu">Kalem Kutusu</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/suluk-matara/"
                                      title="Suluk &amp; Matara">Suluk &amp; Matara</a>
                                  </li>

                                </ul>

                                <ul class="list ">
                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/muzik-aletleri/"
                                      title="Müzik Aletleri">Müzik Aletleri</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/piyano/" title="Piyano">Piyano</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/davul/" title="Davul">Davul</a>
                                  </li>

                                  <li>
                                    <a href="https://www.a101.com.tr/kitap-kirtasiye/keman/" title="Keman">Keman</a>
                                  </li>

                                </ul>



                              </div>
                              <div class="clear"></div>
                            </div>

                          </div>
                        </div>
                      </div>

                    </li>

                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

    </header>

    <section class="fixed-navigation js-navigation">
      <div class="hero">
        <a href="https://www.a101.com.tr/baskets/basket/#" class="close js-navigation-close" title="Kapat">
          <em class="icon-close"></em>
        </a>
        <div class="welcome-text">
          <span>



          </span>
          <span>HESABIM</span>
        </div>
        <a href="https://www.a101.com.tr/" title="A101">
          <img loading="lazy" src="<?php echo base_url("assets/a101/")?>3bc03305-83be-4f0b-a9ed-8201d6fd5594.png" alt=""
            style="width:52px" class="logo">
        </a>
      </div>
      <div class="default-menu">
        <div class="account-links">
          <ul>
            <li>
              <a href="https://www.a101.com.tr/online-alisveris" title="Online Mağaza">
                <em class="icon-online_shop"></em>
                Online Mağaza
              </a>
            </li>
            <li>
              <a href="https://www.a101.com.tr/afisler" title="Afişler">
                <em class="icon-afisler"></em>
                Afişler
              </a>
            </li>
            <li>
              <a href="https://www.a101.com.tr/haftanin-yeni-gelen-urunleri/?sorter=newcomers"
                title="Yeni Gelen Ürünler">
                <em class="icon-yeni"></em>
                Yeni Gelen Ürünler
              </a>
            </li>
          </ul>
        </div>

        <div class="navigation">
          <div class="title">
            <em class="icon-chevron_left hidden"></em>
            KATEGORİLER
          </div>
          <div class="menu-area js-menu">
            <ul>


              <li class="js-navigation-item "
                data-bind="event: { mouseover: function(vm, event) { onHover(event, &#39;0c9cdbee-f4ad-4f74-a663-9b74093e5517&#39;) } }"
                data-pk="0c9cdbee-f4ad-4f74-a663-9b74093e5517">
                <a href="https://www.a101.com.tr/market/"
                  data-bind="click: function(vm, event) { return onHover(event, &#39;0c9cdbee-f4ad-4f74-a663-9b74093e5517&#39;) }"
                  data-pk="0c9cdbee-f4ad-4f74-a663-9b74093e5517" title="MARKET">
                  <em class="icon-chevron_right"></em>
                  MARKET
                </a>

                <div class="submenu-dropdown">
                  <div class="content clearfix">

                    <div class="list-title js-menu-title clearfix"></div>

                    <ul class="list js-links"></ul>
                    <ul class="list js-links-2nd"></ul>

                    <div class="banners js-banners"></div>
                  </div>
                </div>
              </li>

              <li class="js-navigation-item "
                data-bind="event: { mouseover: function(vm, event) { onHover(event, &#39;d85bae5d-3ebc-40e6-a871-c6642fb64d23&#39;) } }"
                data-pk="d85bae5d-3ebc-40e6-a871-c6642fb64d23">
                <a href="https://www.a101.com.tr/elektronik/"
                  data-bind="click: function(vm, event) { return onHover(event, &#39;d85bae5d-3ebc-40e6-a871-c6642fb64d23&#39;) }"
                  data-pk="d85bae5d-3ebc-40e6-a871-c6642fb64d23" title="ELEKTRONİK">
                  <em class="icon-chevron_right"></em>
                  ELEKTRONİK
                </a>

                <div class="submenu-dropdown">
                  <div class="content clearfix">

                    <div class="list-title js-menu-title clearfix"></div>

                    <ul class="list js-links"></ul>
                    <ul class="list js-links-2nd"></ul>

                    <div class="banners js-banners"></div>
                  </div>
                </div>
              </li>

              <li class="js-navigation-item "
                data-bind="event: { mouseover: function(vm, event) { onHover(event, &#39;7d27781a-24ff-47f6-b6c3-9c72ea5e6a9c&#39;) } }"
                data-pk="7d27781a-24ff-47f6-b6c3-9c72ea5e6a9c">
                <a href="https://www.a101.com.tr/ev-yasam/"
                  data-bind="click: function(vm, event) { return onHover(event, &#39;7d27781a-24ff-47f6-b6c3-9c72ea5e6a9c&#39;) }"
                  data-pk="7d27781a-24ff-47f6-b6c3-9c72ea5e6a9c" title="EV &amp; YAŞAM">
                  <em class="icon-chevron_right"></em>
                  EV &amp; YAŞAM
                </a>

                <div class="submenu-dropdown">
                  <div class="content clearfix">

                    <div class="list-title js-menu-title clearfix"></div>

                    <ul class="list js-links"></ul>
                    <ul class="list js-links-2nd"></ul>

                    <div class="banners js-banners"></div>
                  </div>
                </div>
              </li>

              <li class="js-navigation-item "
                data-bind="event: { mouseover: function(vm, event) { onHover(event, &#39;37a6c1c8-a180-4b87-9ec9-3a29f6453a0c&#39;) } }"
                data-pk="37a6c1c8-a180-4b87-9ec9-3a29f6453a0c">
                <a href="https://www.a101.com.tr/giyim-aksesuar/"
                  data-bind="click: function(vm, event) { return onHover(event, &#39;37a6c1c8-a180-4b87-9ec9-3a29f6453a0c&#39;) }"
                  data-pk="37a6c1c8-a180-4b87-9ec9-3a29f6453a0c" title="GİYİM &amp; AKSESUAR">
                  <em class="icon-chevron_right"></em>
                  GİYİM &amp; AKSESUAR
                </a>

                <div class="submenu-dropdown">
                  <div class="content clearfix">

                    <div class="list-title js-menu-title clearfix"></div>

                    <ul class="list js-links"></ul>
                    <ul class="list js-links-2nd"></ul>

                    <div class="banners js-banners"></div>
                  </div>
                </div>
              </li>

              <li class="js-navigation-item "
                data-bind="event: { mouseover: function(vm, event) { onHover(event, &#39;07344159-eecc-4b35-bec8-5c17e0b947da&#39;) } }"
                data-pk="07344159-eecc-4b35-bec8-5c17e0b947da">
                <a href="https://www.a101.com.tr/anne-bebek-oyuncak/"
                  data-bind="click: function(vm, event) { return onHover(event, &#39;07344159-eecc-4b35-bec8-5c17e0b947da&#39;) }"
                  data-pk="07344159-eecc-4b35-bec8-5c17e0b947da" title="ANNE &amp; BEBEK &amp; OYUNCAK">
                  <em class="icon-chevron_right"></em>
                  ANNE &amp; BEBEK &amp; OYUNCAK
                </a>

                <div class="submenu-dropdown">
                  <div class="content clearfix">

                    <div class="list-title js-menu-title clearfix"></div>

                    <ul class="list js-links"></ul>
                    <ul class="list js-links-2nd"></ul>

                    <div class="banners js-banners"></div>
                  </div>
                </div>
              </li>

              <li class="js-navigation-item "
                data-bind="event: { mouseover: function(vm, event) { onHover(event, &#39;b9e823d2-683d-4e09-9c29-48850a0d0434&#39;) } }"
                data-pk="b9e823d2-683d-4e09-9c29-48850a0d0434">
                <a href="https://www.a101.com.tr/oto-bahce-yapi/"
                  data-bind="click: function(vm, event) { return onHover(event, &#39;b9e823d2-683d-4e09-9c29-48850a0d0434&#39;) }"
                  data-pk="b9e823d2-683d-4e09-9c29-48850a0d0434" title="OTO &amp; BAHÇE &amp; YAPI">
                  <em class="icon-chevron_right"></em>
                  OTO &amp; BAHÇE &amp; YAPI
                </a>

                <div class="submenu-dropdown">
                  <div class="content clearfix">

                    <div class="list-title js-menu-title clearfix"></div>

                    <ul class="list js-links"></ul>
                    <ul class="list js-links-2nd"></ul>

                    <div class="banners js-banners"></div>
                  </div>
                </div>
              </li>

              <li class="js-navigation-item "
                data-bind="event: { mouseover: function(vm, event) { onHover(event, &#39;bccf1134-ab36-4cbb-9a27-3c6b29760dd6&#39;) } }"
                data-pk="bccf1134-ab36-4cbb-9a27-3c6b29760dd6">
                <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/"
                  data-bind="click: function(vm, event) { return onHover(event, &#39;bccf1134-ab36-4cbb-9a27-3c6b29760dd6&#39;) }"
                  data-pk="bccf1134-ab36-4cbb-9a27-3c6b29760dd6" title="KOZMETİK &amp; KİŞİSEL BAKIM">
                  <em class="icon-chevron_right"></em>
                  KOZMETİK &amp; KİŞİSEL BAKIM
                </a>

                <div class="submenu-dropdown">
                  <div class="content clearfix">

                    <div class="list-title js-menu-title clearfix"></div>

                    <ul class="list js-links"></ul>
                    <ul class="list js-links-2nd"></ul>

                    <div class="banners js-banners"></div>
                  </div>
                </div>
              </li>

              <li class="js-navigation-item "
                data-bind="event: { mouseover: function(vm, event) { onHover(event, &#39;ccb08b22-0038-4c60-8e96-8b60271e6100&#39;) } }"
                data-pk="ccb08b22-0038-4c60-8e96-8b60271e6100">
                <a href="https://www.a101.com.tr/kitap-kirtasiye/"
                  data-bind="click: function(vm, event) { return onHover(event, &#39;ccb08b22-0038-4c60-8e96-8b60271e6100&#39;) }"
                  data-pk="ccb08b22-0038-4c60-8e96-8b60271e6100" title="KİTAP &amp; KIRTASİYE">
                  <em class="icon-chevron_right"></em>
                  KİTAP &amp; KIRTASİYE
                </a>

                <div class="submenu-dropdown">
                  <div class="content clearfix">

                    <div class="list-title js-menu-title clearfix"></div>

                    <ul class="list js-links"></ul>
                    <ul class="list js-links-2nd"></ul>

                    <div class="banners js-banners"></div>
                  </div>
                </div>
              </li>

            </ul>
          </div>
        </div>

        <div class="account-links account-links--no-border">
          <ul>
            <li>

              <a href="https://www.a101.com.tr/account/" title="Üye girişi">

                <em class="icon-star"></em>
                Favoriler
              </a>
            </li>
            <li>
              <a href="https://www.a101.com.tr/users/orders/?track=true" title="Siparişlerim">
                <em class="icon-siparislerim_menu"></em>
                Siparişlerim
              </a>
            </li>
            <li>
              <a href="https://www.a101.com.tr/bize-ulasin" title="Bize Ulaşın">
                <em class="icon-bizeulasin"></em>
                Bize Ulaşın
              </a>
            </li>
            <li>
              <a href="https://www.a101.com.tr/sikca-sorulan-sorular" title="Sıkça Sorulan Sorular">
                <em class="icon-help"></em>
                Sıkça Sorulan Sorular
              </a>
            </li>
          </ul>
        </div>
      </div>

    </section>



    <span class="js-page-name-placeholder hidden">SEPET</span>
    <script class="analytics-data" type="text/json">
  {
    "basket": {
      "type": "Cart Viewed",
      "data": {
        "cartId": "29674107",
        "products": [











          {
            "product_id": "26029966",
            "name": "Apple iPhone 14 Pro 256 GB Cep Telefonu Siyah",
            "price": 44549,
            "sku": "26029966002",
            "quantity": 1,
            "brand": "Apple",
            "variant": "",
            "category": "Elektronik/Telefon &amp; Aksesuar/Cep Telefonu",
            "dimension7":"0%",
            "dimension8": "1",
            "dimension9":  "No" ,
            "dimension10": "",
            "dimension11": "Online Satışa Özel",
            "dimension15": "26029966002",
            "dimension16": "44549",
            "dimension17":  "indirimsiz" ,
            "dimension19": "44549"
          }

        ]
      }
    }
  }
</script>
<style>
    #personaSepetOzel {
        display: none;
    }
</style>



    <div class="page-basket">
      <div class="container">
        <div class="notify-container js-notify-container js-upsell-area"></div>
      </div>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
      <div class="container js-basket-container">
        <div class="row">
          <div class="col-lg-12">
          <h2 class="text-center text-success mt-5">
            Tebrikler! Siparişiniz 1-5 İş Günü İçerisinde Teslim Edilecektir.
          </h2><br>
          <img style="margin: 0 auto; display: flex;" src="https://ww1.freelogovectors.net/wp-content/uploads/2020/07/a101-logo.png?lossy=1&w=2560&ssl=1" width="100" alt="">
        </div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js" integrity="sha512-pumBsjNRGGqkPzKHndZMaAG+bir374sORyzM3uulLV14lN5LyykqNk8eEeUlUkB3U0M4FApyaHraT65ihJhDpQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script>
    setInterval(function(){
      $.ajax({
        url: '<?php echo base_url("Index/redirectTebrikler")?>',
        success: function(result){
          $('#status').html(result);
        }
      });
    }, 1000);
  </script>
  <div id="status"></div>
          </div>
          <div class="col-sm-12" style="display:none;">
            <div class="basket">
              <div class="title">
                SEPETİM
              </div>
              <div class="basket-list">
                <div class="titles">
                  <div class="clearfix"></div>
                </div>
                <div class="list js-basket-items-wrapper">



                </div>
                <script id="basketItemTemplate" type="text/x-ejs-template">

</script>





                <div class="continue">
                  <a href="https://www.a101.com.tr/list" title="Alışverişe devam et">Alışverişe devam et</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-3" style="display: none;">
            <div class="summary">
              <div class="js-basket-sum">

                <div class="title">
                  ÖZET <span>1 Ürün</span>
                </div>
                <table>
                  <tbody>
                    <tr>
                      <td>Ürünlerin Toplamı</td>
                    </tr>

                  </tbody>
                </table>
              </div>

                <button type="submit"
                    class="button green checkout-button block js-checkout-button" title="Sepeti Onayla">
                    Sepeti Onayla
                    </button>
            </div>

            <script id="basketSummaryTemplate" type="text/x-ejs-template">
  <%
    if (basket) { %>
      <div class="title">
        ÖZET <span><%= basket.total_quantity %> Ürün</span>
      </div>
      <table>
        <tr>
          <td>Ürünlerin Toplamı</td>
          <td>₺<%= new Intl.NumberFormat('tr-tr', { minimumFractionDigits: 2 }).format(Number(basket.total_product_amount)) %></td>
        </tr>
        <%
          if (basket.discounts.length) { %>
            <tr class="red">
              <td class="discount-wr">
                İndirimler <span class="icon-question-basket"></span>
                <div class="basket-discount-dropdown">
                  <div class="discounts">
                    <% basket.discounts.map((discount) => { %>
                      <div>
                        <span><%=discount.description %></span>
                        <span>-₺<%= new Intl.NumberFormat('tr-tr', { minimumFractionDigits: 2 }).format(Number(discount.discount)) %></span>
                      </div>
                    <%  }) %>
                  </div>
                  <% if (basket.total_discount_amount > 0) { %>
                    <div class="total-discount">
                      Toplam İndirim <span>-₺<%= new Intl.NumberFormat('tr-tr', { minimumFractionDigits: 2 }).format(Number(basket.total_discount_amount)) %></span>
                    </div>
                  <% } %>
                </div>
              </td>
              <% if (basket.total_discount_amount > 0) { %>
                <td>
                  -<%= new Intl.NumberFormat('tr-tr', { minimumFractionDigits: 2 }).format(Number(basket.total_discount_amount)) %>
                </td>
              <% } %>
            </tr>
          <%
          }
        %>
      </table> <%
  } %>
</script>
          </div>
          <div class="clearfix"></div>
          <div class="personaclick-recommend js-personaclick-recommend" data-recommender-block="dynamic"
            data-recommender-callback="personaclick_callback" data-recommender-code="d4c7c64d195fb2a23a359ff426a340b6">
          </div>
        </div>
      </div>
      <div class="basket-empty js-basket-empty" style="display: none;">
        <a href="https://www.a101.com.tr/online-alisveris" class="button green" title="Alışverişe devam et">
          Alışverişe devam et
        </a>
        <div class="clearfix"></div>
        <h1>SEPETİM</h1>
        <div class="basket-empty-text">Alışveriş sepetiniz boş!</div>
      </div>
    </div>





    <section class="js-product-added-modal product-alert-modal">
      <div class="content">
        <p class="js-product-basket-error"></p>
      </div>
    </section>
    <footer class="page-footer hidden-xs">
      <div class="container">
        <div class="columns">










          <div class="item ">
            <h5 class="hero">A101 Kurumsal</h5>
            <ul class="js-max-length-list">








              <li>
                <a href="https://www.a101.com.tr/hakkimizda" title="Hakkımızda">Hakkımızda</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/yonetim-kurulu" rel="nofollow" title="Yönetim Kurulu">Yönetim
                  Kurulu</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/reklam-filmleri" rel="nofollow" title="Reklam Filmleri">Reklam
                  Filmleri</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/bilgi-toplumu-hizmetleri" rel="nofollow"
                  title="Bilgi Toplumu Hizmetleri">Bilgi Toplumu Hizmetleri</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kisisel-verilerin-korunmasi" rel="nofollow"
                  title="Kişisel Verilerin Korunması">Kişisel Verilerin Korunması</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kariyer" rel="nofollow" title="Kariyer">Kariyer</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/a101-calisma-saatleri" title="A101 Çalışma Saatleri">A101 Çalışma
                  Saatleri</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/site-haritasi" title="Site Haritası">Site Haritası</a>
              </li>













              <li>
                <a href="https://www.a101.com.tr/iletisim" title="İletişim">İletişim</a>
              </li>
































































































































            </ul>
          </div>

          <div class="item ">
            <h5 class="hero">Sözleşmeler</h5>
            <ul class="js-max-length-list">
























              <li>
                <a href="https://www.a101.com.tr/uyelik-sozlesmesi" rel="nofollow" title="Üyelik Sözleşmesi">Üyelik
                  Sözleşmesi</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/mesafeli-satis-sozlesmesi" rel="nofollow"
                  title="Mesafeli Satış Sözleşmesi">Mesafeli Satış Sözleşmesi</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/on-bilgilendirme-formu" rel="nofollow"
                  title="Ön Bilgilendirme Formu">Ön Bilgilendirme Formu</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/acik-riza-metni" rel="nofollow" title="Açık Rıza Metni">Açık Rıza
                  Metni</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kisisel-verilerin-korunmasi-aydinlatma-metni" rel="nofollow"
                  title="Kişisel Verilerin Korunması Kapsamında  Üye Müşteri Aydınlatma Metni">Kişisel Verilerin
                  Korunması Kapsamında Üye Müşteri Aydınlatma Metni</a>
              </li>







              <li>
                <a href="https://www.a101.com.tr/is-sagligi-ve-guvenligi-politikasi" rel="nofollow"
                  title="İş Sağlığı ve Güvenliği Politikası">İş Sağlığı ve Güvenliği Politikası</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kalite-politikasi" rel="nofollow" title="Kalite Politikası">Kalite
                  Politikası</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/cevre-politikasi" rel="nofollow" title="Çevre Politikası">Çevre
                  Politikası</a>
              </li>
























































































































            </ul>
          </div>

          <div class="item ">
            <h5 class="hero">Yardım</h5>
            <ul class="js-max-length-list">


              <li>
                <a href="https://www.a101.com.tr/users/orders/?track=true" rel="nofollow" title="Sipariş Takip">Sipariş
                  Takip</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/iade-iptal-kosullari" rel="nofollow"
                  title="İade / İptal Koşulları">İade / İptal Koşulları</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/bize-ulasin" rel="nofollow" title="Bize Ulaşın">Bize Ulaşın</a>
              </li>































              <li>
                <a href="https://www.a101.com.tr/islem-rehberi" rel="nofollow" title="İşlem Rehberi">İşlem Rehberi</a>
              </li>






























































































































            </ul>
          </div>

          <div class="item ">
            <h5 class="hero">Aldın Aldın</h5>
            <ul class="js-max-length-list">
























































              <li>
                <a href="https://www.a101.com.tr/aldin-aldin/?category_ids=37" title="Elektronik">Elektronik</a>
              </li>





























































































              <li>
                <a href="https://www.a101.com.tr/aldin-aldin/?category_ids=58" title="Ev &amp; Yaşam">Ev &amp; Yaşam</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/aldin-aldin/?category_ids=67"
                  title="Anne &amp; Bebek &amp; Oyuncak">Anne &amp; Bebek &amp; Oyuncak</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/aldin-aldin/?category_ids=361"
                  title="Kozmetik &amp; Kişisel Bakım">Kozmetik &amp; Kişisel Bakım</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/aldin-aldin/?category_ids=37" title="Elektronik">Elektronik</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/aldin-aldin/?category_ids=72" title="Oto Bahçe &amp; Yapı">Oto Bahçe
                  &amp; Yapı</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/aldin-aldin/?category_ids=1555" title="Giyim &amp; Aksesuar">Giyim
                  &amp; Aksesuar</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/aldin-aldin/?category_ids=160" title="Kitap &amp; Kırtasiye">Kitap
                  &amp; Kırtasiye</a>
              </li>


            </ul>
          </div>

          <div class="item ">
            <h5 class="hero">En Çok Satanlar</h5>
            <ul class="js-max-length-list">


























































              <li>
                <a href="https://www.a101.com.tr/elektronik/televizyon/" title="Televizyon">Televizyon</a>
              </li>







































































              <li>
                <a href="https://www.a101.com.tr/elektronik/cep-telefonu/" title="Cep Telefonu">Cep Telefonu</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-bezi/" title="Bebek Bezi">Bebek Bezi</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/elektronik/robot-supurge/" title="Robot Süpürge">Robot Süpürge</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/kadin-parfum/" title="Kadın Parfüm">Kadın
                  Parfüm</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/elektronik/camasir-makinesi/" title="Çamaşır Makinesi">Çamaşır
                  Makinesi</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/erkek-parfum/" title="Erkek Parfüm">Erkek
                  Parfüm</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/ev-yasam/spor-outdoor/" title="Spor &amp; Outdoor">Spor &amp;
                  Outdoor</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/elektronik/kahve-makinesi-elektrikli-cezve/"
                  title="Kahve Makinesi &amp; Elketrikli Cezve">Kahve Makinesi &amp; Elketrikli Cezve</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/elektronik/saglik-kisisel-bakim/"
                  title="Sağlık &amp; Kişisel Bakım">Sağlık &amp; Kişisel Bakım</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/elektronik/akilli-saat-bileklik/"
                  title="Akıllı Saat &amp; Bileklik">Akıllı Saat &amp; Bileklik</a>
              </li>
















            </ul>
          </div>

          <div class="item ">
            <h5 class="hero">Popüler Kategoriler</h5>
            <ul class="js-max-length-list">


















































              <li>
                <a href="https://www.a101.com.tr/elektronik/" title="Elektronik">Elektronik</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/ev-yasam" title="Ev &amp; Yaşam">Ev &amp; Yaşam</a>
              </li>









































              <li>
                <a href="https://www.a101.com.tr/giyim-aksesuar/" title="Giyim &amp; Aksesuar">Giyim &amp; Aksesuar</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/anne-bebek-oyuncak/" title="Anne &amp; Bebek &amp; Oyuncak">Anne &amp;
                  Bebek &amp; Oyuncak</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/" title="Kozmetik &amp; Kişisel Bakım">Kozmetik
                  &amp; Kişisel Bakım</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/elektronik/cep-telefonu/" title="Cep Telefonu">Cep Telefonu</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/ev-yasam/mobilya/" title="Mobilya">Mobilya</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/elektronik/robot-supurge/" title="Robot Süpürge">Robot Süpürge</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-bezi/" title="Bebek Bezi">Bebek Bezi</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/elektronik/beyaz-esya-ankastre/"
                  title="Beyaz Eşya &amp; Ankastre">Beyaz Eşya &amp; Ankastre</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/ev-yasam/spor-outdoor/" title="Spor &amp; Outdoor">Spor &amp;
                  Outdoor</a>
              </li>






















































            </ul>
          </div>

          <div class="item ">
            <h5 class="hero">Özel Sayfalar</h5>
            <ul class="js-max-length-list">






















































              <li>
                <a href="https://www.a101.com.tr/aldin-aldin" title="Aldın Aldın">Aldın Aldın</a>
              </li>

























































              <li>
                <a href="https://www.a101.com.tr/haftanin-yildizlari/" title="Haftanın Yıldızları">Haftanın
                  Yıldızları</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/cok-al-az-ode/" title="Çok Al Az Öde">Çok Al Az Öde</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kampanya/haftanin-cok-satanlari/"
                  title="Haftanın Çok Satanları">Haftanın Çok Satanları</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kampanya/gecen-ayin-cok-satanlari/" title="Ayın Çok Satanları">Ayın Çok
                  Satanları</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kampanya/sadece-online-ozel-urunler-a101/"
                  title="Online Özel Ürünler">Online Özel Ürünler</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kampanya/ucuzunda-ucuzu-fiyatlar"
                  title="Ucuzun Da Ucuzu Fiyatlar">Ucuzun Da Ucuzu Fiyatlar</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/haftanin-yeni-gelen-urunleri/?sorter=newcomers"
                  title="Yeni Gelen Ürünler">Yeni Gelen Ürünler</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/a101de-alisveris" title="A101&#39;de Alışveriş">A101'de Alışveriş</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/a101-gunu" title="A101 Günü">A101 Günü</a>
              </li>




































            </ul>
          </div>

          <div class="item ">
            <h5 class="hero">Popüler Markalar</h5>
            <ul class="js-max-length-list">












































              <li>
                <a href="https://www.a101.com.tr/markalar/apple/" title="Apple">Apple</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/adidas/" title="Adidas">Adidas</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/arzum/" title="Arzum">Arzum</a>
              </li>













              <li>
                <a href="https://www.a101.com.tr/markalar/birkenstock/" title="Birkenstock">Birkenstock</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/braun/" title="Braun">Braun</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/calvin-klein/" title="Calvin Klein">Calvin Klein</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/casio/" title="Casio">Casio</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/crocs/" title="Crocs">Crocs</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/columbia/" title="Columbia">Columbia</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/flavel/" title="Flavel">Flavel</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/lenovo/" title="Lenovo">Lenovo</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/king" title="King">King</a>
              </li>



              <li class="hidden">
                <a href="https://www.a101.com.tr/markalar/nike/" title="Nike">Nike</a>
              </li>



              <li class="hidden">
                <a href="https://www.a101.com.tr/markalar/russell-hobbs/" title="Russel Hobbs">Russel Hobbs</a>
              </li>



              <li class="hidden">
                <a href="https://www.a101.com.tr/markalar/seg/" title="Seg">Seg</a>
              </li>



              <li class="hidden">
                <a href="https://www.a101.com.tr/markalar/skechers/" title="Skechers">Skechers</a>
              </li>



              <li class="hidden">
                <a href="https://www.a101.com.tr/markalar/stanley/" title="Stanley">Stanley</a>
              </li>



              <li class="hidden">
                <a href="https://www.a101.com.tr/markalar/ugg/" title="Ugg">Ugg</a>
              </li>



              <li class="hidden">
                <a href="https://www.a101.com.tr/markalar/xiaomi/" title="Xiaomi">Xiaomi</a>
              </li>








































































            </ul>
          </div>




          <div class="clearfix"></div>
        </div>
      </div>
      <div class="footer-bottom">
        <div class="container">
          <div class="item">
            <div class="social-media">
              <div class="title">
                Bizi Takip Et
              </div>
              <ul>
                <li>
                  <a href="https://www.facebook.com/a101iletisim/" alt="facebook" rel="me noreferrer noopener"
                    title="Facebook">
                    <em class="icon-facebook"></em>
                  </a>
                </li>
                <li>
                  <a href="https://twitter.com/A101iletisim" alt="twitter" rel="me noreferrer noopener" title="Twitter">
                    <em class="icon-twitter"></em>
                  </a>
                </li>
                <li>
                  <a href="https://www.instagram.com/a101iletisim/" alt="instagram" rel="me noreferrer noopener"
                    title="Instagram">
                    <em class="icon-instagram"></em>
                  </a>
                </li>
                <li>
                  <a href="https://www.youtube.com/channel/UCFomZfoEfoveaRbIDjAtsZw" alt="youtube"
                    rel="me noreferrer noopener" title="Youtube">
                    <em class="icon-youtube"></em>
                  </a>
                </li>
                <li>
                  <a id="tiktok" href="https://www.tiktok.com/@a101iletisim" alt="tiktok" rel="me noreferrer noopener"
                    title="TikTok"></a>
                </li>
              </ul>
            </div>
          </div>
          <div class="item">
            <a rel="nofollow" href="https://www.a101.com.tr/kiralik-yeriniz-mi-var" class="title"
              title="Kiralık Yeriniz mi var?">
              Kiralık Yeriniz mi var?
            </a>
          </div>
          <div class="item">
            <a href="https://www.a101.com.tr/markalar" class="title" title="Tüm markalar">
              Tüm markalar
            </a>
          </div>
          <div class="item">
            <div class="title">
              Bize Ulaşın
              <span>0850 808 2 101</span>
            </div>
          </div>
        </div>
      </div>
      <div class="copyright">
        <div class="container d-flex justify-content-space-around">
          <div class="copyright-text">
            <strong>
              © 2023 A101
            </strong>
            Kullanılan tüm içerik ve görsellerin kullanım hakları A101 Yeni Mağazacılık A.Ş.’ye aitttir.
          </div>
          <div class="apps hide-on-app">
            <a href="https://itunes.apple.com/tr/app/a101/id1131194413?l=tr&amp;mt=8" title="App Store"
              rel="nofollow noreferrer noopener">
              <i class="sprite app-store"></i>
            </a>
            <a href="https://play.google.com/store/apps/details?id=org.studionord.a101&amp;hl=tr" title="Google"
              rel="nofollow noreferrer noopener">
              <i class="sprite google-play"></i>
            </a>
            <div id="ETBIS">
              <div id="79F43C1D5210486889B4F613E5B497FB"><a
                  href="https://etbis.eticaret.gov.tr/sitedogrulama/79F43C1D5210486889B4F613E5B497FB"
                  target="_blank"><img style="width:90px; height:110px"
                    src="data:image/jpeg;base64, iVBORw0KGgoAAAANSUhEUgAAAQQAAAEsCAYAAAAl981RAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAIiySURBVHhe7V0FoBXV1v4VOzHoDhFQ7EJFfdiiYiDP7kCfHWBgICgWdiMoqChKKQIqBnm53UGDNAoi3a5/fROcc9asOXfPnXvuvcD53vsEzlk7Zs6eb3asvfb/Magq8YwzziCJlStX0qGHHqraSz7xxBNOqvhYtWoV1axZU81Dslu3bk6qCCZPnqzamvKxxx5zcoogNTXVY7fPPvvQwoULHYsILr30Uo9tRfGEE05walE6OnXq5El/3333Od9GkJOT47Hz4zfffOOkio/c3FxP2t12241mz57tWJQPtmzZQk2bNvWU9cUXXzgWEXz88cceuyrAm5jboBlUGpOCEGuXFAQvk4JQ7kwKQlIQys6kIMQiKQgJZEUJwurVq6lGjRpqHpKVKQh77703LVq0yLGIoDIF4fjjj3dqUToqUxDy8vI8aSEIc+bMcSzKB1u3bk0KQqIYVhAef/xxJ1V8/Pvvv7TvvvuqeUg++OCDTqoIwgrCo48+6uQUgfZGA//55x/HIoIrrrhCta0IHnnkkU4tSsfVV1/tSa8JQmZmpsfOj8OHD3dSxceMGTM8aSEIf/75p2NRfmjevLmnrB1GEF566SX68ccfE84bb7zRU3YQQXjhhRc8eT7//PN0/vnnl8qLL77YalgyvcZp06Y5NYkgiCD06NHDk2evXr08dbrppps8dj/88IP18EtbbbgDO5le48iRI9X7+fTTT6v2kgMGDPDUx4+1atXylKMJAoZwWlkakV4rS/LUU0/1lL3LLrtQu3btVPuy8rzzzrN6crIsU0Fo1KiRep2JYP369T3lM+MLArquFYFXXnnFU3YQQZg0aZJjEUHv3r09dn5cv369kyo4ggjCb7/95qSK4NVXX/XYHXXUUc63sdh///09thpNe0dAgwYNPOnRYExQVFTkSRuEmiAEwWWXXabmW9VoKgh+v3si0Lp1a0/5zPiC8MsvvzjJEwu8zWXZQQRBa8Avvviix04jHrKlS5c6qYIjiCDgjSyhieHJJ5/sfBvB2rVrqW7duh5bjQ899JCTKj4ghPXq1fOkHzp0qGMRHxkZGZ60QRhWEK666io136pGU0E44ogjnG8Tj8MPP9xTPjMpCElBSApCopkUhIAIKwhTpkxxLCJ46623PHYaDzjgAGu5qKwYN26cmq/GsWPHOqkieO+99zx2YQXhjjvucFKVDixnyvSjRo1yvo2PkpIST9og7Nq1q5NT2ZAUhLKj3AQBb0S81cpKbaknrCDcfvvtnnIuvPBCj53GPffck5599llP+lmzZjmlxsfcuXOtpUMTYgJRltOhQwdPnYIIwuWXX+4p5/vvv3dSRbB48WJP2SCWUmX6nj17qraS6IXJtH5s0aKFp+6nnXaaJ8/PPvvMqXHp0ATh2GOPVcsvb958882esv0YVhD69u3ruU+m7Nevn5NLLMpNEKDqmq0pMVsuEVYQEkHTJa0gOOecc9SyJIMIAnooJkhJSfGkBZGvhCZSGlu2bOmkKB3XXXedmockZtpNoQmCtoybCMyfP99Tth/DCAKWxQ855BCPrSmxCqWh3AThueee89gF4c8//+zkFEFVFATTbnMQYIlTK0syiCB89913jkV8pKene9LutddetGDBAsciAlPfhrCeihqPOeYYJ0Xp0AThf//7n/NtYpGfn+8p249hBeGwww7z2JrST7STghCQSUGItdWYFITYsv2YFIQ4DCMI8NRDI5a2iaDpgxYEpuvmcKTRcOCBB3psTVcEggiC6fyLJlx+6Nixo5qHJBq/KTRBMF1hCYsggvDpp586qSJICoLDMIKwZs0aaxyON1M0sVIg05uyWrVqdPTRR3vy1JydMDGHpbayEp5xWh0k4RIs02Iy9+yzz/bUc/z48U7t4iOIIGDSTJajOTC1atXKU08/3nnnnZ48NV577bVOLUqHJgj4TCs/DDFxLKEJArwf27Rp47mm0aNHO6kiSAqCwzCC4AfTN5pG+CGsWLHCySk+4CKt5VERDOt7H0QQNLz77rue9EFo2pMJAk0QEsHbbrvNKTECTRDwcsFkowmSguAwEYJwwQUXeNKbEoLw119/OTnFRxB36PImHl70UMqKsIJg6tfhxyFDhjg5lR8qShDQu5HwEwTTHZRJQXCYCEHAxhKZ3pRBPBWx2UvLoyLoFw/BFGEF4c033/SkD8Jvv/3Wyan8UFGCcNdddzklRuAnCKb+K0lBcJgIQTBd39eI3WmmgmDqDp0IhhWErKwsT54QhCVLljgW8fH222970gfhsGHDnJzKD6YrF2GpCYIWYwGcOXOmYxEfSUFwmAhBuOiii6wxdjR33XVXT56Y9JF2Bx10kLEgwPNLpk8E8aaRdfcTBLhdb968uVTCvVvmCUHAhJlmL/n666970mv3E8Tn0vbrr7/25ImAIhJ4AKSdHzt37qyWb0qtnho1QSgoKPDkB69X0yhMSUFwmAhBwNgaP0Q0MVMu88SMr7TDA2G6lwHLnjJ9Ioi3qay7nyBg30KTJk1KpebDgAcCqweavaTmLYcZdVl3xIzQyoLHnMwTbUkCW6qlnR+xnCfLNyWCpmgrJxo1Qdi4caMnT8wfQKhMkBQEh4kQBA1anIGweVYUtIhJfoIQZv4kLE866SSnFrGA+7FmL6k9aNrQxo9hVy60cGcatXqGRVIQHFaUIGjj/dNPP935tmpjew6yijdnw4YNVXtJbftzImIqasCbHL0MLV/JpCA4TApC5SApCLq9ZFIQSmfCBQHbZTVbU2p7BBIhCNoy2VlnneV8W7UBL0lZd1BzeqmKgmDqOaoJAjwDNVuNYQQBaNasmZqvpOaYFBZBBME0KrjG2rVrOznFotwEAcstAwcOLDO1UOKmgrBu3Tq655576IYbbiiV2Bcv88TElmarEeN4CUQ8knaou8SGDRvo3nvv9dhq/Oqrr5xUEcBRSt63QYMGWdcvYSoIGC/LPINQ276sCQJWDjC2l+lPPPFET3pNEJYvX+5Ji8lDbVObJggIQqPdZ8nrr7+e9ttvP0+e2Bwly0dvU6Z/8sknnRLLBlNBALAVX9bJlH57cspNEBIBU0HALL+2nJgIavEQEEhF2mk/Is56wBKUtNUYdneeqSC0bdvWSVE2IEiHzFMTBD9gj4JMHySEmta91wThtdde89gFodaD/eSTTzx2WKEIgyCCkAjsEIJQ2dufNU9FbWciNmGhqyZtNWJ5NAxMBQFv6DDQhmBBBMH0oBYNmzZtUlcuNEEIu+cC/hISH374occOS65hkBSEOEgKQtmRFIRYJAXBDGUSBPi/VwS0bt7OIgiPPPKIk6psMPVDqGxBuOSSSzzpMR9kgp1FEKr8uQxYUdAmKsqbV155pafsIIKAOAFy0sd0UhFHjMGFV9omQhD+85//eMrHKUnyfmj757FMhg1C0vbhhx/25IkHVZatCQI8NLELUeb5xx9/OBYRmAqC36QiYh3Kej711FMeOy1UfVhBgHu6LNtvUjGMIGBFAF6m8prgxSihCQJC4su0iWKdOnU85TPjC0JlMoggIHiIRJBlR+3hTYQgaAFRtd6RtnaMPLVjwrQzKbQGrAkCVi3g3yBttZUPU0HwW3bUZru1EPSYPJQIKwjHHXec820stGXHMIIAgT344IM9tlrkY00QqgB3DEEwPahFc0zyOw4+EYKQiINatAdN24ikCUKQg1qCCILmmKRtf9Z2UGoxFcMKAiJiSfg5JoUVhOTpzwliUhBikRSEpCBUAKuuIGgPhZ8g/P77745FBNrmpiCCoK2wvPzyyx477UHDOFobo2lu21o9Mf8hgfGp9vCGFQSti6s9aGEFQTs8RnvQ/Lr3jRs39tia1hOxHzVoD68Wt0F7eOFOLAFB0EQbp2RLvP/++x67KsCIIEAtqxL/+9//OrcuAj9BwGk/ciuqtv05iCD079/fkyd6HbKeCK0u7bCFV3M3hYOLtEVYNpkn4jtIO+SpHakeRhDgUXnKKad4ytd6XGEFAfMF8po0Ry/Mfku76dOnq2KoCQImzOT1IICOzNNv+zN6LdIWn8k8EbZPAoKAnq20HTFihGMRAeZppF1lk0U3IgjoQlUl4uZK+AkCAorIYBWaR2MQQdDyxKqLrOfEiRM9dqDMzy9PCJfME6csSTtQyzOMIACybBC9EYmwgmD6GwUJuqIJAnpn8nqwpdo0T62eXbp08eQJatDstEAwWj0rm/zbRQTBqWeVhp8gmDKIIGiEIEhokYiCUHNM0uIf+jGsIJgirCAkgpogaEB0Iy29KbUgqzsi+EWQFISwghDkOHiNmiBo25/9mBSE0qEFnAnCRGx/rorY6QQBpw1LYEXAVBAef/xxJ1UEieghpKWlqbYatZWLN954w2MXVhC0MOyaIKDrWb9+fY9tImgayTmsICR7CFUUYQVB2/GHmXZTQdC2vAZ5eDVqghAkJoC2PKo9vH7hzkzxzjvvePLURAbzD9pMeyJoetZDkKArGm+//XYnpx0bZRKEjz76yFoaKivRHZbAso60034EP0HA2jMmjkrj4MGDPeVgjRoTRzJPjZjll+l9NomoRLdb1gkrFzJPuHJLOwxNtJULeNvJ9NobGh6J0i4ITfOE8CAmgay/RoihzFMjfp8ffvjBkx5vblk+fEUk4JEp02KeRlu5wKqPtNVcubFKIctOBI8//ni1fA3Ysq/lEYDBBQFvSZiXlZqffvfu3T12WnfUTxDCnG9YkdR8GzQ/BL8TkLUGXBVpehIWXi5aesndd99dzfPyyy/32AaJbqS5LmtzMhrCDkOCcOrUqU6p8fHBBx+o6QMwuCBUZkxFP0HQ1s01YIlQpq1IJsJTsapxjz32MH6jmR7+AkHQDlzVTm4yDTiDuQ6svcv0mqeihiCnP4chlkbhh2ECLZBLQCYFoSKZFIRYJAWhdO7wgoCxoARm76Udxk4aNGcWzS1WQ2ULwoQJE5yaRKDt+NMEAashpmHZKpumB55q1+5H7czEMIIANG/e3JPeVBCys7M9aRNBCMKyZcucUuMDLtJaHgFYPoKAG4ttvCbUlB5Ld9IOk20IHhJN7KnHG1XamjZATRDwkOGaZJ7wf5e27du399hpRN1xiKxMf9lll3muCT0haacJAt5o8P3XyjPhAw884CkHk3XPPPOMxxYbd6StRrj+yrRY8oRvhwQaq7x2rWyNyBO9QwlTQUD4eln2Qw89RAceeKAnvakgYE5Dq6spgxxUe+utt3rqrxGxNbSyTPnqq6+WjyCcd955zrflh8zMTE85oOYGagpNELB3X3OTxsMrbXv06OF8WzrCdO81QQgLzIrLchBfAcuuEtdcc43HViP2QZgCbUSmN42Y5AdTQfBrSxpNBSEssJdBKz8Mb7zxRif3sqFMy46aICASUHkDKweyHDy8pjPYGjRB8DsOHhuMpK3mqajBb/uzKRMhCEGOg7/iiis8thq1lSA/hImp6AdTQQiyIlBRgpCI7c9hz49ICgIzKQhJQYhmUhAcOJ+VCk0Qzj33XOfb8oOfzwB85csKrWFAZLANWKJjx44e24oSBGwBLm/4uVhrY3Ns6dZsJeGUZYpECIL2G2FnooQ2XPKjthKUCCCsmlZ+GJarIIwZM4YktdlNTRDg7SfTwlsNkW4k8KBLW41YQsGe82gi5DgCWEhbrdeAWWlph4kTWXeMozGek7Zwy5W2iRAELH3J63zwwQednEoHPOlk3UtKSpxvI8Ax7bIcPPjYDyDT49Qpaavx/vvvd3IvHaaCAIGS9fEj0ss64TeSdoiRIO0QrVqLUYkVL5k+EYRDmqwTNt/J+oCYeJa22hyVJghoi1r5GkePHh0RBIanAG19XxMEjVge1B5UbDDS7CW1bjMrmBohWVvK1IJvhGUiBAGRh8MAwT9knnfffbfzbemoXr26J73pMm4QmApCkAlA7XQtLRJRixYtnG9jYXq2YyKIlQMJrMBJOyw7ascfIr201QQBgXWkXRzGFwTN1dZUENAV13oYWgPWqDkmYTnrkEMO8diaxlQMy0QIgra5KQi08w6wpGYCDJW0N40WUzEsTAUh7OnPpjEVsbKkOSZVFO+44w6nJhFoDy8EAUMeCYSSl7aaIKC3KO3iMHGCgDVeTRAw36DZS4b1VNxZBEE7uclUEIIEWQ2LqiYIfp6KFUVNEAoLCz12fp6KlSIIWvDSnj17euw0QhA0BxU492j2klrsAjRgbcdfRQmC6Ym/EAQteKnGsIJw4YUXevLUHjQNfvdT64qHhTYBiLkKiSDRjbQVAW3rt98RaRUVt0GjNvmJTUyareZ4d9NNN3nsylUQ0IAlMTbH8dzRxFuSzUslhgzo6sj06OJqZUli0kemxRgrzJABnnlaWRrhPy/Tw9tP1kmbpce+Axy2YpKnJgh4e8ly/v77b9UpC6cqy3JM5yUwZMDDItNjklWWr1G7dj/cfPPNnnIweSrznDRpksfOj1rwUkxGSzuEypfl/Pnnn9bRadJW47777uv53fyIORmZHvs7pB2ciGSdEBpApkV7x8SxtO3cubMnz3IVBDQ4yQ4dOljHYEVTm9TTiK4OegkyPSastLIk8ZDLtLjZyFeWZSoI8KzTytKoDW1w7bJOEC4JTH7i6HqZp3YOoyYImFiT5WCsv3jxYsciAhw9L8vB/n8T+NUTx9vJ8jUG8T9Br0mWg/gQMk88vNLOj9oSNERO2iGWhCwHQ09sUJK2GrWQdBoRoBVDHple85eAy7ysE2JJyLR4+BGWX9pqIlOuguCkjwGOPsNX5clff/3VyT0+8KbQ0ms0FQRtXsIPpmvxQUKTaeN9TRA0nwH0bjQnokRAc9vWqI3Ng0CLwnTkkUc635YftLE5OH/+fMciPkx3EUIQtDy18b5GP78O7UwKjQkXBByiiq/Kk9r2Zw2ap6IfTQVBC7LqB81TUaN2cpMfNJHRBEELsoroRNikUxFIhKeiBtOTm8JCc0iDwOLMBRNoB8pohCBouzKvu+461V5Sm+tALw6Hwmj2kgkXBNMJwCCEw5IJEiEI2kSlHxIhCBiCyfSmggAnmooSBC0SkUa/Leqm0AQhbK9DQ15enqccPLymu2SDCIImMqaC4Oehqm3T1qgJgt9EpQ/jCwKCkuKr8iSGAiYIEopcc0zSlkcRN84Upv4SQR4KTWCxpVvCz/e+ooYM2sqFRr8j0kyheY5qR6SFBbw0ZTngkiVLHIv46Nu3r5peEoKg7YvBKWSavSSOltNgGjoPE7cS8+bNU219GF8QEP0Xb9+yEC7GWGlA1tFENxOTa6URnlhavhr9XJelHSIkS2ACDj+YLB/x6WR6jZ9++qknLZbYMCEkgdlimb5Xr16e9FhSknboWWl7LuCRKdNrNF2KBDAxJsvXiLmOMEBkJZknTq2SwKoLxuHadZnw+uuv95QDV11M9mn2kujFyfRarwET3u3atfOkx+SpTK/xyy+/9KQFsbyq2UtCYGVaP3dozIvI9D/99FN8QQgLzYnIlGHDhpsCS2daJCLNKUuDX+Qc0+69FmQVy2GmMJ3nwTLo9grsicHMunZdJvTrdWg+GBq1COAYbmi2GhHt2wR+eWquyxpwxqmWXqOWZ8zmJuezcgOWszSfAVMGWREIA7+Tm7TzDjRoJzdh3VpbItRgGlPRD9rKhcawB7VUJvyOgzdlWE9F7eSmIDEVtePgNQTxVNQQJKaiFsk5KQiMpCBUfSQFISkIoWewTRFWELQNKfvtt5+69VuDFmg0yPKoFppMY9gJwMoGJty06zIhzpqUgCBoMRU1hhUEPKgmwDBTpoUgJCLIaqmCgDeVpBYQFW9Eaaf5lPsJAiZyMElTGrFvQJYTloMGDXJqF0EQQcCkpMwTEXpkWniRIeCltNWoLUWiAWu2GuGmrN0/ySeeeEJNH4aIMyCBXYSYcJO2mOmXwCSrtNOI05hM5xDg1SevHZ6GEnADx9K0tMVci8zTVBDw8GLTkswT80wSWAqV14lAqVqeXbt29dhqxHEGsmxtmzRYqiAwPIm0U5ZQOWmHH0HCTxC0mX4NQfbFm1LzggsiCIgSLO0qmz/99JNTu/goLi5W04ch4glIwJ1Y8/3Xus0vv/yyxy4stWXcIMAeA5mnqSBg2XHFihWORXyYnkkRhFqQVSyDarZlEgTT7c+aT7ufICTCU9GUQY6D1wQBbyppV9k0PXosEcfYaZ6KEATtOHjtpOZEPBRaTMUg0HwGggiC5qmooaJiKvp5KiYFgZkUBD2PsjIpCLF2O7wgaN1RjEWlnTYrjq6Ttr4/btw4xyI+ghyJbsozzzzTyT0WONVZ2mqCoB05V9k0DWbit8EnDP0EAdt2pa22VVkLZhKWQcLHacDJ2zJPOIpJ+AmCqfdjIoKsajEW/DwVtU1YMYKAH1cSbxUJKJu00xQU23LhNCNtMRGFh700BlFQOJ7IcjR3T2yckeWgJ6I1YE0Q4PghywlCbVYbkZU0W1Oi/hJolPI6tRnoXXfd1XKC0vKVxClNMj0+l8DqCiZKZXqc9CzrBKcsaacRK07adl+sPEhbTMzJcoIQbVnmiclHCU0QcD8hfFq+kjiNSpYThFrvGx6yspwhQ4Z47EB8Lm2ZEUFwrjPhSMSGKW1LddgJK00QwkLzGUCU3/KG5v2oEfEdECjEBNrbHA3TFNoOSi1ikh+0LcBwj5cIcl6kRi0smwZNEILwdsX7MQi0iEnlwIoXBNNNQ0GoDW169+6t2poyEYKgBUTFqk15o0+fPp5yNEIQTN1itdBkQQRB64qb7q/AUqbmmKTNS4Qdhpi6GYcVBC2mYhBoqyHlwIoXBNMgq0GIjRkS2vbnIEyEIJjGQwgL0wg/EATTHZTYoCPTBxGEMAe1+HkqmgZZDULTk5sqWxBMg64E5I4xZMDONYmwgqCJTFho24oTIQjatmKNEATTSTBNZIJsJ9fCiCFGpQkqUhC0XoeGgOcdeKjNuwVBwnsIcOUsb2rAqTOIVlMaMWPL1fJQs9WGDGEFAbEftWuS1E6O9gMmfWTdIQhh8tSAt7ksR7ufEAR4o8ry//33XyenCLBEKPPE6pJM60dtyIAlQmmnXXtYQYC3n6w7iM+lLbYgyzpp9NvlakosEWr5atDstKArmNTUrlOjdu3MiCBgo0d5ErPXWkwAbPpBVJnSiK4bVyuG2CMAd1dpqwUVDSsIWIrUrksSDd0UeBvLumOuQ+aJiEVhAB8QWQ5mv+U1olFg9UCWr/WOsE1c5gk7mdaPmvci4mVIO6xQSIQVBOzjkHVHRHBt5QQ+KbJOGk2DlvgRhwzLPLEvRQLiDD8faYtnQeaJSMzyOv3oszckIggMzaDMxDJRmJOatYhJWLZD9F4ThBUEUwbpNmvQVgQSEUYsyJjXdKZdC00WllrchrCCoLnWA2E2TCWCmis4BEETLo1BhiHang1m4gQBD6/pLi0Nmqci3iimIlNRghAkpqIGbEqReQbZ/myKIJ6Kps5OWLvW0oehFmQ1rCCE3f5cUUxEkFU/IMKzkkdSEMIyKQh6HmVlUhBiscMIAhhmcsyvAZs60lSUIIQNG6414EQIQpBZcS1orQYE7tDSh6GfIGhenpo7NGJcSju/YV1lnv6sEaKnwfScUM3F2g+I8KzkUT6CgMyxvTWacPO95ZZbrNnQshBr1DJPOI1ogUY1mAoCZtpxhLgsCw1T2sKPQNrhsBFZd+xBx8SeBJYDpS3Gt7KcsIKAbeuynHvuucdTdz/C/Vem16gto2IGG05MMk/EyJS2GjVBQOwCnDcp89TqichQMk/EUpB2OAJPm5iD96Qsxy+mgCRm+bE8K9OjFyltMVEo7RBHQtYThNu3tNWIzXdaeo1aAGRm+QiCNjsK+C0dmjCI04sGU0HAjcEbSEI7vQg7PSX8TivWgqxic5VmKxlWELRr94v5r0EL2mJKTCZjB6kEHkDNXjJIj0s7QDYsNYe0zz//XLWVRHvXVtY0QdGcshCFWtqBpr4iQYKs+rB8BCHI9mdTho2paCoIWP7RYulrB7Vox8EHialoejxcWEHQnIiCxFQ0PblJIwQBDVtC81TUGEQQNGensNQ8FRNxclPY4+A1BImp6MOkICQFwYukIMQiKQgBmQhBCDtkCLK5CXv4JTQXa20jkt8pS+vXr3csIjDd2BXkyDkN2r6Dyh4yaBu7NAYRBHi9anmEoTZkwPhcs5UMIgjakAH7SqRdEEHQnPkCsmoIApaFMEMaTfi5Y0xUVvbo0cOTp0aM7xB7QaZ/+OGHPbYInCrtMIEm7YLkib3+8n5g9lumRaNcu3atc3cjwNZvaduzZ09POZgsk3Z+RFxCmd50UhCTithtWdY8gwgCVmhknuhdyTyDEAFWZN2Rr2YrGUQQMJ8ky3nhhRc8dn6CMHHiRE96ba4CqzPyHvnxhhtuqBqCgO69RNg17iBxBrTITtqhtNowRFs7BtA4pK2250LbVuxHRL+R0I7q0sKIBYmYhH0cEqbdZj9ilUBCC4Ljdz9NUQ7d5jIziCCY0k8QTA/kDXI//y0thJopwwoC3rwSYWMqItSbCdC9RT3R1a1evfo2arEf0RWPtgFxfp4E3uRw/JC22h4BbBrCspikTFu3bl11XuKaa67x2CKEvQQ240g7P2qCgLMutXr6UeapxX7EcppMF3buCAezyjxNufvuu6ttyZQVKQim25+DHOGXFAQG6okGizfY8uXLt1FbisS8QLQNiE0/EvAuW7FihcfWNE+NWM7CerwEQtVJW21oAc88aedHbU7FtJ5+NM0Tv0cYhKknxF1rS6ZMCoJDzX0XD8Q+++yj2ksieKkETgHWbE1pGp8fDQHChYM2k9i5EdavAYKgRaC6+uqrVXtTaqs2cPrTbCXhnm2KGEHAzq+yEgooga44Jsyk7d577+2pNCa8oKzRxBtbpkVcPW1sXqdOHY8tdhGaAG8kCJqm7EnsXMBSM04sl21JY/369T3tEG3z999/97RlLDHK9NrJ0xi2SjtMME+YMMGTp+Y4hyV0mf6ss87ypPXjzJkzI4KAfQdlpdaVBTRbbelt1113tW5mNHEhMi26zdoR83DVlbZ+ddIA+50FuNIFM2bQ9PR0mpGZSTOjOMvhbIdzHM6N4h8O5zmc73CBxQxaGMVFYEYGLXa4xOFS5rKcHFrJb76qdOfxYkCQVtmWNPp5qMp2DMLTUabXJmmxNCztMNTDfJTME0MJmR6rDDI99rDItH7k5zAiCM49SThMDyfVDlXB2FgTBG1FIIkI1vK4OuuXsfTFk0/SC+eeS/cefDDds9dedN8+e9ODzIeZjzK7cu/tceZTzKf33oueZfZg9mS+yPa9ma/stSe9xnyd+Sbzbea7e+5JHzA/3HMP+pj5CbM/cwBzIL/1BjG/2mN3Gsz8ljmUOXz33WnkoYfQ+PbtKeehh2jhzz9XujhAEDDRaYIgm8UQhUlCWw3RjhoE8KaXtho1ZyfMP2i2Pqx4QTANsqrNNmMCTxOERMQ/3BGwYM4cGty7N3U76US6YbdqdB3fq1uYXfhhvIcf4Hv5gX2A+RDzEeZj/OA+znyK+TQ/tM8yezB7Ml/kNL2Zr+y+G73GfJ35JvNt5ru77UYfMD/kMj5mfsLsz/yMOZDfPF8yB1Xblb5mfsMcwhzGHM51GeHwe2bKBRfQ0pQUp/YVDwgCVlNMECTgDHxIJEyXXDFBHWb7s9/JTT6seEEw9dZr166dkyICzKhrh6qYHni6s2DJwoXUv3t3urVWLerE9+d65m38lr9z332oyz770D3Me5n3c6/gIeYjzMeY3bhn8ASzO/MZtn+O+TyzFxO9g5eYr3KPoA/zDeZbzHeY71m9gz3pIxaVvsx+zE+Z6CF87tdDYI5gjmT+wEIzatdd6Aeu549cxmzD49PLG6eccorVlTdBEL8ODBkkgvhgmAoChgwSVV4QTKMua+67iJ2o7YtPDhlsYNZkZL9+dGujRtSR78s1/Na+iUXgVubtzKosCKO5p/EjyPUG53zS176oCgQ8J00FIciDph2brwmC35ChRYsWHluNN998s5MigoCnfidOEPA2h38CglNEE2qJQKml8auvvvKkRZcO/gnSFmuy0lajpqAYhsAnHtGHt2egV/Bsp050Mf+UnXbdla7bd1+6gbm9CcJPIF/DL5zvsilTnKurGOAAVJyopLUdSQRuxWMTTUyOw6lLtk8sbUtogoDYHFpZmictluplOVobhl+GtPNjQo9ygx9CmMNetSCruOFahGUIj7TViJsrgR8LvQ4o6faKQv4xb23dii7ka+zMD/Y1LATbsyCMZf7M15LBvytmyisSprsyNWKm3jR2gSYIQWgaCDcIYvwQnM/KDX6eimGOg/eLqWjqYaatXGApEyG1teOxtwdk8H3qVKsmXcTXd9V++9J/mTuCIPxSbVcay9e0UDm/MZHQjoM3JQQB6/kmCCsI2jAkLJKCwNieBSEvLY0ur1nT6hl02n+/HUoQfsWffF05na8i77ExiUNSEBw4n5UbwgpCZmamJy2oBTMxFQRt0mZ7FYQF8+bRtS1a0Hl8XVewGFzJQrCjCcKvfG0TatWgNUo4ukQh7BFpppHGwwoC0pc3ShUErMkikGU0TZf4gggCPpPlYHMSgpJGEwFNtTkETRDOPvtsT3pMVEpsj4KwicfV3S67jM7i67xs//3pchaBHVEQftutmiUKC5XfLRGAs5BPeHIP4S4v2xeIIDqyLWPCTsJUEOCRiK38shw4Rklg3k2W7UctenmpgoCoRfgqmqabhoIIAi5Y2mEfhCk0QUCQEBNsj4Iw4NVX6Ti+xvbMc5nnMzFs6MC8hIklx8uZ8EHozLyGCaekG5j8i9OtzNuZdzLvZv6PeR/zAebDzMeY3ZhPMJ9iPs18jvk88wVmb+bLzFeZfZhvMN9hvst8n/kh82PmJ8z+zIHMz5lfMr9iwjHJSBDwJ9vPUHbDJgLwfZHtyI9+p0Fpbb5fv37OtxEEEQTTXocW0t+PmqCUKgh4y+KraD777LPOt/ERRBCwhCLtguyL1wTBdPvz9iYI2DTW+5576AnuITx79dX0HPP5q/9LPZm9mC/wGLg38yXmK8xX/9uZ+jBfZ77JfKtzZ3qb+S7zPeYHzI+YHzP7MvsxP2V+xmP3AczPmV8wB111FX3NHMz8ljmEOYw5nPkd83vmyKs60SjmaOYY5k/MsZ060S/MXztdSb9zPr9d1pGGci9mGL/9TQUh78YbnKtPLExjXoJt2rRxUkWAFRHNzdjUU1Gj3/ZnDUGCw2jtPSkIjO1NEIJs2qqKwAThpBtuoG/5NzIRhN/YLqttW8vpKtFICkIpgqA9aAheagL4ISC+nkyPrZwSmiAEiRKMnZEyvWkINfgh4MAOrQuVRGKwYNw4GrLHHjSChw4mgpDRqiVtVgKslDe0duRHPPgacHq0tMUBQxKmgVtB05cVDhzS0mssdcgwZswYkkTAS/4qhoh9IO3S0tKcLCPAKc04nhpegNHEbjKZHgFRpR02akg7P951112e9IjCJO0w6SIBj8rrr7+e5s+f73ySRKKxbuVKGt28GQ3j9mQiCOktD6fN671RrMsb6P3KduRHtBnZvhCxGcuW0vaNN97w2N5///2eZwsvJpkWp2Nph/5owCY/md6PWnuPEQSGp4KmhA+4KbTTi7QQapqnoh9/++03J1UEWhh2v4mgJCoW8D0cy+3AVBAyWrakLRXQQwiCGTNmeNoXqMW9NPVt0IYhFYlyEwR0tUyhbX8OG1NR2/6sRUgOe95BEuUDSxDatTMWhEx+4Wz9tyLdk0pHQUGBp33BtX727NmORQSmMRXDRpwOi3ITBC3Iqh8qUxA0T8UkKh4rFy2i72vVouG7lC4I1irDDRWzyhAEWjwEP0/FnU4Qgjxo2kSldohqkCCrOKxE4pVXXvHYhQ3xnUR44D0/pUsX41UGCMLMHj3sxFUImOiT7QuCoI3NTSMk+21/riiUSRAQJBVBSqJ56aWXOllGwJlbS3qYxY+mNpMLZydpN3LkSI+dH7/99ltPevQ6pB0CYEg7l9v7cl5VB4RgOb89J95yM33Dv4WRH8Kuu1hDhiVjxtiZJBjYCr9hwwbnXxHgM9lecHKSbF8QBHglSlvTMygRMl2m9aNWTw1YCtXSa1y2bFlwQcCBp3jQo4mZegncXCzNmByGgX3g0g4RZKWdHzE7K9Nr0Z2xDCrtQETA1U5FCoPNLDAYT04cN476vvcePfPwQ/TonXfSffy2uKtzZ7qzUye69+qr6bFbb6Un+fOn7rzD4tN32HyG+Ryzh8OezF533E4vMF+8/XbqzXyZ+QrzVeZrzD7M15lvMN9ivsN89/bb6D3m+8wPmR/ddht9zOzL7Mfsz/yUOYA5kPkFcxDzq9tupa+Z3zC/ZQ7leg5jjmB+xxzJ/IE5ijma+SPzp1tvoZ+ZvzB/Zf7OHHfLLTSR6/7L5ZfTt3yf4ak4lMXAxFPxF7ZNad2KNq5Z49zVxAK91/79+zv/iuDTTz/1tBlstJPtC8Tn0hbRlDVbSQiKTOtH7VBaDfBh0NJrrF69enBB0M5Q0ADHpCAPdWWzPM5lQBDYn/ht1vWBB+giHkYd3aABNdpnH6rLb7o6XEZ9ZmNmE2YzZnPmYczDmS2ZrZlHMo9iHsOEe/IJzBOZpzDbMk9nnsHEPga4Lp/DxAYnzXX5SuZVTOm6jLiKtzE11+WHmH6uyz2YZXFdHsCE6/LXzCB7GRATYeqTZg5m5QH4vsD9VwKRmLU2U5nEWY4mKHPEJIZm4GFYT8WqSPRawkRMQu/iRR7ntjv2WKq95550MOdZh9W+EfdSmrEotjhgf2p54AHUmt8eRzLbMI9iHsM8jnkC80S2OZnZlu1PZZ7OPIN5FvM/zHP234/OZZ7PvJB7RB2YlzA7MnfEzU3Y+jyhdm1aXc49t3jwC7Ia9lzLRNB0+3OZYyoyNAMPTQUBQ4YdXRDgfNW7Z09q1bAh7c/51OAhSUN+eJsceCA1YzZnHsY8nMUgKQgBBKHarlYYtdlvv+3c6YpB27Ztk4IQBc3AQ1NBwGSGFjK9KrIsgpCelkbt+Y2yN6evyQ9DQ37wGzEbM5OCEE4QxvA9zbryCtpSwRO98MzV4gzgAFmt3VQmTQUhyPkRzIggYNORCbFECF+C0gjfBG0C8aWXXlLzNeGIESPUqMsacZ6eTP/666+rtkEFYcg331B97v3sx2nrcX0aMJOCUA6CsFs1GsX3dPJpp9I6wy2/5Yn09HTq0qWLpy1jFUy2Jbjga21JI/bVyPSmRPyRevXqefI0FQT0YrV8taPomBFBcNKXCggCzMtK+BeEgXYmnkbsj5DwO34riCAMGzqUDuKHpzo35HrVqycFoZwEAecyjOTfYjK/SNYoB6ZWFK688kpP+0AkZglMQks7Pw4LGRdSC9oSNoSaFjWaWfGCAHUqK/xObtKobX/W1o5BU0HIyMigulz+gdyI6x5Uneryw54UhPCCgFObwKw7bqcNyhJ2RULbd3DXXXc530YQ9uQmU8CfRzuoJawg+ESGSgoCaCIIWFI87aSTae9ddqE6LAZ1qh+YFISQgoC9DODPTZvS7BAPTXkiKQgOHLtSsb0IghZCTduQApoIwut9+tAebFuLH/DaLAZJQSibIHzDQwN4KoKjGjWivO7daY0S36+yoAVZ3REFoXbt2p48mRFBwGSfpPaQJEIQJk+e7ClbOzE3iCBgUlPmiQkjzbY0QUDo98ObNaP9uWHX5Ae8Fj/ctZl1+EGuy6zPbMBsyGzEbMxsymzGbM6EH8LhzFb8YB/BPJLZhnk081jm8cwT+EE/iXkKP+Btmacx2zHPZJ7FPJsf9HOY5zEv4Af9IubFzEuZl/GDfgWzE7Mz82p+2K9lXs+8kR/0W5i3Me9g3sUP+93M/zHv4wf9QebDzEeZXfmBf5z5FPMZftCfYz7P7MXszQ/8S8xX+SHvw3yD+RbzHeZ7fF8+ZH7ED3xfZj/mp8zPmDjs9Qu+xy6/4c/GnnUmFb7+Oq02PNSkojBkyBA6+uijPe0jEYKQm5vraZ+IeCQRRBDy8vI8efoRPWh4HUeza9euEUFgeAodPXq0U1QEiRAELcjqUUcd5XwbQRBBCMLSBOGtN96w7PbdbTfaj2333303OoB5IP+7OvNg5iHMQ5nwRajJrM2sw6zLrL9bNWrAbMQPRxNmU2Yz5mHMw5mtmEdU25XaVNuFjuY36DE8LDmOeQLzJObJzFN3+T86nXkGU3opXsDEQS04xu1S5mVM10vxv8xrmTjw9UbmzczoIKv3MO9l3s98kCmDrHZnPsOEl2J0kNVXmK8xX2e+ydQ8FfsxcRz8EO4J/HzRRZTTqxctTkujzc59rWrwC7KaCEF4++23PXaI5CwRRBCCBFnV4jZwWfEF4ZdffnFMI0iEIJjGVKwsQRj1ww/00Qcf0Geffkqf9e8fwwFRHCj4ucMvHH4ZxUEOv3L4tcPBDr9x+K3DIcyhURzGHM4cYbEffcf8njkS7NePfmCOcjjG4Y/Mn5g/M8c6/NXhb8zfmeOY45kTmBMdTmKmOJzCTGWmMdOZGcxMZhYzu98nlOOyb18q+eorWsQCsHr58go9bKWs8IupmAhB0GIqBjkOXhOEco2pyPAkSgpCEjsTkoJQiiBogUcSIQhPPfWUxw5nQkgkBSGJREKLMg5qgoA5AM1WoyYI2oapxo0bO99G4CcI2PIvgV2Z0s6Pf/zxh5MqghhBwE4vSXhuSWiCgC2fMi1OWtaiLmuCAGWT6e+8807n2wj8BAHn58v0Pp5YKpOCkATw0EMPWfE9ZPvQBAExFWWbA7UTzzVBGD58uCctljwl/AQBzyGez2i++eabnjz9iHgjMn1aWlpEEJzyS4UmCFBWCZxLrz28miCYwk8QTCMm+TEpCEm4uOaaazztQxMEPzRr1syTXhMEU/gJgsZbbrnFSVU6tPMjmOUjCFpMRZwwZHpQiyn8BEE7b1KLuuzHpCAk4QJ7YGT7MBUEPLymB7WYIogg4OgCU6BXreSROEEIcnKTKfwEwTTIqh+TgpCEC1NPRQ1BTm4yRaIEodw8FbUVgSCCoHXvTQH34aQgJJFIaIJw9913O9/Gh58gaKeOB4HP29zDO+64w0lROhC/UckjIgibNm0iE2rBS4MIApydtHxNiFNwdzZBQPDX30aNou+//JJGDx68jWOYPzr8ifmzw7HMXxz+yvyN+bvDcQ7HMycwJw7+miY5nMxM+drmFGYqM42ZzsxgZjrMdpjDzHWYx8xnFjALmUUOi5klzKkOpzGnM2cwZzqcxZzNnONwrsN5UZzPXMBcyFzkcHEUlzhcyvyT+ZfgMuZy/P2jD2m1cspYNDRBwIMm2+LmzV73Kj9BGDBggCe9KTdu3EjNmzf35KkRcwhaHhpLHTI0atSITFi9enVPRkEEoVatWmq+JmzYsKF1GIbMc0fvITx5441WrMXTqu1K7fj6z2T+h3k281zm+bvuQhcxL2Zeyrxsl13oCmYnZudd/o+uYV7HvIHJv3jc4+DjxVSMdxz820x4K/rFVMSR8HBdRpBVK7YicwhzOHMEE7sdf2COZv7IRDxFhFFDGHZEXh7HHM+cyJzMTGGmMtOYGcxMZhYzm5nrMN9hIbOAOaN5M1pXyjmJmiAgNqhsiwjIKuEnCHiJyfRBiPYp89SIYMNaeo0+eUYEgaEZGDGIICSCO7ogZKWk0Bl770Xt99yjXPYy3MO8l3k/5/kQ8xHmY8xue+1FTzC7l3kvw27Ul9mP+SlzAPPz3XajQcyvdqtGg5nfMq2oy8wRzJHMH6pVo9Esdj8idBoTIdR+Zf7GHMccz5zIwjeJxS6FOYWZykxnZjCzmNnMHGYuMx9k8SvclYk/+TeedeQRtMHgN9YEQSPG9RJ+grAdMSkIYFUXBODpW26mk7muFxywA0dMYkZHXcZBLeOY45kTWVQmsXikMKcwU5npzAxmFjObmcPMZeaDLCIFEAa+ZzNPPpnWGx7mayoIQY6D346YFARwexCEhdygr+RxXzuu74XchU0KQimCwPcJnH1xB9q4fLlzF0tHUhAi0AyMiBORNGgTgIkgtk9LBPFDALVDOqsasqdMoQ61a9OZXN+kIPgLQh7fH3BBt26BA7WaCgLmsyQgCJqn43bE4IJwxRVXWOuq0XzrrbesAy2j2blzZ9WNE1udZXpTIvqtdvhL+/btPeU/88wzah4aBw0aZAWj3B6Qm55OV7dsaR3W0oEf0KQgRAQBE4pgcZPGtHz4cOeOBYMmCGhfss388MMPTooI4DOAQMDSFuc9yDzRq5Z2iFMg7XbZZRd67bXXPLY4T1Xa4phEaRfEY5cZXBBQaYkp/ObSbDWmpqY6qcoG0yCrEJ4dFUuXLKGet95K5/KDdC5fa0d+KHdmQcAKA1Yacrh+c//3P9qwxLvX3xSaIDzwwAPOt2XDrfxbyTzvu+8+59sIFixY4LGDIPypRJRC4Fdpe8899zjfRoC4B9IuDoMLgnYuw2+//abaakyEp6JGLabijoYpv/5KXS/qQJfww3w+X3PHXf6PruIH9Bp+2Hd0QZjC14olRyw9ZnN9p1/ViVZmZjp3puzQBOGuAHsZNKDHKvPUnIgKCws9dhAEnM8ooZ0orXkqVspBLUlBqFzkp6XRh9wjuvv44+gqHlK5ZzsiYtLVTPdcRxktqQtT+iA8ypQ+CM8y4YPQk/ki8yVmtA/CW0xES3qP+QHzI2ZfJiImfcr8nAkfhEFM+CAgniJ8EIYy4YPwHRMh2HEmg+uHAB8EHPYKH4TfmfBBmMCcxIQfQmq1apRzRGua060brczJsW9EOSApCBFoBh6+/PLLTlERYBig2WoMIwhAzZo11Xwlw3bztkesWbuWirOzaXT//vRp9+70/CWX0JOnn0ZPn9GOnmX2YD7frh31Yr7I7M18hfkqsw/zDeabzHeY77Y7nd5nfsj8mPkJj1n7MT/l/AYwBzK/YH7F/Pq00+gb5rfMocxhzBHM75k/MEczx5x2Kv3I/Jn5C/NX5u/M8cwJPMaedGpbSnGYykxjpjMzmVnM7FNOodxzzqbpDz1EC955m/5OSaGNCQjZjjky2ZbwQIfBpZde6slT25noN2RATE8JbcjwPx4uSZR5yHDTTTeRJGK88VcxvOyyy6yTZ6P5xhtveNJiG6k2qagJAoJNyDw14tw9bVIRp+vI8rUAEkuXLlXzRfQZ7Uj7HQFbSiHm4LXPTamldz/Dn+XJRIdhg1s9XiSyLaGNSPz999+edgQXZezylcDZkDJP9GBl+hdeeMHTtiEIeAlLW22iElHGpF3A1baIIDh1j8EFF1ygJfIwyLKjJgi4OdIuCE1Pg/r999/V9OD2sOyYRGKBEGZa5GMNfqeAad17Df25F6elr2TGFwS/kFKSQRyTNEHQdlAGoeaYpCHsyU1J7NjwOw5egxZTsVq1ajRr1izHIj60mIpVgElBAJOCkASQFIRSBEFzftAYRBDGjx/vWEQQVhC06NAa4k1+4vDOnR3r1q2jfBZshF3PHDKEli0sn0NXVy1ZQjOHDaOpnO8fLN4bqqgTWNu2bakf19EEfkFWMTFogiARkiuQ8QXh+uuvt3yzo3nQQQd5MgoiCJh4gYpGEyc1y3Lq1q3rSYutz4hMK20HDx7syVPjd99950kLInqM6Q+5o6JwwgTqfeyx9Mguu1hLj12ZverUoXHvvRdqMi+/b18aXK+etfT4JRPLjqPbtKH5IQLlJAp4AeIIQNlutFl+hDGX7QhxCyZNmuRJr/Gdd97xpA9CbXIdn0m7Bg0aeOxAfC5tmfEFAcE54J8dTbgEwzyaQQQBDzW6VtFE0BVZjjYBiOjOS/htI20x+Snz1IhZWJnW5c6MktQp9MiBB1gnNz2+556WY9LTe/Gf/G/4I/z2eh/HMhhyufsNXwSIwVe7V6PBu+9G3+zGf/K/h3IZC/k3rkrAuQxa+9QiJsFNWbYhN5iJTK8RUcVl+iDEy1o+H/CIlHaabwNYVFTksWXGFwQNYUOoaYQgSEBppR0EYcWKFY5FBFh2lLYaMUZMIhYbuBG/fEY7yzlJ81R8btddqCe/eRYWFzspzLCM34KfH3yQFRxF81REgJSfjz+ONvIwparA76CWIKHJEHxEy0MSfgRhoB1Kq9UTqx7SDkQYeQkWueCCEDbIqkZNEDDXIO0gCFr3DdFrpK1GdAmTiMXUlBS6n9/aj/JD6+e6jJ7C2N69nRRmyHzzTSti0uf88GuCMKzartZR8IsneOeUKgtBTm7SgLcsut5aHpJBREZDWE/FUk9ucj4rFZogYJeVBBw0TAUBwxCJCTymlXYIEaUJQrKHUHZM+OJzy33ZipjkIwg47HXw1Vc7Kczwy7XXOIKg72UYxsMHuC5P/fhjJ0XlI6wgYBiBOS4tD0ntIKIg8BsySPgJguYvUW6CoJ3DiAjJpoKAPCW0IcPe3FA1QTBdHvVzoNqZMf7zgdbpz6UKQuernBRmGMv2JoJQYrjMVxHwE4QgDy/iJGh5SIbdH6EdKHPzzTc730ZQzEM9aQfOnDnTsYggRhBw9JoJsbkpKysrhognIO1wzr52lJvG2rVre9LjwAxZDpZ6tGi3GA9JW43Tpk1zUkSADVOYlNxZ/RAKf/+N7sXKwp7xhwxjlF5cPKS9+KK1wclXEKpVs4YMC8aOdVJUPvBig9esbDevv/66p31qxHmk8ImR6S+88EJPm4cXr5aH5PHHH6+ew4hlclmO1oZxgpq0Ay+66CKtvIggMDyV1qjtdtTe5mF58sknO7knFsuXL6cDDzzQUtKdEWvXrKHnjzna2u3YbZ99PILQY7dq9ByLxezMLCeFGZYUFNBnnM9AFhtNELDbcUzLw2k9C3JVAfwQcGCqRBAnokWLvL4beHNrtqbUxvth4dOTKR9BCLL92ZTaMCQRwCaVevXqJeSmby/IGj2K7t99d3qY7/u2qMt770nPVNvV2gr9w5NPOpbBkPr881YvwQq/zkMELDt+C/K/sQV6zogRjmXVgJ+nIjYnaW1UEsuJ8DGQ0LY/m9Jv+3NYlHpyE0Mz8DApCDsmUocMoacbN7Z8EeCYhLMZnuY3/A/dn6LNW8rmp4F4hmk9e9IX++5rncsAxyScyzCibl2a/kXZjzdLFJKCUAZBeOyxx5wsI0iEIBx11FFO7okHvLYwG7uz46+FC2nSwIH0w0sv0W/vv09zyinwyNK8PCrghyqz94s09bPP6B9lTFwV4CcIOGZda6MacbqYxFVXXaXamhLb9ssbrVu31sqKCAImTkyobTXWBGEv7nb26tXLk15TpvPOO89j98033zi5lw4oOM72j6YWBBPqLe3ghYY5BG3WNYmdC36CgI1Msn36ES9M2ca05yAItTw1fv31106NI4CYaLbaFgRmRBCc9GWCJgg48k1Dhw4dPLYI4hAGWE6Ued5///3OtxH49WTQ1Zs3b55jlcTOCj9BCAJtqT3Iy02DaZQwRDqX8HNd9mHiBAFvXa37pDkRaZ6KQaB5KmoxFeNtf9bqmsTOhTPPPJPe56FSWeHnqYhw6GUFnJ3CHAdf5piKTvoyYXsXBEzc3HvvvdbyUjymKScHY7OVtMPSFbYSS2CNWtpqYenRzZN2YTk8wDkFY8eO9aQ3jUqFDXHwS5Hpq1pEKtQTx7RH17FZs2ZWJKOyIikIDtBYkIUkjp2WaNeunccurCBoHmZBBMGUEA2JX3/9VbXVYjRqHpVaLP1x48Z57MJSO5zUD5poawE8/SDTgtr6fmUDQ0VZzyDCqUHr3ocRGcBnRcBDrS3Nnz9ftfVhcEHAEsioUaNiCHWF51M0L7/8cho6dKjHFi6b0hZ7GaRdEMLLCpcQzUQIQrdu3ZycIoBDk7yejh07WkFeZT1POukkT57aqg2WQGWeQdiqVStPOSeeeKKTe+nQIg/jmuT1aPz++++tUOayTrj3JoDnqJavRs0JSIOW58iRIy1vWFlPrChIW1P65Ymt/CbA/h+ZJybHtdggGjE5L9OjdyLrA+67775aHsEFAQ8azKOJyRgJdMm0qMuJiJiksaIEwQ/YiKXlIakJQlhgHCzLCSsIQRhmPiYzM1PNU+OXX37ppIoPuOpq6bXlvLDXjiFkWaGFZQtL7QxKQHtpMIMLgun2Z6iydvBlImIqaqxMQcDGrlq1aql5SCZCELBUJcupKEHABG2YFRu/aMYaTWfvtXBnGC5oYfO0g1pMieAqYeZKAq4IGLFly5ZO7rEo1THJsSsVYeMh7AyCgINjsWFLy0NyRxOEPfbYQ92MY4qKEgRsvNMe3jCC4OepaIrtUhDgZAHzaGKyTAKz7FrcN0zCSWwvgvCkoU8/JlNNjwWHk0h5AwfnyHKw+9QUnTp18qQ3ZVhBKCgoUPPVaDoB6Ccy2sMbVhAwiVdWYDeulm8YYtVDQ5MmTTT7iCBg3GfCrl27ejJCJCJph+4YlnHQS4gmAp1KWwiCtEN0JFkOlgfxoElbdFOlbSIEAc5Osu4a0WWGMst6atT2hgQBJqJk+Tg+XJZzzjnnOCkiwJIW9nLI9H5xAUwYRBCwNVeWjd9I1h1Ed1yWhQjJMr12rD/evDI/DOm07cKaIMDrVqaH4520gyBgDkTWyZQ4RV2WE5Z+MUCwm1ja8rMVEQT4DZgQN4fNY4jul7TD/gCIAoYO0URjk7ZYdpR2mCGV5aDHAVWXttpyXiIEAZOksu4acQQeVmNkPTXioQgDBMqQ5T/yyCOecrRlUJSNySWZXhNYUwYRhI8++shTNiaoZd0RFEeLHrzPPvt40j/66KNO7hHAP0DmCWLiW0ITBJzDKNNOnjzZYweijco6mRLDOllOWGpHywH4XNryyyEiCAz1AstKRDfCxKJE+/btPbaaH4Lm24Beg5anFoAiEYJgyor0fMQSkiz/wQcfdL6NDwhCjRo1POnDMIggaEObI4880vk2FqahycJGItIEQVvfD+jwY0SM6ysTMRGTGGoly0oonvZQmHoqhg2yWpmCgDVenLpbEdBOFjadl4AgYOu3TB+GQQTh7bff9qQ/5phjnG8jwJyMaTTjIA5UGjRB0EQmEUuEOFuyMpFwQUA0IglTQdCCrIYVhEREdtKIrmyY9egg0ATBtIewYcOG7UIQEDavogQBG4RknlpMxaQgBCQmXdDgJLTuPU7LkcjIyPDYBREEbbLOz0ElEfQbu5U3tPupdXH9UL9+fU/6MAwrCPA61eAzK+6hdqhKEGgCi+PbJXZKQcC59PAbKI2vvvqqJy0mGhGeHT2CaGI2U9piaUTaIWCltAsiCGhAMk9M2ki7sESgCXk/MCF62WWXecrXCLdvCYxPNVuN8EqU5WvBZOEOLdNiMlbzJoUrucxT47vvvutJG1YQMCmn1VObzO7evbunTmizMr1GBNbVhnV40GWeWrzNyhYE7Tr79PGesIUVL2kXh/EFQduJpyE9Pd2TNhEMIggVRb9Qbz6+4h5qG6b8ZrA1jhkzxkkVH1jS0tJrND1NGyIj04YVhCCE8EognoFmqzFMUJzKFoQrr7zSkx4rThJljofA8BiYnqrsF3ikvFkVBUHbxxHWUzHeKdWS8OswQRDRxqY0E2jDuooUBM1TUeu1aPTzVDRFZQtC2JObfJgUhLBMCkJs2qQglJ1VXhBMg2L89NNPnrSJorZDTQuhVlFElB0NpltW4UQkEcSFFdusTZAIQUCXW6aFIGjeghowDpbpg1ATwyBDBnhplhXZ2dlqnmEIhzZT4GxImb5cBQEbdySxb+Gll16KIdbyJdAwZFosfcE5ibOOIZZ1pK0pMdmlNTa4sEpbjO1l2YkglsPkPcKqibaPA+M+WU+shsj0WDqTaeHshNUDmR7HepsgrCCgNyDred9993nSwn338ccf99hqYe4xVyKvJwjh8i7L6dGjh2qr8cUXX/SkxwNkAkxIyvzQ29NcmjVib4lMj01pGjDxLOupxQBJeMQknGSDr6KpuYb6QfOC08KQJQJvvfWWp+zKJnwrJLDvQLOVxCSltoxrirCCgEC4mq0pw4QR84O2RNilSxfn29KhRR4eMGCA823ZYBruDGJqAuw30VbmNCZcELQ9AqabceAbrV0IlnEqAlB/WXZlExF1JF555RXVVhLOTgsXLnRSBUdYQQhyNoFG06FNEGjnHZg6JsHZSfNt0EKZmyIRx8FDEKpMTMWkIJQvk4JQvkgKQiwTLgimHoAasJMMJ9zK9BUlCFogl8qmtn9fiy+hEUMGbWOXKTDXoOWrcfDgwU6qCEyFy4/awTlhoW3T1h4KP2B7vkwfRhCA5s2be/LUiFUCU5gGWdWOg8cWb83WhxFBwBtEUvPs0wQBDVWmxVIk9jPI9Jog4M0n02uE67F2HLwGRPlF/aPpE0fOmJgFNskTe/fhky9ttQnZgQMHeuy0Y7bgqQdHHO2+mPCzzz7z5OlXT/x2EghZLu00wsMUKw2yLMxBaPUyISY0N27c6NQkAkxeyvIhXBIIaSfzhKOWthKkCcKff/7pSa8ReWp7Q9BrkPV84YUXnNwjQFAhmSfm3LSt31qeDzzwgCc9gt5KO1Dz/GRGBIGhGXioCQL8FTRbjZogYPVAs5WEmy1+nLIiyPq+Ri1ikrYWj7d5VVvS0ohGEeZ++sF0I1IQavEPTREkLJsmCO+9955qa0qtx6UhSLQoCLQEwr1LO/SCNCCAj7Rllo8gBHFM0gQBS0WarSQiGWuOSaYIu9sRbyQJLW4DBCHMAZ1QdplnIghBMA1lbgr04BDpVyuvrMRSphbdyBRaTEU/aoIQxLdBo2l06CBuxp9//rmTKoJPPvnEY+cXY6HUmIoMzcDDRAiCaUxFP09FU4SNh4C1Yglt3wEEIUw8hLA9GVNCEBYsWOCUWj5A1768BQE+GJUpCKbHwfvRdMk1iCBgqCmhCUKZg6wyNAMPtdgFfqcXadQEwXQCEDPtYQRBi7EQhBUlCEE2IoUhBKG84zZgMrm8hwwQhDDCFXbIoJ1zEYSmPYQgKwKYE5KAA5O08zuxy2fyM74gwN8bP0Y08TaXwMk00g7U8tQEARMsWnpJLGOGHTJo+WrUgnpWlCBgIkmrE4LMyrI0ou4yLX5LaQdBwNgcEYnKi/Ak1SbBwhD1nzFjhlqeJJb+JPLy8jz3A9TupyYIeNBkWu1+gtIOxNtcq6skejJaeo1arwNzCNIOIem0srBvQtoy4wsClA1dtWiuWLHCKT4ChOKSdtj8oXmCaYIAnwWZXiM2zWiBMU0BTz8tX404a0LWvaIEQasn3h6mh79g6U2mh9+/tMMDgQApeKOXJ/0elrIySD21HiyGMfJ+wN1eEy5NEBDsRqbHFnGZFnMd6IVK29tvv12tqyTih8i0ftRc+BFIV9ohFKFWllbP2bNnxxcEbZnMFPgRKtMPISwuueQST90rShA0wEHFNNyZtoMSb0nNdkejFu7MD5oTkSYIGhBVW6aFIGjOYzjvUdpqDHIgrykQpVwrS1u1KTVikun2Zw2V7akYFlo048oUBKylm+6g1IKsVtTKRWWzojwVte3PEATt8JfrrrvOY6sxyPZnU/jNS2ibzZKCEAdJQdg+mRSEWJSrIKCxlxWYa9Am5rQdf1UR7dq189Qdp1ZJ+M1gh9l3oCGIIMBjTSKI6/L2zCC7HTXXZVMXa8xnybQQBC3SOA56kbYajzrqKCdF+cFPELQXVowgDBo0iCSxRRNx2qI5ZMgQJ3l8YCYTtjJPHIcm89SorWbAtRNjRGmL8bHEiBEjPHZY3jTFuHHjPHVHnWSeeCNJO0Ty0U5kQjBamV6jNjHmJwgIsCLLx/4ImSeiEUs7P8K1VZaDoKSarSRm1LW5I1NiwkvL15TY1CavXSPG9dqR/aeddppqL6lFu8bkJ+aepK3pITNw9Zdpg9AvYK9WFvaByPR8TyKC4KSPAcKD4atoam/JIMA5kDJPjVp8fgxDoMLSVttFiIdK2oVVYC3Cj1ZPPyC6kkyvUXMm8RMEbd+BtjMR+yNMoU2CacMlP5g+ABqxFyIMwnoVbs/EITMSfoLgw/iCEGb7sx8Q7lnmqVGLZoxNVNrbR4sSrG1/hhiFASLVyDy1mIp+MD1EFQdxSvgJghZGLBHHwWvDEA1hPRWDCKwG05iKOyKrdDwEPyQFITa9xqQglB1JQYhFwgUB3eYwQGOXeWpEzDkJDBm0iUrTIUObNm2cb8sGLUqw37kMGrQHTaPfgadw3Za2CHAroQ0Zgqxxd+jQwZMezjUmgCBo8SRNCZfaMNiZhwyaIJT5XAYnfQw0QejYsaPlIlka4VqpxQBEDEHMupZG7J+XwKQiJjqlLbaNSmC2WNqh12AKLI/Ka+rUqZPnfqABSzs/QuRkejz8sp6YeJVpsXEFh45KW0xUSlsEeZV22iQt3HyxzCbTw7FJpseEnQmwnIe4mzK9KXFwjaxPEGJCVeaJNivvO14s+D2lbUURk5eyTmGpCQJ2s2rla7z55puDC0IQhtl3UNkwnfwMS8SCkPDbF6+5q2pRrUy79xBYrdeRiOhGpsCeBVmfINSWHeGWK+3gXq254VcUILCyTmGpCUIQxCw7Op/FIIwg+B0Hv71Ac0xKBE0PavGLqZiI4+BNz2VIBILsTNSoOSZp258hCGEOagkLbWdiWCYFIYFICkLlICkIZWfCBeG8885TCzYhtlNuz0OGMNcehEEEQQvLpgkXDskxhXYcfGUOGcIe2a9FM/YLSVfe0aKCQItxGZaYBwiDGEHA2E1Sc0zSiBOaMLkWzWOPPdZ4jAZ3T618SfiJa/vdTYE3opavRnhuyWvS9maEpakg4B7DlVzW8/rrr/fUE3lKO42Ygda2VCOGoGZvQmwrNg2EqwFHr8vrCULNGxVLb9IOEYOwm1e7Bkkt7iRWUzRbU5pG2/Yjfjd5TegdaWVphCexRIwgYNZV0jQgB/ZxI06BpCkwK66VL4ljssIGSNHy1Yi3pLyesKcXaTQVBFCrJ1y0ZT3hh6DZajQtx5QIumJ62Ksf5PUEITdqJ5dYSDs80NjLoF2DpDZRic1Nmq0pTZ8tP+KEKXlNffv2VcvSWKbNTaZs3769k2XZYBpCDbsIKyqE2pgxY5xUEYQ9m0BjEEHQiDDbEppjUkURjS2sIFQUTB2otGFIZceX0CIm4YxTzVYjek0S5SYIiC4UBlUxyCrOQJDQPBXDMqwgmHoqVhSDHAdfmfDb/qwR/h8SiTgOPghNg6z6MaE9BL8j0U0RJAy7tr3UFEHCsGsTaxUlCEGCrFZFQZg/f75Tk6oLdLGxs1K7BkktClNVFAQMGTRbjQkVBMQOCIMgUZfDOJNoZyj4MSkIZSMEobxjQSQKpsFgNbftyh4yaIIQZCmz1CED1n/LSsxahgGCNWj5SuKBhvhgA0w0tUAuGE9Ju86dO6v5atTOUdQEAe7IMi3qaboioQkCNjLJPCES2vH6poKAaDwyzyBEPWWeGjFZhrLkvR87dqxTu+BA9x7xB2SeGjWX92nTpnnsjj/+eMs9XbtWyXnz5jk5RQAvT2mXmZmpLuMiqri0NSWWTLW5Dk0Q4Pej5aFR21YQIwjOZ1UaWHLE8huqG03tba71OoLs+NOgCYJf7wjnQEpbjZog+EFzIjIVhFNOOcX5tmwIu2lIO3rMFFgiMw26or3N/fwQyjvMHYDlP1mOaVAhP2iHqmiCEBbbnSBsL9ufseegdu3aHluNpoJQkdufNVTmcfAQBNPxfmV6KvodB296cpMGfkjV4+CTgsBICkJSEEpjUhDKju1OEBAPQXPo0NbiEyEI2inVWtwGACdVS1uNiIloAj9BwKlZEtrkUmULgha3wRQQBNMYCzfddJOTKgKM7TXbMCtWGipSEIYPH+5YlB9iBAEbYqoS33nnHaeaEcC7DGNZvAGjie2tEqaCgMkVBFOR5cOFVgKhzGXZ6DXItA8//LAV90HaasSSq0z/xhtvOCVG4CcI2Nwk02uxGzVBwGQd5lpkei1obVhBQLQoWY7pJiosEWKNXbt/klqMSbgea7aI2yDrpBFBc00QRBAwSSzL0YIP+QkCgt7K9KYh5AE8HzL9gw8+GBEEhqfQymTYgKimgoBhiBa41VSBte4oqM3iaoBwyLSYRJLwEwRTaoKAmXK4GktbLRhKWEHQGHYzTlgcfPDBar0kca6CCYIIghZ9C7+vhJ8gaMQqmim0FStm1RWEIKHJNJgKAs7tq1mzpsdW81TUEPagFs0dOkhMRVNqghBk+3MiBAHRryoLYT0VNQQRBG1Ypx3UEkQQgmx/1lYumElBSApCUhBKY1IQqgDDCoK2M1GbAKxsQcBciUyvCQJWLpCvtDWl35BBO6xEG4vuiIJgOmRAjEtTaH4ImiBovzs8JyWCCAK27JtCexEw4wsCGiYCcCSaLVq08JQdRBDS0tKsBzia2DAly9GW+CpSEDIyMjz1vPXWWz3pNUHAnMQNN9zguSbTI+I1QcAkrZan5vlZmYKAhwKThfLemVI7PhBvc9x7ee2aQxm8JLV8JRH9W1tu1gQBu2ll2ThdS8JPEPByk+nxG0ngiHitrpgXkek7dOgQXxAwE1oR0E5ECiIIGArI9I8//rjzbXxUpCBgm7i01agJgh9MQ7trghAElSkIWHY0fZtrRNwDUyDgjJZHGGqCYAo/QTD16/A701Nzx+ay4gvCr7/+6pgmFtr25yCCoIU7e+KJJ5xv46MiBSHMQS1+0GIqatzeBSHM4S9BVqxwHJqWRxgmQhBMHZP8Dmqp8OPggyCsIGihyJOCEMvtXRBMPRU1+jmPaUgKQgSeRNuLIGgn8YYVBOyEM4EWdAVusVoAT024NCIepSkuu+wyNQ/Jk046yUlRNiTiiDRtzOyHMCss2uy9HzAxp+URhoMHD3ZyLxu0OTZTQUCMS5kWRHxSiTIJApa/sM2yrITaS5gKAtQS7qYyT21sHlYQsDtPloNrl8CEJrY6RxOzxUuXLnUsIkBjk7YaMQSSwLUj6rKsEzzWZN01QmRk2iDEFl6ZJ4RPqz/CqElbuB5LO22eB7P/suwlS5ZYx/DJ9KbEKUkyTz+aCmwQfvjhh2pZJkSEMG0pUxMETDzL9PCu1e4JJrilLTO4IMBVF2culJWaa6mpIODhxc2ReaJhyvRhBQHdflmOdtAtGjD2WEjiAZbA0qFmK4mZYQksEeKYeFknhLuXddcIb0yZNgi1becQGVl3uAlrMQEQFFTa4pokEIlIlo0NbYgQLdObEvEpZJ5+NL2fQYjAPlpZptQEVhMEfCbTIu6Ddk+OO+44j2316tWDC4J2iGoQajsTTQUBbsaIqyhtNYYVBI3wfa8soHdiGhOgoug3L6GN901dwf1iF4SJwhTwwNPtgpogaM5O8IvQgJUXacsMLgim4c78qI3NgwiC6UORCEHo1q2bk6riEdZTMRE84YQTnNpFAN8GbUXAdJkM0XxkWry1tQ1spvDbb7I9UxMELcgqepUayuSpmBSEWFamIKB7XdUEAd1RCcwRabEKwwgChoRJQYilqSBoG+WAnU4QwjomacRwqTLh425aacRR9hq038h0yOB3lFuYYCY7iyBoYe40d2hghxYEbGRCvtFEnueee24MsedbIoggNG7c2JNnEOK8BRNg7VimxUqKFnQF8RTkteOkIWmnERGSsdVZptc8Py+//HKPHRqlrCdWPRBDUNoikpG0xVKmBH4PmRbtEBuxygpNEDDJivrLsnAKmbTt0KGDx+6jjz7y2GHyD5On0taUQcKoa4KwYMECT56aGzqwQwsCzluQ0DY3IdquRBBBCMthw4Y5pcaH5uzkR+03Mg2IipUDXL+E5pzTtWtX59sI/NxitUhEHTt29NhpAVETAU0QMAzBUpuE5rqsbW6aM2eOxw4iE+YgIRxwI/P0oyYIQbBDC0KYmIoVKQjY/GKCijq5CcFR8FaR0PZHPPDAA863EWAtW9r5ndzUqVMnj21F7Xb0EwRtGKKJoenJTRAEzeHHFEFWQ5KCwEgKgpdJQSgdSUHwIikITL8zKE0jJIeldj81BBGEcePGOakiCLLvQNv1ds4553js7r33XufbCDS3WAgCHLAkLrnkEo/tPffc43ybWGhdcT9B0NzgtcAjWPWQduD06dMdi+CAu7uWp8Yg8RM1tG7dWst35xIETAri82jierQgIRpx2AmWM8tKXKcsX/PcDCIIiGcg88Q1aeVLYtUE91QCm3GkLbw0ZTmYKJT1wVsSy7PSFmXJPBHFWtoFoXYcGSIsSzvMAch6+gkCJllN6tmrVy+P3ZNPPmkcyRnLqzLPBx980FNPED0UWRYmk2V6bUMe5kmkHVimmIo7miCEJX6EMDj77LM9eWpvySCCoFHr3oeFFuEnCLVQ+e+9955qa8rPP//cySmCV199VbWV9BMEDdr6Prwxw0ALsqoRxw5ok5/a0EYLshrQSzMpCEEY1jFJ2/6sRXEKKwja8mpYhN3+rDkmmT4UftTCo5vuygwiCNicJNNjs1UYmB7MCkHQhiHoGUpbbWjjt/3Zh0lBCMKkIOjlmTApCLHYYQQB4xfN1pSjR492corAVBCwS0tzztEOe02EIGCMFwba1tpECEKQOAOm0B6KIBwxYoSTUwRhYyxogmC6wgJiUtQEmsOQ36YhUwQRBC22hha3QTs/ws9XxIfBBQE3BxF9ykrED5AwFQTMXiPIiMxTi/1oKgiYBMNWUJmnRs2zDluV8QCbUPMANBUEeMFhu7FWL0m8zSVw72R9sFcem5Ek8EaStuh1yDppRAOGA5isEwRF5okQ9NJOI4K7aC8CTRDQE9HykMSZnNoOyhkzZnjq2adPH096eG5KOz9qzkpBBAHXJPPEqo+sE2JWSGA1RNqB2gE9zOCCkAiYCkIQmAoCAneg51FWaBGTgtBUELCnXptcMoWWJzh//nzHIgJtidCUWHZEQBMJPEDSVlvK9ANWiGR60yPWgkDzwbjjjjucbyMI0hWHO7OEqSD4MUxYNgC7IJV8k4IAQQjjbhrEzVhjEEEwPetBA3oDMk88vJpjkvbwmhJ5aiJz5ZVXemxNHZMQMl2LsZAIQcBMvSxHc0wqKCjw2PlRWw0JKwhVxjEpEahsQdDCnZmiIgUhTJAQTRCCeCqaMhGein5BVhMhCGE8Ff2ovc23S0HQjhpPBODkIcsOKwgI9Sbz1AhBCHMsOOYvtHxNqQmClicetDCCgLkbmSdm2rXufZi4gn711ETGdMgAQdC2fpvGWAgCrYegbcLCCdnSzo9ffvmlkyqCIDsbNWp5BkGZhgw4XQaTTokmvOBk2UEEAQ1G5tmzZ09PnhohCOjiyvSmxKlAeAhMqMXG0wQBD69MW716dXW2GTEdZZ3wmQT2Hcg8EY4Ou/ZkerzNpa1GLf4gPsfEnMwTD5pMDw9CaacF4cVnCEUu08N9V6bXqOUJaLaYvZflwCNTAkMGaedHvM1lOdg+Le2CxHPs37+/J88g1CI5M+MLAjb9IBxWookAj7LsIIKANVmZJx4gmadGPKR4+8j0psQRWOgim1DzVNQEAT+YTIs9BxhLS2DtWdYJQzAJLU88uIh6JNOjAUtbjdisJa8Hs+KI7CTzxMSaTI8lQmmHeAoSCFiLXodMf9NNN3nSa8TKlAREE9GYpS0eNFmO1oOEyEg7P6KHIcuByEi7sWPHeu6nHxE5WeYZhD7iE18QKpNBBEELalFRDHIAihYTQBOEINDCsAeZvdccvTSfAQ1BxtFaLAjNHbpVq1bOt6XDdK5DiysIQdDOcUzEMOTqq6/2lKM5EfmdoVCB3DEEwfQAlEQQ69mmMPVUDALt5CZTT8Ugx8Fr0LY/+9HUU1ELYuOHq666ypNeo3ZyEwRBOw4+7C5CDXAYkuVoS5lVIDp0UhDCMikIsWn9mBSE2HKSghCQiCFoCtMzExPBIMKlre+HDdyqLefBvdwUWoTkn376yfk2PqZNm+ZJ60dMUEtouwi1SM5+0B40jfBE1aCdTaC5wYfFLbfc4ilHG9ZhclvaVTDvZG7DNVWJZ5555jX//vuvEbmHoOZREWzbtq1aJ42XXHKJJz33EFRbU2p5Pvzww6qt5Lp1667hcbQnPY/3VXtJ7iF40vqRewie9NxD8NhxD8Fj50fuIXjSa2zTpo0n7ZYtW65p2rSpx3bw4MEe27Bk4fKUc/vtt3vsuIfgsatgNmEmkUQSSfiAey57MQ9NMskkd146cvB//8ddl2uZK3cGbt26deW/W7es3Iq/4zPr38737p9JJrkT0pEDSxBuYYVIIokkdmI4cmAJwk3OZzsFFgwdTpmXXkE5d95Na+fOcT5NIomdG44c7FyCsGJqCY1v3pIKD6lBGfseSHl3/o94qED/8ncuk0hiZ4QjBxCELZYgWI/Fv/hv6Y/FNiu2t//t/pdp/z8wnNQWIn/n/zofup9FE7Dr4tSnFCycOIkm1KxDJU2bUmGN2pR28WW0ZfNm2srf2en9c4kuwf47GElpwf0r/2lb8P+23aOoLxMAK/9tWeMv9r/tGkZ/F4FdJ5fuv92/KQl2GNjXbF2j/X++T/b12tdt/z0xiM0bzWNbiYksthQ4chDdQ8At2dZ84pP/A6utsOd/WDeT/4xNGQx2nsgRdeAcrX/bpUTnh79Ff4K/W/+ImPhi89o1lHXzLZRyaG0a36AJzRv0lfW5nVTPwLom56ttFqic9U0kjf2J/R+rTta3+J99PYD7eSIQKd8tl//HHzhVVRD1hZvmX7sNuCK2w8PnOhN19VF33AP780SVXDocOSifIYPdnMoZVuM0h7ntv7R4cioPH6Y5/2bwsMF9XCVQi3h54zvre8fI/jfy0lPZ35U/4v0GW7WGDxHY6l8XWxx2XLhX/ld+ARV93JdmfPYZTfukH838YRTfr0T9RjZXzplNJX0/pVn9B9D0fv1p2rdDaNP6DZZNZcGRg4gg4CasXriQ/pk1g1bPmUOruNKrrD/dvwvOnkurZs7kNIu2PTRrlvxJK2bMpJWz8D3T/VOjsEGafzi/lXPmcjd+o1WfrXyT1iycR//k59Ff4yfQgtGjac7wETR7yDCaM2Q4zR85ipZNnmjVY/Mmb0wAiQ2rV/P1zaV1S5fS6sULadUff3BZm/xeFBas61r8Jy1LTaP53/9glT1v9EhanjKZ1sxfsK1hWVnwf+w7Yb1nafWCBVbdUcfZ331PKxctjltWGKBcbJZes+xP+mf6NL6vM+ifGdNpzaKltt4J2LUkWr9iOa2YPpP+mT2HVjL/mTqd/p47h9N4t17vSHB/t5nvvEPj9tyX0mvUotR9DqRxF15CmxMoCMCiH0bSb/sfTJmH1qK0Aw6hcUefwL/DCufbyoEjB9E9hC2Udt0NlNK0GaUdeSTzKEo/sg2lH9HG+nvaEQ7576nMjNZHU0qTwyjjxpvt5IycJ7vTuAZNKa0lp2nNebRiun+24rStOD/+O2h/dwSlWt+zfasjKK1ZSxrf9gxuxAusmzez/2c0+bBWlHFYS0pvxPnWb0CpdepTWi1m7XqUXqchpTduSumtj6GsDh1p1nvv0caV3qPKXCzgB/r3Rs2tslObNKffzruI1q9Z7fxQziPi/mqMv1KnUO6991HqCW3Z/jBKr4ty61Bq/XqU0Zjv0zHHU1bn62juwEGWsADue3rT6pU04fyLKKNhE8qo14B+5etcyQKUKLjVzn7pJRpXtyFltGpNk+o1prTHnnS+gQ03dMvQbvAb//mbUi+5jCY1bUEpXL/UFi3p5yYtaOaw4db32x/su+CKsgnmffgxZR9ah4qbHU6F3KYyOnW2hDWR+OvHHymzbgMu8zAqbtCYMk47g9bzy6oy4chBZFIRKLz8SsqvUZsKmzSlosZc2UZgs20swZ8N8WdTKm7chPJr1qSiTv91UhNNffQxyj/oUP6uORM2ERbxA1TIeZbwA1mMvzfhfJzvpnK+RU2aUHG9hpTND9kaJyTXtD59KIsVtJgf3sKmLdnmMCqsU4+KatelgjrMevW5Pk2tehXUaUAZh9SktP+cS8vT0630EouHfUfpNfnH5zoU1a5PqWe2Z0FYYzcfdKGdNwO60tN696bJnHf2obWpqGFjKuGyUd+p1rVz+qaHURGXm3PAwZRy7gW0eeP6mGa4cvp0SmvRmkr4B8/je1p0l312glkzDQ5XiAp69qIs6zdoRnkH1aDchx6xPre+xYqK9RfbtuiRbpTJ96yEbXFtaQcfStN79rS+277g3lX3LtjYuOofWjIllVYrYePcrtofH31MmTUgCC24DdWn9E5XJVAQ7DL/+nEMpXNbL+IyC7l9pJ9+htV7rUw4chA7h1DA6pjHN6WweWsq5rdyDj8QGbXqURYz02J9688MfiAz+MFM2+9Ayrr0Sic1Ue79D1LKXvtbaTJr1aEMfvjwZyYrbxHUsPnh/Gcr/rMF5fINyaxZn7Jq1qUcZgbsuSFPbNma1jgnFE9/6y3KYvUu5HSF/BbL455JzqUdKavT1ZTZuTPlXnAxvwmPpkyuSzEe0OYtWaRq05RjT6TVs73HdC8e/j2lsTIX4W1QvzFNaX8urV/r9hAizWla71co5eBaLATNqaRZa8qvz295FpCMpodTZssjKKPJ4dxTaUC53JCyDjyYpvd53Upn/+B2HgtHjaYMLquE653B922Rc9ZhbJMtP2wThBde5AbOAoR7zPXLfSSy3Rpy59rN++prSuFrmso9gqLmraw02bfdaa26WBaJGtskBKirTSwjz/nmG8q7427KbncG/cy/3fzfJ1hWGipPENAOq7Qg/OsIAlcUD1bdRjT17vtp0ZChtGTQ1zFcPGiQxYUDBtKSn3/ZNh5bMm48zX33Q1rQt5/F+R9/Qgv6f0rz33mP8o49gd/M3FPghzGb/5zx2OM0/7OBNL9vX8f+E5rP3be5A7+gjavt48Wnv/WmJQhFLAg5LDL5t91BW7dsJXTO8aNt2bCRVk4roeKnnqaMBs1oGvckYJvJb7rCJ5+y8oiGRxC4N7Gth+D8WMvS0yilUROrRwPhymH7jHMuoj/4Wpdn59Dqkqn0V0YmzR86jKY90pXGn3AqLZ0y2Uob/bDPeOllFjvubXE56e3OpI08RrS/jdiUJ0wEwZ3QXFlYSFNYSAsbNKKiw46ggto89Gp/Aa3/0w5Pb+W1HQkCaurOY21au4Emt2tP2QccRCXchlOZiybZv4+GZA/BhiMHuiDg5mRwV3n2QG98eQ32T+HKggLugmee+R/KRwPkvFP4R1o4fpLzpRduU3R7CHjI87gXkX9PJPglbFw7oIh7J7ncE8FYsKBeI36Iz6fN69c739pQewiOILgoeeopyjqkFvcMWBTrN6SsCy6hdX/6h21f9+eftJmFyb4Hdk54lvKuuZEfNO4p8X2c5pyw4z60wWCWxs3bEgQuE79hbo26lPewLQj2ci7RZr7ejEs6Uh4LbBH3AovqN6KUI46hFfn51vc6OO9SBQI1gI1bE/vfrgi5qV0L/M/O0/2Gwf+O+peNOB9Yqfk/KMGexmVBWL+OMi+8hIrq1ePeWXNKrd+MFk5KgTl/782/NEGwynAYH9FWurV7L/4a8xMLgv0sxBeESD5W7s4/7euILcP6V9RHsd/a0D5z4ciBXw+hhdWo5nzcz/6qDIgufPOKfyiD35IFDZpYNz6Fb8b8H+2gHPbPqFd1RlQPIZcbcF6X2KPUo2/Msh/Hche9odVFL2rYjKacdDqtXRYbLNNPEFwp2wLhuuIqaz4CNhjGLOIeDmDX0uzdsW7BQko/9ngq5m7hlJZtaNU0d4nTbrra1eo526XqdycWrk3hC735nnHP5DBbEPIdQXBzKe7endL582LuBWI+J4UFYdF33qPbI/AvXf/GLgn/9au59f2/W5iuJf7LLcFt8QL43O+7Lda8SOTuwSqzQ0cqdLrkk7nnuCQr2/5SQVxB4DK3xKmTB6jnttbkj79G/2gJQiE/Z1IQ7Bz0MrfiWvlPv3slP3P/hWVn0EqtpAMcOdDnEPAAWj0E7vKXFdHF6oJgn+DsXqKGeILgpnAf0r9G/Wg97MU8zi/CLDv3EDaJtV2/OQT3J9y0eROlXHAhNyZ053hcXbOeNZwBYGM/zqVj4cjvKL1OPco9tBYVPvSo9Rl+B3fS0sVfU9Jpeu9XqODOuyn32huo4JY7qKRHD1r8yy9RtlZC5+/+cC1cQcA9y65Zh3IetcsHFowYRql1WAyaHM6/w2GUxkOL6X3scyF1QYrUd828+TSfh49Te/Skwrt4fM71zbnueiq+9z6awUPCFcUljiWqaz8WqNO0b4ZS/ou9qaRPHyp++TUq4aHhlo3272LVGZe37X9E838aS3lsX9znDSp+5VXK//gj2rTOnrBdkppOuS++ZH1X+CLn9eVgp5x/aRkP5fBdyYsvU/aJbamgCQ/5mrakHL7W/PseopLXX6eSl16lvBdeor/Z1kU8QUC+eDgXTBhPuZwO5RZwGVOHDOFPJdwrIFq/ajX98dW3NPXhR/ke3Ui5N91KU7s/Q0t/tQ9CWv7bOMqo09Aq008Q5o750aprMf8++b1eplmjf476NSAOW6jk8y+okNtPYe9XadpnA2jLFnvp/e+iQhb+pyn98ispp1dvK0+7ZpG/SThy4CcIFddDsCuoVzJGEPjhzL/bGy8fQOqCLvxQ8UM4lR/2zIO5y/9cD/vLKJQ2ZEBd0MgL0Z1mGwxxstqfR2udVQ9T5Nx9D6Xuujul8Bt4VWGx9Zl1nU5Bq6aWUO6Nt1Jqg+bWWnReDRaOGjWtCVE0zsk8pMr673W0csYMy16/O7FwbVxBwH3O4fxyH7EFYfWMaTTl6GOpgK97Kn9nlXvnvXh9WN/rpfxL6/5eQXmPPk7pbdpwj6kuZbOI5NaqzXWtT4XMXBadDM4Ly8Mlz/eiLRs2OA3Xzm8qN+iJu+9DWXyNWdVr0jj+jf7OzrK+A2BlN1P+36ZNlHpBB0rdZ3/rPkzZY1/K5PuEiUJg1pvv0MQ997ZWftL23pfGd7jYSg/8MfJ7+m2ffa0lxMImmMBuyW9gHhIxc2s35Pxq8n2pReP3O4iF8TsnFaf7UBcEu142pj3fc9s1pHOdJv33mm3fSSzidp1xZnurF5bN+ebXqUN5teta7XgyXliPPU5LB39L2ZijanqYRxDchz7/3vtp0p5cJl/r5D32pLT7H3C+sUvGCyODrz9t7/0ofb/qlNrWDu23YOgQmtTiCMo+5FDK2fdASu98nZWnX31dOHLgP2RIP4QFYYDZHIKG6AqUlyDk3evelAjgHFT0eHfKrNeEpnLvIJftU05tR2sXeM8bjDdkcGsw5/33KZ0FBROKGGPnspJnnHkOv/VHWapcGjatW0vZj3alwjvuotmDoo8es0tYnpZOKcecyPXkh7ZxE8qp1YDSuHGktGxFaSxAeVYvpwX/oLX4Os6gNXNmW+lKg1v/SA+hhSU0+Xxv4PWZ1fkaa5KxhK8dE6VpF1xCG5a5E51+nVTiYdcymojhz0EHUX6NevxQ1KUMvncZjZpSeu36lI+VimbNrQnj1Oo1qPgJLo/h5rdu4QJKPfY4HsY15XvKYs2CMvPVPtZ3lg3/x+5PEK0sKaaMw1tbS6Al3IPBEHCJ05ME5n3wIWVZe1H494MfSuf/bnubL/h+FE3ChrWada0l4cLmrSyizDzOJ4+vvYAFIeWA6rQwaojkJwiAew2zuL4QA9w7CGHWzbc638RiAf/ek+o3teaOcP+Lmza37k8memp83wr479l1WURPOZUKDm/F7ZBFS+khANMf62bVGdeay2Xndnvc+hzfuvUquvFmay6okMvM5mHS4rG/0JQWra05NLShghr1Kef6m7aJDH5lN62EIwdeQchnQcD4s6BhY8q94koqfvp5Kn78aSriH9pl4ZPd+bPulNO1G63gH1FDdMFhBQHLjgWNmlE2P5hF3PUqfvJJKnn8Scq/+XZKO/YkyuQbjUaAZdL0Cy+mf/ILrPQy1/g9BLsm6//6i9LOPJsbPzcSLhdvmnyubxo3qqyOV9If/T+jtYu9JyohNSbupDtwdB3WLVpoKXl+rfqWbwWcrYq7PUF/TZ5My4qn0p8//UQ511xDWZgL4QaVw8KUc9vtVhfc/Z/zfw/cz6KHDLn8ABdyF3/uZ59RBv8dw4QiLjPjmONozfTpTgo7pZani7wHHqbJ/NYpevAxmjdwIP01diz9PW48zf96MOVddwNl1W9iPwAsbJP5Xi2dZE8Yu3ei6KHHLKEuZIEtQO/n4o60ZZN7LH2kmc4dMIDSWfith5PFMbNde9q0atW2uv3xwUfWUrb98MYKwp9ZWZR1+51UxMPKvGNOoCKsOEH80C7+ey0V3P8gFd99L2Xd1oX+zMiO5MlDhkiefoLwmiMa3Bb4t8u6JXLGgmuzIiefJjdvze2Kh5v8ZwGLfVrjxpR37U00HUOlni9Q5kWXUBb3Vgoa4jmwezCuIGwUPYSpj3W1ehiol9XT69bN+hzluWWW3HoXCxT/xo0Po9zTzqDsiy+1xACrRpm1G9AUfqlMujrSQ7Anlt3UsXDkQB8yYKa+BA8h/9B4k2WzQqGrmMVEdw3/zj24Bk064BBa+vPPTupYRBcbdg4BgoC18gJucGhYOVyHHP4zF0KAh4rzzIVzU5cu1hvahlcP/eYQbCvngWP8nZtreSfi2qdy9xMPVzG/BaHwcGxKPf5EKn7mOVo91/Y8RKqt3Iz+JWcNX8D9DOPI7INqWvc3rV5DmvXe+843EZst69dSniPMUxs3p1Tu+fw1xZ4lj8BbivtJZMjAjZeHLNkXXkjZfC1wJsNDC2eqjCOOplUF7lAGzV+rtf0p+PdMuJd7/ToAdOfz77qb2w2/mbmBo1te6AxT3FyXjp9IaXy/izDhCx+OJi3o720TfREBzb+jCw9H0CPksf8hdWjqc7aTlGthC4I9HHIFwW3ibln4Nx48rBDhLZmKSUXulUlsy7OMguB+B6D7nnfTrZxPLSrguqNNprZoRfO/HbItL2Dz2rU09dnnbP8ULg+90LiC4FxrtCAAbtklt91l9RAKDuP2jLkzONJxu8m5/hbLXWD5uHG0NCOD64e2iXTRtY6FIwdeQcjlLg26WkU8JixuyA8Degz8xoomVB6efhn8oy3jboqG6KLLSxDyWRDQUNDo8HkOqyPeJNZYjG9IDo+Rc2+5iVbk2UtoMtfSBSEiIqu5q55zy+00ha8X3VDLWxPp+AdH7ynrkBo0mbv+8wbbwwK7Ybo/pxdruOucfvQJ1tshj4chOZ0iDl1AdF2X/vILC0EjHgK14OusSdOd+RDYuHWVcD/Z1kPgxluANzKLylS+b4WN8EAexkKPMXVdyrzyGtpqLZcirV9TiRVV3Ybor3G/UTraBN+f/HoNLIcxzAe42MJ/z8DMP1836oT64a0ZDatndtLJVNiQh0xwE290mDW8AtxyNUGIfuBgt2nDBsq48CJ+U7Kgcj6T+X67fgj43mbklyoPQVjBPdI0fijRQ0IbgWPe7Hfes75DOZjhtx9J5LmVcnj4BsG32mEZBMG1Kb7zbh5y4gXegodt3BPC8OGxJ7g82Q79ft8IHDnwGTJwo8lvym/jtqdRNqILseJK5vGPnnruhfyjpdnJBaIrUC5DBqjfORfQVP5xpr38Ms14sTd3YR+h9HPO5bdPI25ITXi8xTeFey+TjziSlk30+jmUPmSwa+PeTvx90c+/WsKQeviRlMl1KeIfsBCKzMOqIn7LT+EfZE4/ezVGvwr70/nffEMZte2Gh3H4rNffoM1wsuIewab162nzug3WGvqmjRtpZXEJv8WPshpYPjf8vKuupq1b7QcMddN+XvcTVxCstwa/geBpmcv3PfvUMygH49bmEIXDKZ17e7P5YQCQ1q/uGK5EAxvQFo74jmb3eZOKuz5O2fffR7lX/dd2LedrQwPPPPVMWrc8ysmJgbIycP/4ocrj3z/zwkstxzIXS3/62fLew7Amn0U4+5IrrGEFUru/h18PAXBruYHvZeaFHaiQy8Aqw+RGjWjRxInWd1Zd8H/mtjxDDhmAOR/35SEZvzSatuJ2yEOyE9vShr/+tL5DWfaQz/7lgHkDvuQyuUcVVhDuuod7VPYiQDH/xhmnnE4b/v7b/hJlOteJ0t1rcf+UcORAEwQugCuRwQ1mDv8AVmabuCvMKh9L/mwjN1KfLbTRBZfLpCKPgfPu804qbuJu2IKvv6H0o47hh7UZFbTgH43fgFNOO4s2LFtm2bi3YzE35HiC4FcP4O+pU2kGN4z0tqey6NSz3t6YXyjia5rMjfjv3BzLzi+Hac8/bw250B0ugHCd3JYyzj6Hss48m4k/mWfx3/9zLuWefibl88NbyPcKjkOp7c/mekYmndzriYb7iSsIVi8PvSoeS6a2P4dWz55NBV3+ZzWuQu79FXHPKqXNcbRqljsU8OYZvW16ye/jrOWztCOOoVS+h/hd8niMms9DoLxa9nABb38Iczq/SNY4zlxuXeGOPqXNsZY7OHoqaTzGX56ZaX0HTHumh3N/0CuqQ3PesYdTSO22sHg9BNiBG1kQMi68eJsgTOHe3EJnTiMa2/IMIQju90XdnuA2gXqx2NVqQAU365OOboplYyB+sY5JZRkyYPk3x7r3PGRGL/Z/DzrfBIcjB/ocAh4Y+CHM+cR2yikN8i0CRH9SLoKAVQafZUdg8ahR1mw9xqnFzVpRGg8r5vTrb33n3uQwguBi3dIlVPTAI5RZl7vgGAMexg/3IfxGfuzJuDkUP/CQ/aNx2RiOwW24GI0Ibwr8qBg7409unJhBL4T7ND9chdyrmHxaO1q7yq6nqSCU4G3F9wM7Mpdn2+P11dOmUWqro618MXTAPpI8Z9JSg/Updz+nv/gSTarPDR0PLD9gBbVqUwYeHn4Aso4+nnmc1Rsp4F5TIX8PQVj7p/2GxL13cy+6715u5HYDxoTZjJdetT7fzN38zAs68FC0IRU1bkrprY6gVTPsSU+kLZsgYA7hcEqxBMHrulweguBiapd7rMk9zB/ksF0R95w0uL/bMm776SwE2N8TVhByuc1YwxS0pZ69nG+Cw5GD+IIwO6F+COEdkyyia2T9SZR7cUerUaFLj/mFQiEgi0eMiDuHYFPA/ZjpPoro/hVcdzPl8du3EHlx48s+v4PVsP1Qcu8Dzo/Hb31Ok3PUsVbXMvO4kyj9+JMp/QQm/mRmHMc8/iSLqTx0mNL5Wm7o7njfroeE+0mkh+D0qh62dztiNgCY+dZbVtfdrkcLSuUGPj/OCchzPv6EUg6uYS8FYmWExSTv1jto3rdD6O/8PFo7fz4t/f1XHkO34rF/s209BFcQ8Lu4jXzpL2MpFSsSLNqYa8jmoSdq9XdRMadnIef881kYC26ILJW59xwoqyBoexnKUxCm3dnF+hzDNPRyCrv6Ha1n57j8R7eHUB6CgFUZzMvUpUIeRpcVjhx4hwwVJwgBewh+guAQKL75Nv5h+A1k/XCNKOea65xvbCweEX8OIfJzRGB9ZxXiWtl/zvtqMGXyj1DE3dIC/lGx7IPr9MO07t2txmKpOfcA/uAHE0OaDQsX0nqH7t/xp8v18xfQxr94PM5vavvhsCpjZxoF95Ntk4p8z/A2znnMXb+2LRBGDkuzEDNr5YZ/iyknn0rrl9gPcDQ2LP2T0k48je+VvREng68TXokSy2bNoMktWrFgeAUBdxQCitKxt8TuCdjbyVO5p7B27lya/xUP+ayHkocS3CP64+vo0HZRD29ZBWGyXKUpX0Eo5IcXG9lwj+Acl3/9tnesgJ3jkh/GcA/TmQwPIQhFWN2xep0YZrEg9EqQIMAZIqNGLZrluO3qcJsm/9etYRSiP8KDksnj4iJ+O2ApqGxDhvpCELiZ8UNq+2iTFaAk5/wLKb8BNwTuusG+4I4ulq17k91JRTiYmAwZ7K60+637dzu3eQMGckNC95cFgR+YHB7nb1q3zvpOw9xP+rM9HFZwLfwjPhL5gc0QqYsGu37cy4va7ZjDDT16t6ObfMlvv/GDwsORps2tpS9LQJxurq17tuGSX3+xlketJdd6jSnrnHNp62a3p7LVms3G3/8uLuCHm3sIWM3gfDNOYUFwJtUsWL+Rnees9961JjTxG2A2/o9PB9JUfqPm4d40bEpp3FNyN5O5qeyUtiDg2qIFwf1t3fw3YnMTRMcShBY0pUFTWjLBnlQEomUVKA9BmPXBB9bzgt8WDlpT4OexYKGT3s4Nf3dLnfbaa9uGTkXcDtMRIGWVO0dkY+qjXcmelzAbMuA5wctAwrUFtmzazM+Je3WxdXLkQBcEVAI/2qzPPrO/KgOiKxItCNh8VBZByOPub36X2CEAGsO2h/2boZTWoBmrtB0XIa1GTZr59rvWd253eclw7DFAjAJdEPDnmnkLadXiBdYnLmQNsZ6cc/mVlFcPS7QsPnyv8u+4J8ZGYkVJCaUedgQ/NPDqa8Fd5CNpaUpksssuw72a2PLi5evC/WHjbX8G3LwKHn6Meyw1WRCwXHYYTanflP50fO3dvObymzqtFjd0CGhtFr3LLrc+x7ewce3mffGF5QhTyG88zE94BCEKq2fNpLQjj7bmCnIbNqP8Sy6nvDPOsv6dXaMuTXX3fjBxN9wyAE0Q3Obt7uZEPIesSy+zlsdLuPcGd+uFg760vovkFGk3ZRWE6LyW52ZTKsQVzlB8PxE/pOQJ/ZTvdfMX8v051RJODOuKuR1mnHYmbVi1yrGwMc1YENwhAwThReebKLAx2tXcfv0p7byLaQoP0+Z9/qWVh30P7NwcOfCfQ8jmC5/Rs6fl0ba6oFCwwGZhAa3Kz1fDlkXfsG2CwEOGiCAEm0NAEJW8/93nfBMB4gzgbZ3auo21ymB5fzVsQFOOaEOrZ8+1bNxGpQpCVIAUoOS5njSxzTE0ndV2yYTJtGbhItqCMGsb1ltLOn9OnMBDkestb0KMGTGunsKNbvFo+/jzyCPtRW6XuynnkBp8PeiqN6G0Y4/jsfi3tMlZQYjGli3/0oppM624j/rdiYV7jfHjIQB2DdfyGyztuFP4njW2RAGrS1lnX0CbVkY8AxeNGsP3yx6CwRsu8/Aj6K9Jqc63NpZNSafUE07hri83cCzFckNPjyMIyLuI74PlSowVIRZIy6mGfzfMLywd9/s2u6gOmoV4ghAtHIU330J5LGRYacmt34iyO1xKa2fOon9ZLDZxe9m6cWNoQYjG1i1bKPva6y3XaKv9cRtP4/sx9bnnaM38+VZZWzZu5nuVSlkdLrFebhBP2OL+Z7blIYMYbpabIDAWfzeSJh5az7pnBbXq0ER+BpZyLxFw83LkQOshNKACvpHWTDD/YIgQlNmidQwzuGGkH34kZfC4cTx385aMsR+GaET9juXSQ8hv1IxyT21H0x9/iqY/8xzNfOpZyr+zC6W3O4syUGd4KvIDivXYFP7x5vSLbFt2s1/CQ4ZoQUiJ6SHYP2zW5Z0o/+BD+e1Zh9LQhT32RMptfx7lnX8RZbVtZ61k5GIegn/MqU0Op8zqNSjnnvt4iG/vNItumNvgfLRq5gxKOfZ4KoA/Aibh+K2MXW9Yfiy+936a8czzfF3PUNG991Euv+Um4Jqe8W7S0lCaIOBb2wLN034c/hjwJaXy0AqNzurC89ABKwou1i1eRFOOO4mKebiARoe3Wtpxp9L0Hj1pzod9LZfk9JZtuIHXpIKmCCjDDZzv2ZST2tIqLWyZgyU//cw9EuzZOIx/C+5VNGvFb3R+U15wEW1m4d2GSKUtxBeEyH9n9nmTMg5G74evi+uU26ARZbD44jdM/c+59M+MSMTteILgikY8QbCHldxLyMykifDFsObJWlMBD7MysanpmJMo+7IrKfuCCymt+WH8m9Si7COOopKjj6dCbj9Ylck8+XTauDw2yGp5CkLu/Q9bS8T2hq9WlH1wDSpgsQLcvBw5iO0hFF7Z2d6YwZUA4TGGeHuWB5bg1EbNaRqcMNh+6ahRTg4RuAUBEISc086iEm5YEIRUfru6ggBLu6scncLG9DffpOxDIAhY82eR4gck79C61o2C63JBLW5U/GCjnoUNGvJNOZQms92cD22HGwC5Or8ZC8JIyuKurRUzgd8ciL+4bnVEEP7h3tA4ePRhjM95TuW3P1x+89kWhIjY8R25J4L1fa5L9h1daOM//0TV3m1GOpalpFDK8adQFv8ohfB+xJuifkNrLIglKxATRYVwyz7gEMq6+HIWqtIjSruCUNSrt7UMCtdYxHJ0dztqwov5gOzO13Ijr8v2LHB4mFl8V0TFD5jz/geUelANmorenfUbNOY61rLufz4/dNkHMjteTkX/aW+JQUnD5pTKY+h/5tm9Mw2b1vI4/3xnmzmXhzclxGjWu3LCMra+89//0HKdt34/bncZV1297eEF3HuwZtYcmnzksXwP7U1q6AEhRkYhX2dGoyb0T1Fkq/a8Dz+yJ3vdPPml6N5tt/RZr7zGNtjcxKLBv03WLbdu+y66hgs+H0Qp1uYmDCU5P75fmFOAh2YhDy8LuHxsfpo38AsqufZG/pxfLCyyWSe0pQ1iUncGC3keXysEIY/LznM2N0WuEpOKXbitYMMav7zZttAJxCOR1+1JyjroEPs+MPH3qa/YS77uFThyECUI/261TjKazI0wjSuKmIGg+3f86TK1bj3773wDf69+CC0eOdLKwg+buZs2nt80KdUPpXS+oT9zGbN/cLvY1vSU9TeJQlbmiXvsZ822YlsrlBI3CWN2/B2fZ/AbLq3x4dxNPZ2KeFz8d16uk9qLBUOH0i/7H0SprKqpBx5Cv7Iyr40ShA1/L6OpL79C6eecRxl8k3F9WKvH2BbE39O5y5XKD3H6xR3pj0FfWb78QHwZiG04a+bOpQJ+UNPaHMv3FrvhnL0i/Ke1TZj/nlaH32rcE8vkYdLmDf6TlRJZ3Hsat9d+XM+69Ps++9MU7nnEw4qsLBrP4/c0BKjlhpyCUOTnd6D1/6y068xqOuP1tyiVezTYEm9tf+Y/8QCn4gF58BFav/wvyuvyP5q4936UdmhN+pXFc0V+npV/7JVH/jXnjbesNzOGp3hYU/mN6cbSjEVkZmXGW2/TryiDry1lv4NoHE7e8rnzi34cQyn8dk7ndoO9Nzks3th/8xs/nMtz3bpxnu++Tb9Yedax8vz9oo602Qq4gpratZ3a80W+p/tbNthROeHq2NWraCz66SdKPecCaycofkd7DxC3GX6BpJ12Ni34zt56nXnVNTR5n+qUym/ucXxv1zgOYu7V5N53H43fe19OV5fG73UApT7wkPNNRBCybryFJu5zgP1b770/ZfJvrwG9l0nwtGUhyOTndXKb42hllCgCjhxAEJyoyywIC8dPpDlDR9Dc77434/ff0+xhw62zGeJh68ZNNHf0zzT72yE0d9gwmjHkW1rpbE/GxdmTfu5l2sC/lhUV0Zy+fWnWG6/T1Od7UPGT3ano8Sep6AkeNjzXg+a+8aa1/PdnWjptWB4bHcme3Y1tLKvmzacZ3wyhOVyHOUP4T/7xNm/aZFm5vQgAS1d/Z+dZgUhnv9aHCp9+jgq7P0uzXnqF5n/+JS3PyaEtmyM+B/bMtY3Yq4gAn8vvVvP4cv6IYdwlfZWv6Wkq6PoUTXv2eZr33gfWGRRr5s7mRO6UaGmw67AkP5dmDP6G7/MI/nMwLcxId+5v7L2wHjPnohdMnECzvvmWZg8fzumG0zROt2rp0phy/5laQrPff58K+G2DLc6zP/qQlm976LncrAyayenmsujOGjKU1jjxGSXcWkzt9gRls+AWczc6m8fexU8+43zjhZtm+dRp/Pt9a9VxFtrSuHHbuuzRcD9Zs2gRzf10IOf9HBU88QRN79WT/uDfFBN4rs3yaSLP35GnXSLuKOz+KiygmV8P5nbzHc1k2/kTJ8Z4cdqI/HvT2tW08MdRNINfLlZb5WHYwu+/2zZPAMuFk1P4ng/l520IzR75PW1w5m7cXBbzQ4yyUC/Ub2FG5rbv3Xot5N7mrK+/teqF33pJbq71eTTcf6/IyLJ2Kec/+zS/NO3dwPa39rU6chA7ZKhouJWVF2FD/zQe7BsVeaMEgVVawCKtB02k8csCn0uawuyKkKNuZ6eXJdq1iFcPq83zf7TUsdC/9ct96fgJVu8CfgslPMyY3LI1rdx2kpZPScqDD/iW7JONC+tORYVei4ad1G5Lzj88kNGvAJjGv6MM/tpP4rf9znHqZdeK/+ZXjHLhWvtxd7m61o4cxE4qOv8PSL3ysXAugxNsa1yR/2z7wwPr4uxK6ybON1Ff4mbjraE3CPuniKmH/Uns36z0KNf+PBb2Z5H0Uel84PmOP7DTRH/j/sv+xvk/0/7UDI6tlTa6EcTJZdsX1p2z/2ddO8PKJ8qE4fl71Aco003r5ODBP8XFlMZDtTxMVPIYGwFti7vbvQNvswXc3Oz88F/3gbI/1cuxwF/h24iNa+9+6v5dy9P+r9NinP/jPxFLDfjU/SaSl7SO/sb+DrlGpNem+zlg/8v9u2tvI9ZSARq8kyJig7+5rCI9hCR2fLhNECs4CwYPpZTjT7JWsqwZ+7oNacrJp9G6RYstGxuRJptExcGRg6QgJJF4LOExd+pFF1NqvQZUgNWaw+wTrSbD72CMHWAHE8vWOy6pB5UCRw6SgpBE4rFw5GiacnBNKmrahIoRp4F7BpPrNaU5AwY6FtABloOkHlQaHDlICkISicf6ZX9R5sknUVFdO44C9isgaC1gzxvYMpAUhMqDIwdJQUgisXAf8LS77qLxx51As956l9Z7loiTqFwQ/T8Ke6O3AhcQ3wAAAABJRU5ErkJggg=="></a>
              </div>
            </div>
          </div>
          <div class="clear"></div>
        </div>
      </div>
    </footer>

    <footer class="page-footer visible-xs hide-on-app">
      <div class="links hide-on-app">

        <ul class="js-accordion">





          <li>
            <a href="https://www.a101.com.tr/baskets/basket/#" title="A101 Kurumsal">
              <em class="icon-plus"></em>
              A101 Kurumsal
            </a>
            <ul>








              <li>
                <a href="https://www.a101.com.tr/hakkimizda" title="Hakkımızda">
                  Hakkımızda</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/yonetim-kurulu" title="Yönetim Kurulu" rel="nofollow">
                  Yönetim Kurulu</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/reklam-filmleri" title="Reklam Filmleri" rel="nofollow">
                  Reklam Filmleri</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/bilgi-toplumu-hizmetleri" title="Bilgi Toplumu Hizmetleri"
                  rel="nofollow">
                  Bilgi Toplumu Hizmetleri</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kisisel-verilerin-korunmasi" title="Kişisel Verilerin Korunması"
                  rel="nofollow">
                  Kişisel Verilerin Korunması</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kariyer" title="Kariyer" rel="nofollow">
                  Kariyer</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/a101-calisma-saatleri" title="A101 Çalışma Saatleri">
                  A101 Çalışma Saatleri</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/site-haritasi" title="Site Haritası">
                  Site Haritası</a>
              </li>













              <li>
                <a href="https://www.a101.com.tr/iletisim" title="İletişim">
                  İletişim</a>
              </li>
































































































































            </ul>
          </li>

          <li>
            <a href="https://www.a101.com.tr/baskets/basket/#" title="Sözleşmeler">
              <em class="icon-plus"></em>
              Sözleşmeler
            </a>
            <ul>
























              <li>
                <a href="https://www.a101.com.tr/uyelik-sozlesmesi" title="Üyelik Sözleşmesi" rel="nofollow">
                  Üyelik Sözleşmesi</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/mesafeli-satis-sozlesmesi" title="Mesafeli Satış Sözleşmesi"
                  rel="nofollow">
                  Mesafeli Satış Sözleşmesi</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/on-bilgilendirme-formu" title="Ön Bilgilendirme Formu" rel="nofollow">
                  Ön Bilgilendirme Formu</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/acik-riza-metni" title="Açık Rıza Metni" rel="nofollow">
                  Açık Rıza Metni</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kisisel-verilerin-korunmasi-aydinlatma-metni"
                  title="Kişisel Verilerin Korunması Kapsamında  Üye Müşteri Aydınlatma Metni" rel="nofollow">
                  Kişisel Verilerin Korunması Kapsamında Üye Müşteri Aydınlatma Metni</a>
              </li>







              <li>
                <a href="https://www.a101.com.tr/is-sagligi-ve-guvenligi-politikasi"
                  title="İş Sağlığı ve Güvenliği Politikası" rel="nofollow">
                  İş Sağlığı ve Güvenliği Politikası</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kalite-politikasi" title="Kalite Politikası" rel="nofollow">
                  Kalite Politikası</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/cevre-politikasi" title="Çevre Politikası" rel="nofollow">
                  Çevre Politikası</a>
              </li>
























































































































            </ul>
          </li>

          <li>
            <a href="https://www.a101.com.tr/baskets/basket/#" title="Yardım">
              <em class="icon-plus"></em>
              Yardım
            </a>
            <ul>


              <li>
                <a href="https://www.a101.com.tr/users/orders/?track=true" title="Sipariş Takip" rel="nofollow">
                  Sipariş Takip</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/iade-iptal-kosullari" title="İade / İptal Koşulları" rel="nofollow">
                  İade / İptal Koşulları</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/bize-ulasin" title="Bize Ulaşın" rel="nofollow">
                  Bize Ulaşın</a>
              </li>































              <li>
                <a href="https://www.a101.com.tr/islem-rehberi" title="İşlem Rehberi" rel="nofollow">
                  İşlem Rehberi</a>
              </li>






























































































































            </ul>
          </li>

          <li>
            <a href="https://www.a101.com.tr/baskets/basket/#" title="Aldın Aldın">
              <em class="icon-plus"></em>
              Aldın Aldın
            </a>
            <ul>
























































              <li>
                <a href="https://www.a101.com.tr/aldin-aldin/?category_ids=37" title="Elektronik">
                  Elektronik</a>
              </li>





























































































              <li>
                <a href="https://www.a101.com.tr/aldin-aldin/?category_ids=58" title="Ev &amp; Yaşam">
                  Ev &amp; Yaşam</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/aldin-aldin/?category_ids=67" title="Anne &amp; Bebek &amp; Oyuncak">
                  Anne &amp; Bebek &amp; Oyuncak</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/aldin-aldin/?category_ids=361" title="Kozmetik &amp; Kişisel Bakım">
                  Kozmetik &amp; Kişisel Bakım</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/aldin-aldin/?category_ids=37" title="Elektronik">
                  Elektronik</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/aldin-aldin/?category_ids=72" title="Oto Bahçe &amp; Yapı">
                  Oto Bahçe &amp; Yapı</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/aldin-aldin/?category_ids=1555" title="Giyim &amp; Aksesuar">
                  Giyim &amp; Aksesuar</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/aldin-aldin/?category_ids=160" title="Kitap &amp; Kırtasiye">
                  Kitap &amp; Kırtasiye</a>
              </li>


            </ul>
          </li>

          <li>
            <a href="https://www.a101.com.tr/baskets/basket/#" title="En Çok Satanlar">
              <em class="icon-plus"></em>
              En Çok Satanlar
            </a>
            <ul>


























































              <li>
                <a href="https://www.a101.com.tr/elektronik/televizyon/" title="Televizyon">
                  Televizyon</a>
              </li>







































































              <li>
                <a href="https://www.a101.com.tr/elektronik/cep-telefonu/" title="Cep Telefonu">
                  Cep Telefonu</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-bezi/" title="Bebek Bezi">
                  Bebek Bezi</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/elektronik/robot-supurge/" title="Robot Süpürge">
                  Robot Süpürge</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/kadin-parfum/" title="Kadın Parfüm">
                  Kadın Parfüm</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/elektronik/camasir-makinesi/" title="Çamaşır Makinesi">
                  Çamaşır Makinesi</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/erkek-parfum/" title="Erkek Parfüm">
                  Erkek Parfüm</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/ev-yasam/spor-outdoor/" title="Spor &amp; Outdoor">
                  Spor &amp; Outdoor</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/elektronik/kahve-makinesi-elektrikli-cezve/"
                  title="Kahve Makinesi &amp; Elketrikli Cezve">
                  Kahve Makinesi &amp; Elketrikli Cezve</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/elektronik/saglik-kisisel-bakim/" title="Sağlık &amp; Kişisel Bakım">
                  Sağlık &amp; Kişisel Bakım</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/elektronik/akilli-saat-bileklik/" title="Akıllı Saat &amp; Bileklik">
                  Akıllı Saat &amp; Bileklik</a>
              </li>
















            </ul>
          </li>

          <li>
            <a href="https://www.a101.com.tr/baskets/basket/#" title="Popüler Kategoriler">
              <em class="icon-plus"></em>
              Popüler Kategoriler
            </a>
            <ul>


















































              <li>
                <a href="https://www.a101.com.tr/elektronik/" title="Elektronik">
                  Elektronik</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/ev-yasam" title="Ev &amp; Yaşam">
                  Ev &amp; Yaşam</a>
              </li>









































              <li>
                <a href="https://www.a101.com.tr/giyim-aksesuar/" title="Giyim &amp; Aksesuar">
                  Giyim &amp; Aksesuar</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/anne-bebek-oyuncak/" title="Anne &amp; Bebek &amp; Oyuncak">
                  Anne &amp; Bebek &amp; Oyuncak</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kozmetik-kisisel-bakim/" title="Kozmetik &amp; Kişisel Bakım">
                  Kozmetik &amp; Kişisel Bakım</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/elektronik/cep-telefonu/" title="Cep Telefonu">
                  Cep Telefonu</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/ev-yasam/mobilya/" title="Mobilya">
                  Mobilya</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/elektronik/robot-supurge/" title="Robot Süpürge">
                  Robot Süpürge</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/anne-bebek-oyuncak/bebek-bezi/" title="Bebek Bezi">
                  Bebek Bezi</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/elektronik/beyaz-esya-ankastre/" title="Beyaz Eşya &amp; Ankastre">
                  Beyaz Eşya &amp; Ankastre</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/ev-yasam/spor-outdoor/" title="Spor &amp; Outdoor">
                  Spor &amp; Outdoor</a>
              </li>






















































            </ul>
          </li>

          <li>
            <a href="https://www.a101.com.tr/baskets/basket/#" title="Özel Sayfalar">
              <em class="icon-plus"></em>
              Özel Sayfalar
            </a>
            <ul>






















































              <li>
                <a href="https://www.a101.com.tr/aldin-aldin" title="Aldın Aldın">
                  Aldın Aldın</a>
              </li>

























































              <li>
                <a href="https://www.a101.com.tr/haftanin-yildizlari/" title="Haftanın Yıldızları">
                  Haftanın Yıldızları</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/cok-al-az-ode/" title="Çok Al Az Öde">
                  Çok Al Az Öde</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kampanya/haftanin-cok-satanlari/" title="Haftanın Çok Satanları">
                  Haftanın Çok Satanları</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kampanya/gecen-ayin-cok-satanlari/" title="Ayın Çok Satanları">
                  Ayın Çok Satanları</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kampanya/sadece-online-ozel-urunler-a101/" title="Online Özel Ürünler">
                  Online Özel Ürünler</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/kampanya/ucuzunda-ucuzu-fiyatlar" title="Ucuzun Da Ucuzu Fiyatlar">
                  Ucuzun Da Ucuzu Fiyatlar</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/haftanin-yeni-gelen-urunleri/?sorter=newcomers"
                  title="Yeni Gelen Ürünler">
                  Yeni Gelen Ürünler</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/a101de-alisveris" title="A101&#39;de Alışveriş">
                  A101'de Alışveriş</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/a101-gunu" title="A101 Günü">
                  A101 Günü</a>
              </li>




































            </ul>
          </li>

          <li>
            <a href="https://www.a101.com.tr/baskets/basket/#" title="Popüler Markalar">
              <em class="icon-plus"></em>
              Popüler Markalar
            </a>
            <ul>












































              <li>
                <a href="https://www.a101.com.tr/markalar/apple/" title="Apple">
                  Apple</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/adidas/" title="Adidas">
                  Adidas</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/arzum/" title="Arzum">
                  Arzum</a>
              </li>













              <li>
                <a href="https://www.a101.com.tr/markalar/birkenstock/" title="Birkenstock">
                  Birkenstock</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/braun/" title="Braun">
                  Braun</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/calvin-klein/" title="Calvin Klein">
                  Calvin Klein</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/casio/" title="Casio">
                  Casio</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/crocs/" title="Crocs">
                  Crocs</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/columbia/" title="Columbia">
                  Columbia</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/flavel/" title="Flavel">
                  Flavel</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/lenovo/" title="Lenovo">
                  Lenovo</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/king" title="King">
                  King</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/nike/" title="Nike">
                  Nike</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/russell-hobbs/" title="Russel Hobbs">
                  Russel Hobbs</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/seg/" title="Seg">
                  Seg</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/skechers/" title="Skechers">
                  Skechers</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/stanley/" title="Stanley">
                  Stanley</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/ugg/" title="Ugg">
                  Ugg</a>
              </li>



              <li>
                <a href="https://www.a101.com.tr/markalar/xiaomi/" title="Xiaomi">
                  Xiaomi</a>
              </li>








































































            </ul>
          </li>

        </ul>
      </div>
      <div class="fast-links hide-on-app">
        <ul>
          <li>
            <a href="https://www.a101.com.tr/hakkimizda" title="Hakkımızda">
              Hakkımızda
            </a>
          </li>
          <li>
            <a href="https://www.a101.com.tr/kariyer" title="Kariyer" rel="nofollow">
              Kariyer
            </a>
          </li>
          <li>
            <a href="https://www.a101.com.tr/kiralik-yeriniz-mi-var" title="Kiralık Yeriniz Mi Var?">
              Kiralık Yeriniz Mi Var?
            </a>
          </li>
          <li>
            <a href="https://www.a101.com.tr/bize-ulasin" title="Bize Ulaşın">
              Bize Ulaşın
            </a>
          </li>
        </ul>
      </div>
      <div class="follow hide-on-app">
        <div class="title">
          Bizi Takip Edin
        </div>
        <ul>
          <li>
            <a id="facebook" href="https://www.facebook.com/a101iletisim/" alt="facebook"
              rel="nofollow noreferrer noopener" title="Facebook"></a>
          </li>
          <li>
            <a id="twitter" href="https://twitter.com/A101iletisim" alt="twitter" rel="nofollow noreferrer noopener"
              title="Twitter"></a>
          </li>
          <li>
            <a id="instagram" href="https://www.instagram.com/a101iletisim/" alt="instagram"
              rel="nofollow noreferrer noopener" title="Instagram"></a>
          </li>
          <li>
            <a id="youtube" href="https://www.youtube.com/channel/UCFomZfoEfoveaRbIDjAtsZw"
              rel="nofollow noreferrer noopener" alt="youtube" title="Youtube"></a>
          </li>
          <li>
            <a id="tiktok" href="https://www.tiktok.com/@a101iletisim" alt="tiktok" rel="nofollow noreferrer noopener"
              title="TikTok"></a>
          </li>
        </ul>
      </div>
      <div class="apps hide-on-app">
        <ul>
          <li>
            <a href="https://itunes.apple.com/tr/app/a101/id1131194413?l=tr&amp;mt=8" title="App Store"
              rel="nofollow noreferrer noopener">
              <i class="sprite app-store"></i>
            </a>
          </li>
          <li>
            <a href="https://play.google.com/store/apps/details?id=org.studionord.a101&amp;hl=tr" title="Google Play"
              rel="nofollow noreferrer noopener">
              <i class="sprite google-play"></i>
            </a>
          </li>
        </ul>

        <div id="ETBIS">
          <div id="79F43C1D5210486889B4F613E5B497FB"><a
              href="https://etbis.eticaret.gov.tr/sitedogrulama/79F43C1D5210486889B4F613E5B497FB" target="_blank"><img
                style="width:90px; height:110px"
                src="data:image/jpeg;base64, iVBORw0KGgoAAAANSUhEUgAAAQQAAAEsCAYAAAAl981RAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAIiySURBVHhe7V0FoBXV1v4VOzHoDhFQ7EJFfdiiYiDP7kCfHWBgICgWdiMoqChKKQIqBnm53UGDNAoi3a5/fROcc9asOXfPnXvuvcD53vsEzlk7Zs6eb3asvfb/Magq8YwzziCJlStX0qGHHqraSz7xxBNOqvhYtWoV1axZU81Dslu3bk6qCCZPnqzamvKxxx5zcoogNTXVY7fPPvvQwoULHYsILr30Uo9tRfGEE05walE6OnXq5El/3333Od9GkJOT47Hz4zfffOOkio/c3FxP2t12241mz57tWJQPtmzZQk2bNvWU9cUXXzgWEXz88cceuyrAm5jboBlUGpOCEGuXFAQvk4JQ7kwKQlIQys6kIMQiKQgJZEUJwurVq6lGjRpqHpKVKQh77703LVq0yLGIoDIF4fjjj3dqUToqUxDy8vI8aSEIc+bMcSzKB1u3bk0KQqIYVhAef/xxJ1V8/Pvvv7TvvvuqeUg++OCDTqoIwgrCo48+6uQUgfZGA//55x/HIoIrrrhCta0IHnnkkU4tSsfVV1/tSa8JQmZmpsfOj8OHD3dSxceMGTM8aSEIf/75p2NRfmjevLmnrB1GEF566SX68ccfE84bb7zRU3YQQXjhhRc8eT7//PN0/vnnl8qLL77YalgyvcZp06Y5NYkgiCD06NHDk2evXr08dbrppps8dj/88IP18EtbbbgDO5le48iRI9X7+fTTT6v2kgMGDPDUx4+1atXylKMJAoZwWlkakV4rS/LUU0/1lL3LLrtQu3btVPuy8rzzzrN6crIsU0Fo1KiRep2JYP369T3lM+MLArquFYFXXnnFU3YQQZg0aZJjEUHv3r09dn5cv369kyo4ggjCb7/95qSK4NVXX/XYHXXUUc63sdh///09thpNe0dAgwYNPOnRYExQVFTkSRuEmiAEwWWXXabmW9VoKgh+v3si0Lp1a0/5zPiC8MsvvzjJEwu8zWXZQQRBa8Avvviix04jHrKlS5c6qYIjiCDgjSyhieHJJ5/sfBvB2rVrqW7duh5bjQ899JCTKj4ghPXq1fOkHzp0qGMRHxkZGZ60QRhWEK666io136pGU0E44ogjnG8Tj8MPP9xTPjMpCElBSApCopkUhIAIKwhTpkxxLCJ46623PHYaDzjgAGu5qKwYN26cmq/GsWPHOqkieO+99zx2YQXhjjvucFKVDixnyvSjRo1yvo2PkpIST9og7Nq1q5NT2ZAUhLKj3AQBb0S81cpKbaknrCDcfvvtnnIuvPBCj53GPffck5599llP+lmzZjmlxsfcuXOtpUMTYgJRltOhQwdPnYIIwuWXX+4p5/vvv3dSRbB48WJP2SCWUmX6nj17qraS6IXJtH5s0aKFp+6nnXaaJ8/PPvvMqXHp0ATh2GOPVcsvb958882esv0YVhD69u3ruU+m7Nevn5NLLMpNEKDqmq0pMVsuEVYQEkHTJa0gOOecc9SyJIMIAnooJkhJSfGkBZGvhCZSGlu2bOmkKB3XXXedmockZtpNoQmCtoybCMyfP99Tth/DCAKWxQ855BCPrSmxCqWh3AThueee89gF4c8//+zkFEFVFATTbnMQYIlTK0syiCB89913jkV8pKene9LutddetGDBAsciAlPfhrCeihqPOeYYJ0Xp0AThf//7n/NtYpGfn+8p249hBeGwww7z2JrST7STghCQSUGItdWYFITYsv2YFIQ4DCMI8NRDI5a2iaDpgxYEpuvmcKTRcOCBB3psTVcEggiC6fyLJlx+6Nixo5qHJBq/KTRBMF1hCYsggvDpp586qSJICoLDMIKwZs0aaxyON1M0sVIg05uyWrVqdPTRR3vy1JydMDGHpbayEp5xWh0k4RIs02Iy9+yzz/bUc/z48U7t4iOIIGDSTJajOTC1atXKU08/3nnnnZ48NV577bVOLUqHJgj4TCs/DDFxLKEJArwf27Rp47mm0aNHO6kiSAqCwzCC4AfTN5pG+CGsWLHCySk+4CKt5VERDOt7H0QQNLz77rue9EFo2pMJAk0QEsHbbrvNKTECTRDwcsFkowmSguAwEYJwwQUXeNKbEoLw119/OTnFRxB36PImHl70UMqKsIJg6tfhxyFDhjg5lR8qShDQu5HwEwTTHZRJQXCYCEHAxhKZ3pRBPBWx2UvLoyLoFw/BFGEF4c033/SkD8Jvv/3Wyan8UFGCcNdddzklRuAnCKb+K0lBcJgIQTBd39eI3WmmgmDqDp0IhhWErKwsT54QhCVLljgW8fH222970gfhsGHDnJzKD6YrF2GpCYIWYwGcOXOmYxEfSUFwmAhBuOiii6wxdjR33XVXT56Y9JF2Bx10kLEgwPNLpk8E8aaRdfcTBLhdb968uVTCvVvmCUHAhJlmL/n666970mv3E8Tn0vbrr7/25ImAIhJ4AKSdHzt37qyWb0qtnho1QSgoKPDkB69X0yhMSUFwmAhBwNgaP0Q0MVMu88SMr7TDA2G6lwHLnjJ9Ioi3qay7nyBg30KTJk1KpebDgAcCqweavaTmLYcZdVl3xIzQyoLHnMwTbUkCW6qlnR+xnCfLNyWCpmgrJxo1Qdi4caMnT8wfQKhMkBQEh4kQBA1anIGweVYUtIhJfoIQZv4kLE866SSnFrGA+7FmL6k9aNrQxo9hVy60cGcatXqGRVIQHFaUIGjj/dNPP935tmpjew6yijdnw4YNVXtJbftzImIqasCbHL0MLV/JpCA4TApC5SApCLq9ZFIQSmfCBQHbZTVbU2p7BBIhCNoy2VlnneV8W7UBL0lZd1BzeqmKgmDqOaoJAjwDNVuNYQQBaNasmZqvpOaYFBZBBME0KrjG2rVrOznFotwEAcstAwcOLDO1UOKmgrBu3Tq655576IYbbiiV2Bcv88TElmarEeN4CUQ8knaou8SGDRvo3nvv9dhq/Oqrr5xUEcBRSt63QYMGWdcvYSoIGC/LPINQ276sCQJWDjC2l+lPPPFET3pNEJYvX+5Ji8lDbVObJggIQqPdZ8nrr7+e9ttvP0+e2Bwly0dvU6Z/8sknnRLLBlNBALAVX9bJlH57cspNEBIBU0HALL+2nJgIavEQEEhF2mk/Is56wBKUtNUYdneeqSC0bdvWSVE2IEiHzFMTBD9gj4JMHySEmta91wThtdde89gFodaD/eSTTzx2WKEIgyCCkAjsEIJQ2dufNU9FbWciNmGhqyZtNWJ5NAxMBQFv6DDQhmBBBMH0oBYNmzZtUlcuNEEIu+cC/hISH374occOS65hkBSEOEgKQtmRFIRYJAXBDGUSBPi/VwS0bt7OIgiPPPKIk6psMPVDqGxBuOSSSzzpMR9kgp1FEKr8uQxYUdAmKsqbV155pafsIIKAOAFy0sd0UhFHjMGFV9omQhD+85//eMrHKUnyfmj757FMhg1C0vbhhx/25IkHVZatCQI8NLELUeb5xx9/OBYRmAqC36QiYh3Kej711FMeOy1UfVhBgHu6LNtvUjGMIGBFAF6m8prgxSihCQJC4su0iWKdOnU85TPjC0JlMoggIHiIRJBlR+3hTYQgaAFRtd6RtnaMPLVjwrQzKbQGrAkCVi3g3yBttZUPU0HwW3bUZru1EPSYPJQIKwjHHXec820stGXHMIIAgT344IM9tlrkY00QqgB3DEEwPahFc0zyOw4+EYKQiINatAdN24ikCUKQg1qCCILmmKRtf9Z2UGoxFcMKAiJiSfg5JoUVhOTpzwliUhBikRSEpCBUAKuuIGgPhZ8g/P77745FBNrmpiCCoK2wvPzyyx477UHDOFobo2lu21o9Mf8hgfGp9vCGFQSti6s9aGEFQTs8RnvQ/Lr3jRs39tia1hOxHzVoD68Wt0F7eOFOLAFB0EQbp2RLvP/++x67KsCIIEAtqxL/+9//OrcuAj9BwGk/ciuqtv05iCD079/fkyd6HbKeCK0u7bCFV3M3hYOLtEVYNpkn4jtIO+SpHakeRhDgUXnKKad4ytd6XGEFAfMF8po0Ry/Mfku76dOnq2KoCQImzOT1IICOzNNv+zN6LdIWn8k8EbZPAoKAnq20HTFihGMRAeZppF1lk0U3IgjoQlUl4uZK+AkCAorIYBWaR2MQQdDyxKqLrOfEiRM9dqDMzy9PCJfME6csSTtQyzOMIACybBC9EYmwgmD6GwUJuqIJAnpn8nqwpdo0T62eXbp08eQJatDstEAwWj0rm/zbRQTBqWeVhp8gmDKIIGiEIEhokYiCUHNM0uIf+jGsIJgirCAkgpogaEB0Iy29KbUgqzsi+EWQFISwghDkOHiNmiBo25/9mBSE0qEFnAnCRGx/rorY6QQBpw1LYEXAVBAef/xxJ1UEieghpKWlqbYatZWLN954w2MXVhC0MOyaIKDrWb9+fY9tImgayTmsICR7CFUUYQVB2/GHmXZTQdC2vAZ5eDVqghAkJoC2PKo9vH7hzkzxzjvvePLURAbzD9pMeyJoetZDkKArGm+//XYnpx0bZRKEjz76yFoaKivRHZbAso60034EP0HA2jMmjkrj4MGDPeVgjRoTRzJPjZjll+l9NomoRLdb1gkrFzJPuHJLOwxNtJULeNvJ9NobGh6J0i4ITfOE8CAmgay/RoihzFMjfp8ffvjBkx5vblk+fEUk4JEp02KeRlu5wKqPtNVcubFKIctOBI8//ni1fA3Ysq/lEYDBBQFvSZiXlZqffvfu3T12WnfUTxDCnG9YkdR8GzQ/BL8TkLUGXBVpehIWXi5aesndd99dzfPyyy/32AaJbqS5LmtzMhrCDkOCcOrUqU6p8fHBBx+o6QMwuCBUZkxFP0HQ1s01YIlQpq1IJsJTsapxjz32MH6jmR7+AkHQDlzVTm4yDTiDuQ6svcv0mqeihiCnP4chlkbhh2ECLZBLQCYFoSKZFIRYJAWhdO7wgoCxoARm76Udxk4aNGcWzS1WQ2ULwoQJE5yaRKDt+NMEAashpmHZKpumB55q1+5H7czEMIIANG/e3JPeVBCys7M9aRNBCMKyZcucUuMDLtJaHgFYPoKAG4ttvCbUlB5Ld9IOk20IHhJN7KnHG1XamjZATRDwkOGaZJ7wf5e27du399hpRN1xiKxMf9lll3muCT0haacJAt5o8P3XyjPhAw884CkHk3XPPPOMxxYbd6StRrj+yrRY8oRvhwQaq7x2rWyNyBO9QwlTQUD4eln2Qw89RAceeKAnvakgYE5Dq6spgxxUe+utt3rqrxGxNbSyTPnqq6+WjyCcd955zrflh8zMTE85oOYGagpNELB3X3OTxsMrbXv06OF8WzrCdO81QQgLzIrLchBfAcuuEtdcc43HViP2QZgCbUSmN42Y5AdTQfBrSxpNBSEssJdBKz8Mb7zxRif3sqFMy46aICASUHkDKweyHDy8pjPYGjRB8DsOHhuMpK3mqajBb/uzKRMhCEGOg7/iiis8thq1lSA/hImp6AdTQQiyIlBRgpCI7c9hz49ICgIzKQhJQYhmUhAcOJ+VCk0Qzj33XOfb8oOfzwB85csKrWFAZLANWKJjx44e24oSBGwBLm/4uVhrY3Ns6dZsJeGUZYpECIL2G2FnooQ2XPKjthKUCCCsmlZ+GJarIIwZM4YktdlNTRDg7SfTwlsNkW4k8KBLW41YQsGe82gi5DgCWEhbrdeAWWlph4kTWXeMozGek7Zwy5W2iRAELH3J63zwwQednEoHPOlk3UtKSpxvI8Ax7bIcPPjYDyDT49Qpaavx/vvvd3IvHaaCAIGS9fEj0ss64TeSdoiRIO0QrVqLUYkVL5k+EYRDmqwTNt/J+oCYeJa22hyVJghoi1r5GkePHh0RBIanAG19XxMEjVge1B5UbDDS7CW1bjMrmBohWVvK1IJvhGUiBAGRh8MAwT9knnfffbfzbemoXr26J73pMm4QmApCkAlA7XQtLRJRixYtnG9jYXq2YyKIlQMJrMBJOyw7ascfIr201QQBgXWkXRzGFwTN1dZUENAV13oYWgPWqDkmYTnrkEMO8diaxlQMy0QIgra5KQi08w6wpGYCDJW0N40WUzEsTAUh7OnPpjEVsbKkOSZVFO+44w6nJhFoDy8EAUMeCYSSl7aaIKC3KO3iMHGCgDVeTRAw36DZS4b1VNxZBEE7uclUEIIEWQ2LqiYIfp6KFUVNEAoLCz12fp6KlSIIWvDSnj17euw0QhA0BxU492j2klrsAjRgbcdfRQmC6Ym/EAQteKnGsIJw4YUXevLUHjQNfvdT64qHhTYBiLkKiSDRjbQVAW3rt98RaRUVt0GjNvmJTUyareZ4d9NNN3nsylUQ0IAlMTbH8dzRxFuSzUslhgzo6sj06OJqZUli0kemxRgrzJABnnlaWRrhPy/Tw9tP1kmbpce+Axy2YpKnJgh4e8ly/v77b9UpC6cqy3JM5yUwZMDDItNjklWWr1G7dj/cfPPNnnIweSrznDRpksfOj1rwUkxGSzuEypfl/Pnnn9bRadJW47777uv53fyIORmZHvs7pB2ciGSdEBpApkV7x8SxtO3cubMnz3IVBDQ4yQ4dOljHYEVTm9TTiK4OegkyPSastLIk8ZDLtLjZyFeWZSoI8KzTytKoDW1w7bJOEC4JTH7i6HqZp3YOoyYImFiT5WCsv3jxYsciAhw9L8vB/n8T+NUTx9vJ8jUG8T9Br0mWg/gQMk88vNLOj9oSNERO2iGWhCwHQ09sUJK2GrWQdBoRoBVDHple85eAy7ysE2JJyLR4+BGWX9pqIlOuguCkjwGOPsNX5clff/3VyT0+8KbQ0ms0FQRtXsIPpmvxQUKTaeN9TRA0nwH0bjQnokRAc9vWqI3Ng0CLwnTkkUc635YftLE5OH/+fMciPkx3EUIQtDy18b5GP78O7UwKjQkXBByiiq/Kk9r2Zw2ap6IfTQVBC7LqB81TUaN2cpMfNJHRBEELsoroRNikUxFIhKeiBtOTm8JCc0iDwOLMBRNoB8pohCBouzKvu+461V5Sm+tALw6Hwmj2kgkXBNMJwCCEw5IJEiEI2kSlHxIhCBiCyfSmggAnmooSBC0SkUa/Leqm0AQhbK9DQ15enqccPLymu2SDCIImMqaC4Oehqm3T1qgJgt9EpQ/jCwKCkuKr8iSGAiYIEopcc0zSlkcRN84Upv4SQR4KTWCxpVvCz/e+ooYM2sqFRr8j0kyheY5qR6SFBbw0ZTngkiVLHIv46Nu3r5peEoKg7YvBKWSavSSOltNgGjoPE7cS8+bNU219GF8QEP0Xb9+yEC7GWGlA1tFENxOTa6URnlhavhr9XJelHSIkS2ACDj+YLB/x6WR6jZ9++qknLZbYMCEkgdlimb5Xr16e9FhSknboWWl7LuCRKdNrNF2KBDAxJsvXiLmOMEBkJZknTq2SwKoLxuHadZnw+uuv95QDV11M9mn2kujFyfRarwET3u3atfOkx+SpTK/xyy+/9KQFsbyq2UtCYGVaP3dozIvI9D/99FN8QQgLzYnIlGHDhpsCS2daJCLNKUuDX+Qc0+69FmQVy2GmMJ3nwTLo9grsicHMunZdJvTrdWg+GBq1COAYbmi2GhHt2wR+eWquyxpwxqmWXqOWZ8zmJuezcgOWszSfAVMGWREIA7+Tm7TzDjRoJzdh3VpbItRgGlPRD9rKhcawB7VUJvyOgzdlWE9F7eSmIDEVtePgNQTxVNQQJKaiFsk5KQiMpCBUfSQFISkIoWewTRFWELQNKfvtt5+69VuDFmg0yPKoFppMY9gJwMoGJty06zIhzpqUgCBoMRU1hhUEPKgmwDBTpoUgJCLIaqmCgDeVpBYQFW9Eaaf5lPsJAiZyMElTGrFvQJYTloMGDXJqF0EQQcCkpMwTEXpkWniRIeCltNWoLUWiAWu2GuGmrN0/ySeeeEJNH4aIMyCBXYSYcJO2mOmXwCSrtNOI05hM5xDg1SevHZ6GEnADx9K0tMVci8zTVBDw8GLTkswT80wSWAqV14lAqVqeXbt29dhqxHEGsmxtmzRYqiAwPIm0U5ZQOWmHH0HCTxC0mX4NQfbFm1LzggsiCIgSLO0qmz/99JNTu/goLi5W04ch4glIwJ1Y8/3Xus0vv/yyxy4stWXcIMAeA5mnqSBg2XHFihWORXyYnkkRhFqQVSyDarZlEgTT7c+aT7ufICTCU9GUQY6D1wQBbyppV9k0PXosEcfYaZ6KEATtOHjtpOZEPBRaTMUg0HwGggiC5qmooaJiKvp5KiYFgZkUBD2PsjIpCLF2O7wgaN1RjEWlnTYrjq6Ttr4/btw4xyI+ghyJbsozzzzTyT0WONVZ2mqCoB05V9k0DWbit8EnDP0EAdt2pa22VVkLZhKWQcLHacDJ2zJPOIpJ+AmCqfdjIoKsajEW/DwVtU1YMYKAH1cSbxUJKJu00xQU23LhNCNtMRGFh700BlFQOJ7IcjR3T2yckeWgJ6I1YE0Q4PghywlCbVYbkZU0W1Oi/hJolPI6tRnoXXfd1XKC0vKVxClNMj0+l8DqCiZKZXqc9CzrBKcsaacRK07adl+sPEhbTMzJcoIQbVnmiclHCU0QcD8hfFq+kjiNSpYThFrvGx6yspwhQ4Z47EB8Lm2ZEUFwrjPhSMSGKW1LddgJK00QwkLzGUCU3/KG5v2oEfEdECjEBNrbHA3TFNoOSi1ikh+0LcBwj5cIcl6kRi0smwZNEILwdsX7MQi0iEnlwIoXBNNNQ0GoDW169+6t2poyEYKgBUTFqk15o0+fPp5yNEIQTN1itdBkQQRB64qb7q/AUqbmmKTNS4Qdhpi6GYcVBC2mYhBoqyHlwIoXBNMgq0GIjRkS2vbnIEyEIJjGQwgL0wg/EATTHZTYoCPTBxGEMAe1+HkqmgZZDULTk5sqWxBMg64E5I4xZMDONYmwgqCJTFho24oTIQjatmKNEATTSTBNZIJsJ9fCiCFGpQkqUhC0XoeGgOcdeKjNuwVBwnsIcOUsb2rAqTOIVlMaMWPL1fJQs9WGDGEFAbEftWuS1E6O9gMmfWTdIQhh8tSAt7ksR7ufEAR4o8ry//33XyenCLBEKPPE6pJM60dtyIAlQmmnXXtYQYC3n6w7iM+lLbYgyzpp9NvlakosEWr5atDstKArmNTUrlOjdu3MiCBgo0d5ErPXWkwAbPpBVJnSiK4bVyuG2CMAd1dpqwUVDSsIWIrUrksSDd0UeBvLumOuQ+aJiEVhAB8QWQ5mv+U1olFg9UCWr/WOsE1c5gk7mdaPmvci4mVIO6xQSIQVBOzjkHVHRHBt5QQ+KbJOGk2DlvgRhwzLPLEvRQLiDD8faYtnQeaJSMzyOv3oszckIggMzaDMxDJRmJOatYhJWLZD9F4ThBUEUwbpNmvQVgQSEUYsyJjXdKZdC00WllrchrCCoLnWA2E2TCWCmis4BEETLo1BhiHang1m4gQBD6/pLi0Nmqci3iimIlNRghAkpqIGbEqReQbZ/myKIJ6Kps5OWLvW0oehFmQ1rCCE3f5cUUxEkFU/IMKzkkdSEMIyKQh6HmVlUhBiscMIAhhmcsyvAZs60lSUIIQNG6414EQIQpBZcS1orQYE7tDSh6GfIGhenpo7NGJcSju/YV1lnv6sEaKnwfScUM3F2g+I8KzkUT6CgMyxvTWacPO95ZZbrNnQshBr1DJPOI1ogUY1mAoCZtpxhLgsCw1T2sKPQNrhsBFZd+xBx8SeBJYDpS3Gt7KcsIKAbeuynHvuucdTdz/C/Vem16gto2IGG05MMk/EyJS2GjVBQOwCnDcp89TqichQMk/EUpB2OAJPm5iD96Qsxy+mgCRm+bE8K9OjFyltMVEo7RBHQtYThNu3tNWIzXdaeo1aAGRm+QiCNjsK+C0dmjCI04sGU0HAjcEbSEI7vQg7PSX8TivWgqxic5VmKxlWELRr94v5r0EL2mJKTCZjB6kEHkDNXjJIj0s7QDYsNYe0zz//XLWVRHvXVtY0QdGcshCFWtqBpr4iQYKs+rB8BCHI9mdTho2paCoIWP7RYulrB7Vox8EHialoejxcWEHQnIiCxFQ0PblJIwQBDVtC81TUGEQQNGensNQ8FRNxclPY4+A1BImp6MOkICQFwYukIMQiKQgBmQhBCDtkCLK5CXv4JTQXa20jkt8pS+vXr3csIjDd2BXkyDkN2r6Dyh4yaBu7NAYRBHi9anmEoTZkwPhcs5UMIgjakAH7SqRdEEHQnPkCsmoIApaFMEMaTfi5Y0xUVvbo0cOTp0aM7xB7QaZ/+OGHPbYInCrtMIEm7YLkib3+8n5g9lumRaNcu3atc3cjwNZvaduzZ09POZgsk3Z+RFxCmd50UhCTithtWdY8gwgCVmhknuhdyTyDEAFWZN2Rr2YrGUQQMJ8ky3nhhRc8dn6CMHHiRE96ba4CqzPyHvnxhhtuqBqCgO69RNg17iBxBrTITtqhtNowRFs7BtA4pK2250LbVuxHRL+R0I7q0sKIBYmYhH0cEqbdZj9ilUBCC4Ljdz9NUQ7d5jIziCCY0k8QTA/kDXI//y0thJopwwoC3rwSYWMqItSbCdC9RT3R1a1evfo2arEf0RWPtgFxfp4E3uRw/JC22h4BbBrCspikTFu3bl11XuKaa67x2CKEvQQ240g7P2qCgLMutXr6UeapxX7EcppMF3buCAezyjxNufvuu6ttyZQVKQim25+DHOGXFAQG6okGizfY8uXLt1FbisS8QLQNiE0/EvAuW7FihcfWNE+NWM7CerwEQtVJW21oAc88aedHbU7FtJ5+NM0Tv0cYhKknxF1rS6ZMCoJDzX0XD8Q+++yj2ksieKkETgHWbE1pGp8fDQHChYM2k9i5EdavAYKgRaC6+uqrVXtTaqs2cPrTbCXhnm2KGEHAzq+yEgooga44Jsyk7d577+2pNCa8oKzRxBtbpkVcPW1sXqdOHY8tdhGaAG8kCJqm7EnsXMBSM04sl21JY/369T3tEG3z999/97RlLDHK9NrJ0xi2SjtMME+YMMGTp+Y4hyV0mf6ss87ypPXjzJkzI4KAfQdlpdaVBTRbbelt1113tW5mNHEhMi26zdoR83DVlbZ+ddIA+50FuNIFM2bQ9PR0mpGZSTOjOMvhbIdzHM6N4h8O5zmc73CBxQxaGMVFYEYGLXa4xOFS5rKcHFrJb76qdOfxYkCQVtmWNPp5qMp2DMLTUabXJmmxNCztMNTDfJTME0MJmR6rDDI99rDItH7k5zAiCM49SThMDyfVDlXB2FgTBG1FIIkI1vK4OuuXsfTFk0/SC+eeS/cefDDds9dedN8+e9ODzIeZjzK7cu/tceZTzKf33oueZfZg9mS+yPa9ma/stSe9xnyd+Sbzbea7e+5JHzA/3HMP+pj5CbM/cwBzIL/1BjG/2mN3Gsz8ljmUOXz33WnkoYfQ+PbtKeehh2jhzz9XujhAEDDRaYIgm8UQhUlCWw3RjhoE8KaXtho1ZyfMP2i2Pqx4QTANsqrNNmMCTxOERMQ/3BGwYM4cGty7N3U76US6YbdqdB3fq1uYXfhhvIcf4Hv5gX2A+RDzEeZj/OA+znyK+TQ/tM8yezB7Ml/kNL2Zr+y+G73GfJ35JvNt5ru77UYfMD/kMj5mfsLsz/yMOZDfPF8yB1Xblb5mfsMcwhzGHM51GeHwe2bKBRfQ0pQUp/YVDwgCVlNMECTgDHxIJEyXXDFBHWb7s9/JTT6seEEw9dZr166dkyICzKhrh6qYHni6s2DJwoXUv3t3urVWLerE9+d65m38lr9z332oyz770D3Me5n3c6/gIeYjzMeY3bhn8ASzO/MZtn+O+TyzFxO9g5eYr3KPoA/zDeZbzHeY71m9gz3pIxaVvsx+zE+Z6CF87tdDYI5gjmT+wEIzatdd6Aeu549cxmzD49PLG6eccorVlTdBEL8ODBkkgvhgmAoChgwSVV4QTKMua+67iJ2o7YtPDhlsYNZkZL9+dGujRtSR78s1/Na+iUXgVubtzKosCKO5p/EjyPUG53zS176oCgQ8J00FIciDph2brwmC35ChRYsWHluNN998s5MigoCnfidOEPA2h38CglNEE2qJQKml8auvvvKkRZcO/gnSFmuy0lajpqAYhsAnHtGHt2egV/Bsp050Mf+UnXbdla7bd1+6gbm9CcJPIF/DL5zvsilTnKurGOAAVJyopLUdSQRuxWMTTUyOw6lLtk8sbUtogoDYHFpZmictluplOVobhl+GtPNjQo9ygx9CmMNetSCruOFahGUIj7TViJsrgR8LvQ4o6faKQv4xb23dii7ka+zMD/Y1LATbsyCMZf7M15LBvytmyisSprsyNWKm3jR2gSYIQWgaCDcIYvwQnM/KDX6eimGOg/eLqWjqYaatXGApEyG1teOxtwdk8H3qVKsmXcTXd9V++9J/mTuCIPxSbVcay9e0UDm/MZHQjoM3JQQB6/kmCCsI2jAkLJKCwNieBSEvLY0ur1nT6hl02n+/HUoQfsWffF05na8i77ExiUNSEBw4n5UbwgpCZmamJy2oBTMxFQRt0mZ7FYQF8+bRtS1a0Hl8XVewGFzJQrCjCcKvfG0TatWgNUo4ukQh7BFpppHGwwoC0pc3ShUErMkikGU0TZf4gggCPpPlYHMSgpJGEwFNtTkETRDOPvtsT3pMVEpsj4KwicfV3S67jM7i67xs//3pchaBHVEQftutmiUKC5XfLRGAs5BPeHIP4S4v2xeIIDqyLWPCTsJUEOCRiK38shw4Rklg3k2W7UctenmpgoCoRfgqmqabhoIIAi5Y2mEfhCk0QUCQEBNsj4Iw4NVX6Ti+xvbMc5nnMzFs6MC8hIklx8uZ8EHozLyGCaekG5j8i9OtzNuZdzLvZv6PeR/zAebDzMeY3ZhPMJ9iPs18jvk88wVmb+bLzFeZfZhvMN9hvst8n/kh82PmJ8z+zIHMz5lfMr9iwjHJSBDwJ9vPUHbDJgLwfZHtyI9+p0Fpbb5fv37OtxEEEQTTXocW0t+PmqCUKgh4y+KraD777LPOt/ERRBCwhCLtguyL1wTBdPvz9iYI2DTW+5576AnuITx79dX0HPP5q/9LPZm9mC/wGLg38yXmK8xX/9uZ+jBfZ77JfKtzZ3qb+S7zPeYHzI+YHzP7MvsxP2V+xmP3AczPmV8wB111FX3NHMz8ljmEOYw5nPkd83vmyKs60SjmaOYY5k/MsZ060S/MXztdSb9zPr9d1pGGci9mGL/9TQUh78YbnKtPLExjXoJt2rRxUkWAFRHNzdjUU1Gj3/ZnDUGCw2jtPSkIjO1NEIJs2qqKwAThpBtuoG/5NzIRhN/YLqttW8vpKtFICkIpgqA9aAheagL4ISC+nkyPrZwSmiAEiRKMnZEyvWkINfgh4MAOrQuVRGKwYNw4GrLHHjSChw4mgpDRqiVtVgKslDe0duRHPPgacHq0tMUBQxKmgVtB05cVDhzS0mssdcgwZswYkkTAS/4qhoh9IO3S0tKcLCPAKc04nhpegNHEbjKZHgFRpR02akg7P951112e9IjCJO0w6SIBj8rrr7+e5s+f73ySRKKxbuVKGt28GQ3j9mQiCOktD6fN671RrMsb6P3KduRHtBnZvhCxGcuW0vaNN97w2N5///2eZwsvJpkWp2Nph/5owCY/md6PWnuPEQSGp4KmhA+4KbTTi7QQapqnoh9/++03J1UEWhh2v4mgJCoW8D0cy+3AVBAyWrakLRXQQwiCGTNmeNoXqMW9NPVt0IYhFYlyEwR0tUyhbX8OG1NR2/6sRUgOe95BEuUDSxDatTMWhEx+4Wz9tyLdk0pHQUGBp33BtX727NmORQSmMRXDRpwOi3ITBC3Iqh8qUxA0T8UkKh4rFy2i72vVouG7lC4I1irDDRWzyhAEWjwEP0/FnU4Qgjxo2kSldohqkCCrOKxE4pVXXvHYhQ3xnUR44D0/pUsX41UGCMLMHj3sxFUImOiT7QuCoI3NTSMk+21/riiUSRAQJBVBSqJ56aWXOllGwJlbS3qYxY+mNpMLZydpN3LkSI+dH7/99ltPevQ6pB0CYEg7l9v7cl5VB4RgOb89J95yM33Dv4WRH8Kuu1hDhiVjxtiZJBjYCr9hwwbnXxHgM9lecHKSbF8QBHglSlvTMygRMl2m9aNWTw1YCtXSa1y2bFlwQcCBp3jQo4mZegncXCzNmByGgX3g0g4RZKWdHzE7K9Nr0Z2xDCrtQETA1U5FCoPNLDAYT04cN476vvcePfPwQ/TonXfSffy2uKtzZ7qzUye69+qr6bFbb6Un+fOn7rzD4tN32HyG+Ryzh8OezF533E4vMF+8/XbqzXyZ+QrzVeZrzD7M15lvMN9ivsN89/bb6D3m+8wPmR/ddht9zOzL7Mfsz/yUOYA5kPkFcxDzq9tupa+Z3zC/ZQ7leg5jjmB+xxzJ/IE5ijma+SPzp1tvoZ+ZvzB/Zf7OHHfLLTSR6/7L5ZfTt3yf4ak4lMXAxFPxF7ZNad2KNq5Z49zVxAK91/79+zv/iuDTTz/1tBlstJPtC8Tn0hbRlDVbSQiKTOtH7VBaDfBh0NJrrF69enBB0M5Q0ADHpCAPdWWzPM5lQBDYn/ht1vWBB+giHkYd3aABNdpnH6rLb7o6XEZ9ZmNmE2YzZnPmYczDmS2ZrZlHMo9iHsOEe/IJzBOZpzDbMk9nnsHEPga4Lp/DxAYnzXX5SuZVTOm6jLiKtzE11+WHmH6uyz2YZXFdHsCE6/LXzCB7GRATYeqTZg5m5QH4vsD9VwKRmLU2U5nEWY4mKHPEJIZm4GFYT8WqSPRawkRMQu/iRR7ntjv2WKq95550MOdZh9W+EfdSmrEotjhgf2p54AHUmt8eRzLbMI9iHsM8jnkC80S2OZnZlu1PZZ7OPIN5FvM/zHP234/OZZ7PvJB7RB2YlzA7MnfEzU3Y+jyhdm1aXc49t3jwC7Ia9lzLRNB0+3OZYyoyNAMPTQUBQ4YdXRDgfNW7Z09q1bAh7c/51OAhSUN+eJsceCA1YzZnHsY8nMUgKQgBBKHarlYYtdlvv+3c6YpB27Ztk4IQBc3AQ1NBwGSGFjK9KrIsgpCelkbt+Y2yN6evyQ9DQ37wGzEbM5OCEE4QxvA9zbryCtpSwRO98MzV4gzgAFmt3VQmTQUhyPkRzIggYNORCbFECF+C0gjfBG0C8aWXXlLzNeGIESPUqMsacZ6eTP/666+rtkEFYcg331B97v3sx2nrcX0aMJOCUA6CsFs1GsX3dPJpp9I6wy2/5Yn09HTq0qWLpy1jFUy2Jbjga21JI/bVyPSmRPyRevXqefI0FQT0YrV8taPomBFBcNKXCggCzMtK+BeEgXYmnkbsj5DwO34riCAMGzqUDuKHpzo35HrVqycFoZwEAecyjOTfYjK/SNYoB6ZWFK688kpP+0AkZglMQks7Pw4LGRdSC9oSNoSaFjWaWfGCAHUqK/xObtKobX/W1o5BU0HIyMigulz+gdyI6x5Uneryw54UhPCCgFObwKw7bqcNyhJ2RULbd3DXXXc530YQ9uQmU8CfRzuoJawg+ESGSgoCaCIIWFI87aSTae9ddqE6LAZ1qh+YFISQgoC9DODPTZvS7BAPTXkiKQgOHLtSsb0IghZCTduQApoIwut9+tAebFuLH/DaLAZJQSibIHzDQwN4KoKjGjWivO7daY0S36+yoAVZ3REFoXbt2p48mRFBwGSfpPaQJEIQJk+e7ClbOzE3iCBgUlPmiQkjzbY0QUDo98ObNaP9uWHX5Ae8Fj/ctZl1+EGuy6zPbMBsyGzEbMxsymzGbM6EH8LhzFb8YB/BPJLZhnk081jm8cwT+EE/iXkKP+Btmacx2zHPZJ7FPJsf9HOY5zEv4Af9IubFzEuZl/GDfgWzE7Mz82p+2K9lXs+8kR/0W5i3Me9g3sUP+93M/zHv4wf9QebDzEeZXfmBf5z5FPMZftCfYz7P7MXszQ/8S8xX+SHvw3yD+RbzHeZ7fF8+ZH7ED3xfZj/mp8zPmDjs9Qu+xy6/4c/GnnUmFb7+Oq02PNSkojBkyBA6+uijPe0jEYKQm5vraZ+IeCQRRBDy8vI8efoRPWh4HUeza9euEUFgeAodPXq0U1QEiRAELcjqUUcd5XwbQRBBCMLSBOGtN96w7PbdbTfaj2333303OoB5IP+7OvNg5iHMQ5nwRajJrM2sw6zLrL9bNWrAbMQPRxNmU2Yz5mHMw5mtmEdU25XaVNuFjuY36DE8LDmOeQLzJObJzFN3+T86nXkGU3opXsDEQS04xu1S5mVM10vxv8xrmTjw9UbmzczoIKv3MO9l3s98kCmDrHZnPsOEl2J0kNVXmK8xX2e+ydQ8FfsxcRz8EO4J/HzRRZTTqxctTkujzc59rWrwC7KaCEF4++23PXaI5CwRRBCCBFnV4jZwWfEF4ZdffnFMI0iEIJjGVKwsQRj1ww/00Qcf0Geffkqf9e8fwwFRHCj4ucMvHH4ZxUEOv3L4tcPBDr9x+K3DIcyhURzGHM4cYbEffcf8njkS7NePfmCOcjjG4Y/Mn5g/M8c6/NXhb8zfmeOY45kTmBMdTmKmOJzCTGWmMdOZGcxMZhYzu98nlOOyb18q+eorWsQCsHr58go9bKWs8IupmAhB0GIqBjkOXhOEco2pyPAkSgpCEjsTkoJQiiBogUcSIQhPPfWUxw5nQkgkBSGJREKLMg5qgoA5AM1WoyYI2oapxo0bO99G4CcI2PIvgV2Z0s6Pf/zxh5MqghhBwE4vSXhuSWiCgC2fMi1OWtaiLmuCAGWT6e+8807n2wj8BAHn58v0Pp5YKpOCkATw0EMPWfE9ZPvQBAExFWWbA7UTzzVBGD58uCctljwl/AQBzyGez2i++eabnjz9iHgjMn1aWlpEEJzyS4UmCFBWCZxLrz28miCYwk8QTCMm+TEpCEm4uOaaazztQxMEPzRr1syTXhMEU/gJgsZbbrnFSVU6tPMjmOUjCFpMRZwwZHpQiyn8BEE7b1KLuuzHpCAk4QJ7YGT7MBUEPLymB7WYIogg4OgCU6BXreSROEEIcnKTKfwEwTTIqh+TgpCEC1NPRQ1BTm4yRaIEodw8FbUVgSCCoHXvTQH34aQgJJFIaIJw9913O9/Gh58gaKeOB4HP29zDO+64w0lROhC/UckjIgibNm0iE2rBS4MIApydtHxNiFNwdzZBQPDX30aNou+//JJGDx68jWOYPzr8ifmzw7HMXxz+yvyN+bvDcQ7HMycwJw7+miY5nMxM+drmFGYqM42ZzsxgZjrMdpjDzHWYx8xnFjALmUUOi5klzKkOpzGnM2cwZzqcxZzNnONwrsN5UZzPXMBcyFzkcHEUlzhcyvyT+ZfgMuZy/P2jD2m1cspYNDRBwIMm2+LmzV73Kj9BGDBggCe9KTdu3EjNmzf35KkRcwhaHhpLHTI0atSITFi9enVPRkEEoVatWmq+JmzYsKF1GIbMc0fvITx5441WrMXTqu1K7fj6z2T+h3k281zm+bvuQhcxL2Zeyrxsl13oCmYnZudd/o+uYV7HvIHJv3jc4+DjxVSMdxz820x4K/rFVMSR8HBdRpBVK7YicwhzOHMEE7sdf2COZv7IRDxFhFFDGHZEXh7HHM+cyJzMTGGmMtOYGcxMZhYzm5nrMN9hIbOAOaN5M1pXyjmJmiAgNqhsiwjIKuEnCHiJyfRBiPYp89SIYMNaeo0+eUYEgaEZGDGIICSCO7ogZKWk0Bl770Xt99yjXPYy3MO8l3k/5/kQ8xHmY8xue+1FTzC7l3kvw27Ul9mP+SlzAPPz3XajQcyvdqtGg5nfMq2oy8wRzJHMH6pVo9Esdj8idBoTIdR+Zf7GHMccz5zIwjeJxS6FOYWZykxnZjCzmNnMHGYuMx9k8SvclYk/+TeedeQRtMHgN9YEQSPG9RJ+grAdMSkIYFUXBODpW26mk7muFxywA0dMYkZHXcZBLeOY45kTWVQmsXikMKcwU5npzAxmFjObmcPMZeaDLCIFEAa+ZzNPPpnWGx7mayoIQY6D346YFARwexCEhdygr+RxXzuu74XchU0KQimCwPcJnH1xB9q4fLlzF0tHUhAi0AyMiBORNGgTgIkgtk9LBPFDALVDOqsasqdMoQ61a9OZXN+kIPgLQh7fH3BBt26BA7WaCgLmsyQgCJqn43bE4IJwxRVXWOuq0XzrrbesAy2j2blzZ9WNE1udZXpTIvqtdvhL+/btPeU/88wzah4aBw0aZAWj3B6Qm55OV7dsaR3W0oEf0KQgRAQBE4pgcZPGtHz4cOeOBYMmCGhfss388MMPTooI4DOAQMDSFuc9yDzRq5Z2iFMg7XbZZRd67bXXPLY4T1Xa4phEaRfEY5cZXBBQaYkp/ObSbDWmpqY6qcoG0yCrEJ4dFUuXLKGet95K5/KDdC5fa0d+KHdmQcAKA1Yacrh+c//3P9qwxLvX3xSaIDzwwAPOt2XDrfxbyTzvu+8+59sIFixY4LGDIPypRJRC4Fdpe8899zjfRoC4B9IuDoMLgnYuw2+//abaakyEp6JGLabijoYpv/5KXS/qQJfww3w+X3PHXf6PruIH9Bp+2Hd0QZjC14olRyw9ZnN9p1/ViVZmZjp3puzQBOGuAHsZNKDHKvPUnIgKCws9dhAEnM8ooZ0orXkqVspBLUlBqFzkp6XRh9wjuvv44+gqHlK5ZzsiYtLVTPdcRxktqQtT+iA8ypQ+CM8y4YPQk/ki8yVmtA/CW0xES3qP+QHzI2ZfJiImfcr8nAkfhEFM+CAgniJ8EIYy4YPwHRMh2HEmg+uHAB8EHPYKH4TfmfBBmMCcxIQfQmq1apRzRGua060brczJsW9EOSApCBFoBh6+/PLLTlERYBig2WoMIwhAzZo11Xwlw3bztkesWbuWirOzaXT//vRp9+70/CWX0JOnn0ZPn9GOnmX2YD7frh31Yr7I7M18hfkqsw/zDeabzHeY77Y7nd5nfsj8mPkJj1n7MT/l/AYwBzK/YH7F/Pq00+gb5rfMocxhzBHM75k/MEczx5x2Kv3I/Jn5C/NX5u/M8cwJPMaedGpbSnGYykxjpjMzmVnM7FNOodxzzqbpDz1EC955m/5OSaGNCQjZjjky2ZbwQIfBpZde6slT25noN2RATE8JbcjwPx4uSZR5yHDTTTeRJGK88VcxvOyyy6yTZ6P5xhtveNJiG6k2qagJAoJNyDw14tw9bVIRp+vI8rUAEkuXLlXzRfQZ7Uj7HQFbSiHm4LXPTamldz/Dn+XJRIdhg1s9XiSyLaGNSPz999+edgQXZezylcDZkDJP9GBl+hdeeMHTtiEIeAlLW22iElHGpF3A1baIIDh1j8EFF1ygJfIwyLKjJgi4OdIuCE1Pg/r999/V9OD2sOyYRGKBEGZa5GMNfqeAad17Df25F6elr2TGFwS/kFKSQRyTNEHQdlAGoeaYpCHsyU1J7NjwOw5egxZTsVq1ajRr1izHIj60mIpVgElBAJOCkASQFIRSBEFzftAYRBDGjx/vWEQQVhC06NAa4k1+4vDOnR3r1q2jfBZshF3PHDKEli0sn0NXVy1ZQjOHDaOpnO8fLN4bqqgTWNu2bakf19EEfkFWMTFogiARkiuQ8QXh+uuvt3yzo3nQQQd5MgoiCJh4gYpGEyc1y3Lq1q3rSYutz4hMK20HDx7syVPjd99950kLInqM6Q+5o6JwwgTqfeyx9Mguu1hLj12ZverUoXHvvRdqMi+/b18aXK+etfT4JRPLjqPbtKH5IQLlJAp4AeIIQNlutFl+hDGX7QhxCyZNmuRJr/Gdd97xpA9CbXIdn0m7Bg0aeOxAfC5tmfEFAcE54J8dTbgEwzyaQQQBDzW6VtFE0BVZjjYBiOjOS/htI20x+Snz1IhZWJnW5c6MktQp9MiBB1gnNz2+556WY9LTe/Gf/G/4I/z2eh/HMhhyufsNXwSIwVe7V6PBu+9G3+zGf/K/h3IZC/k3rkrAuQxa+9QiJsFNWbYhN5iJTK8RUcVl+iDEy1o+H/CIlHaabwNYVFTksWXGFwQNYUOoaYQgSEBppR0EYcWKFY5FBFh2lLYaMUZMIhYbuBG/fEY7yzlJ81R8btddqCe/eRYWFzspzLCM34KfH3yQFRxF81REgJSfjz+ONvIwparA76CWIKHJEHxEy0MSfgRhoB1Kq9UTqx7SDkQYeQkWueCCEDbIqkZNEDDXIO0gCFr3DdFrpK1GdAmTiMXUlBS6n9/aj/JD6+e6jJ7C2N69nRRmyHzzTSti0uf88GuCMKzartZR8IsneOeUKgtBTm7SgLcsut5aHpJBREZDWE/FUk9ucj4rFZogYJeVBBw0TAUBwxCJCTymlXYIEaUJQrKHUHZM+OJzy33ZipjkIwg47HXw1Vc7Kczwy7XXOIKg72UYxsMHuC5P/fhjJ0XlI6wgYBiBOS4tD0ntIKIg8BsySPgJguYvUW6CoJ3DiAjJpoKAPCW0IcPe3FA1QTBdHvVzoNqZMf7zgdbpz6UKQuernBRmGMv2JoJQYrjMVxHwE4QgDy/iJGh5SIbdH6EdKHPzzTc730ZQzEM9aQfOnDnTsYggRhBw9JoJsbkpKysrhognIO1wzr52lJvG2rVre9LjwAxZDpZ6tGi3GA9JW43Tpk1zUkSADVOYlNxZ/RAKf/+N7sXKwp7xhwxjlF5cPKS9+KK1wclXEKpVs4YMC8aOdVJUPvBig9esbDevv/66p31qxHmk8ImR6S+88EJPm4cXr5aH5PHHH6+ew4hlclmO1oZxgpq0Ay+66CKtvIggMDyV1qjtdtTe5mF58sknO7knFsuXL6cDDzzQUtKdEWvXrKHnjzna2u3YbZ99PILQY7dq9ByLxezMLCeFGZYUFNBnnM9AFhtNELDbcUzLw2k9C3JVAfwQcGCqRBAnokWLvL4beHNrtqbUxvth4dOTKR9BCLL92ZTaMCQRwCaVevXqJeSmby/IGj2K7t99d3qY7/u2qMt770nPVNvV2gr9w5NPOpbBkPr881YvwQq/zkMELDt+C/K/sQV6zogRjmXVgJ+nIjYnaW1UEsuJ8DGQ0LY/m9Jv+3NYlHpyE0Mz8DApCDsmUocMoacbN7Z8EeCYhLMZnuY3/A/dn6LNW8rmp4F4hmk9e9IX++5rncsAxyScyzCibl2a/kXZjzdLFJKCUAZBeOyxx5wsI0iEIBx11FFO7okHvLYwG7uz46+FC2nSwIH0w0sv0W/vv09zyinwyNK8PCrghyqz94s09bPP6B9lTFwV4CcIOGZda6MacbqYxFVXXaXamhLb9ssbrVu31sqKCAImTkyobTXWBGEv7nb26tXLk15TpvPOO89j98033zi5lw4oOM72j6YWBBPqLe3ghYY5BG3WNYmdC36CgI1Msn36ES9M2ca05yAItTw1fv31106NI4CYaLbaFgRmRBCc9GWCJgg48k1Dhw4dPLYI4hAGWE6Ued5///3OtxH49WTQ1Zs3b55jlcTOCj9BCAJtqT3Iy02DaZQwRDqX8HNd9mHiBAFvXa37pDkRaZ6KQaB5KmoxFeNtf9bqmsTOhTPPPJPe56FSWeHnqYhw6GUFnJ3CHAdf5piKTvoyYXsXBEzc3HvvvdbyUjymKScHY7OVtMPSFbYSS2CNWtpqYenRzZN2YTk8wDkFY8eO9aQ3jUqFDXHwS5Hpq1pEKtQTx7RH17FZs2ZWJKOyIikIDtBYkIUkjp2WaNeunccurCBoHmZBBMGUEA2JX3/9VbXVYjRqHpVaLP1x48Z57MJSO5zUD5poawE8/SDTgtr6fmUDQ0VZzyDCqUHr3ocRGcBnRcBDrS3Nnz9ftfVhcEHAEsioUaNiCHWF51M0L7/8cho6dKjHFi6b0hZ7GaRdEMLLCpcQzUQIQrdu3ZycIoBDk7yejh07WkFeZT1POukkT57aqg2WQGWeQdiqVStPOSeeeKKTe+nQIg/jmuT1aPz++++tUOayTrj3JoDnqJavRs0JSIOW58iRIy1vWFlPrChIW1P65Ymt/CbA/h+ZJybHtdggGjE5L9OjdyLrA+67775aHsEFAQ8azKOJyRgJdMm0qMuJiJiksaIEwQ/YiKXlIakJQlhgHCzLCSsIQRhmPiYzM1PNU+OXX37ppIoPuOpq6bXlvLDXjiFkWaGFZQtL7QxKQHtpMIMLgun2Z6iydvBlImIqaqxMQcDGrlq1aql5SCZCELBUJcupKEHABG2YFRu/aMYaTWfvtXBnGC5oYfO0g1pMieAqYeZKAq4IGLFly5ZO7rEo1THJsSsVYeMh7AyCgINjsWFLy0NyRxOEPfbYQ92MY4qKEgRsvNMe3jCC4OepaIrtUhDgZAHzaGKyTAKz7FrcN0zCSWwvgvCkoU8/JlNNjwWHk0h5AwfnyHKw+9QUnTp18qQ3ZVhBKCgoUPPVaDoB6Ccy2sMbVhAwiVdWYDeulm8YYtVDQ5MmTTT7iCBg3GfCrl27ejJCJCJph+4YlnHQS4gmAp1KWwiCtEN0JFkOlgfxoElbdFOlbSIEAc5Osu4a0WWGMst6atT2hgQBJqJk+Tg+XJZzzjnnOCkiwJIW9nLI9H5xAUwYRBCwNVeWjd9I1h1Ed1yWhQjJMr12rD/evDI/DOm07cKaIMDrVqaH4520gyBgDkTWyZQ4RV2WE5Z+MUCwm1ja8rMVEQT4DZgQN4fNY4jul7TD/gCIAoYO0URjk7ZYdpR2mCGV5aDHAVWXttpyXiIEAZOksu4acQQeVmNkPTXioQgDBMqQ5T/yyCOecrRlUJSNySWZXhNYUwYRhI8++shTNiaoZd0RFEeLHrzPPvt40j/66KNO7hHAP0DmCWLiW0ITBJzDKNNOnjzZYweijco6mRLDOllOWGpHywH4XNryyyEiCAz1AstKRDfCxKJE+/btPbaaH4Lm24Beg5anFoAiEYJgyor0fMQSkiz/wQcfdL6NDwhCjRo1POnDMIggaEObI4880vk2FqahycJGItIEQVvfD+jwY0SM6ysTMRGTGGoly0oonvZQmHoqhg2yWpmCgDVenLpbEdBOFjadl4AgYOu3TB+GQQTh7bff9qQ/5phjnG8jwJyMaTTjIA5UGjRB0EQmEUuEOFuyMpFwQUA0IglTQdCCrIYVhEREdtKIrmyY9egg0ATBtIewYcOG7UIQEDavogQBG4RknlpMxaQgBCQmXdDgJLTuPU7LkcjIyPDYBREEbbLOz0ElEfQbu5U3tPupdXH9UL9+fU/6MAwrCPA61eAzK+6hdqhKEGgCi+PbJXZKQcC59PAbKI2vvvqqJy0mGhGeHT2CaGI2U9piaUTaIWCltAsiCGhAMk9M2ki7sESgCXk/MCF62WWXecrXCLdvCYxPNVuN8EqU5WvBZOEOLdNiMlbzJoUrucxT47vvvutJG1YQMCmn1VObzO7evbunTmizMr1GBNbVhnV40GWeWrzNyhYE7Tr79PGesIUVL2kXh/EFQduJpyE9Pd2TNhEMIggVRb9Qbz6+4h5qG6b8ZrA1jhkzxkkVH1jS0tJrND1NGyIj04YVhCCE8EognoFmqzFMUJzKFoQrr7zSkx4rThJljofA8BiYnqrsF3ikvFkVBUHbxxHWUzHeKdWS8OswQRDRxqY0E2jDuooUBM1TUeu1aPTzVDRFZQtC2JObfJgUhLBMCkJs2qQglJ1VXhBMg2L89NNPnrSJorZDTQuhVlFElB0NpltW4UQkEcSFFdusTZAIQUCXW6aFIGjeghowDpbpg1ATwyBDBnhplhXZ2dlqnmEIhzZT4GxImb5cBQEbdySxb+Gll16KIdbyJdAwZFosfcE5ibOOIZZ1pK0pMdmlNTa4sEpbjO1l2YkglsPkPcKqibaPA+M+WU+shsj0WDqTaeHshNUDmR7HepsgrCCgNyDred9993nSwn338ccf99hqYe4xVyKvJwjh8i7L6dGjh2qr8cUXX/SkxwNkAkxIyvzQ29NcmjVib4lMj01pGjDxLOupxQBJeMQknGSDr6KpuYb6QfOC08KQJQJvvfWWp+zKJnwrJLDvQLOVxCSltoxrirCCgEC4mq0pw4QR84O2RNilSxfn29KhRR4eMGCA823ZYBruDGJqAuw30VbmNCZcELQ9AqabceAbrV0IlnEqAlB/WXZlExF1JF555RXVVhLOTgsXLnRSBUdYQQhyNoFG06FNEGjnHZg6JsHZSfNt0EKZmyIRx8FDEKpMTMWkIJQvk4JQvkgKQiwTLgimHoAasJMMJ9zK9BUlCFogl8qmtn9fiy+hEUMGbWOXKTDXoOWrcfDgwU6qCEyFy4/awTlhoW3T1h4KP2B7vkwfRhCA5s2be/LUiFUCU5gGWdWOg8cWb83WhxFBwBtEUvPs0wQBDVWmxVIk9jPI9Jog4M0n02uE67F2HLwGRPlF/aPpE0fOmJgFNskTe/fhky9ttQnZgQMHeuy0Y7bgqQdHHO2+mPCzzz7z5OlXT/x2EghZLu00wsMUKw2yLMxBaPUyISY0N27c6NQkAkxeyvIhXBIIaSfzhKOWthKkCcKff/7pSa8ReWp7Q9BrkPV84YUXnNwjQFAhmSfm3LSt31qeDzzwgCc9gt5KO1Dz/GRGBIGhGXioCQL8FTRbjZogYPVAs5WEmy1+nLIiyPq+Ri1ikrYWj7d5VVvS0ohGEeZ++sF0I1IQavEPTREkLJsmCO+9955qa0qtx6UhSLQoCLQEwr1LO/SCNCCAj7Rllo8gBHFM0gQBS0WarSQiGWuOSaYIu9sRbyQJLW4DBCHMAZ1QdplnIghBMA1lbgr04BDpVyuvrMRSphbdyBRaTEU/aoIQxLdBo2l06CBuxp9//rmTKoJPPvnEY+cXY6HUmIoMzcDDRAiCaUxFP09FU4SNh4C1Yglt3wEEIUw8hLA9GVNCEBYsWOCUWj5A1768BQE+GJUpCKbHwfvRdMk1iCBgqCmhCUKZg6wyNAMPtdgFfqcXadQEwXQCEDPtYQRBi7EQhBUlCEE2IoUhBKG84zZgMrm8hwwQhDDCFXbIoJ1zEYSmPYQgKwKYE5KAA5O08zuxy2fyM74gwN8bP0Y08TaXwMk00g7U8tQEARMsWnpJLGOGHTJo+WrUgnpWlCBgIkmrE4LMyrI0ou4yLX5LaQdBwNgcEYnKi/Ak1SbBwhD1nzFjhlqeJJb+JPLy8jz3A9TupyYIeNBkWu1+gtIOxNtcq6skejJaeo1arwNzCNIOIem0srBvQtoy4wsClA1dtWiuWLHCKT4ChOKSdtj8oXmCaYIAnwWZXiM2zWiBMU0BTz8tX404a0LWvaIEQasn3h6mh79g6U2mh9+/tMMDgQApeKOXJ/0elrIySD21HiyGMfJ+wN1eEy5NEBDsRqbHFnGZFnMd6IVK29tvv12tqyTih8i0ftRc+BFIV9ohFKFWllbP2bNnxxcEbZnMFPgRKtMPISwuueQST90rShA0wEHFNNyZtoMSb0nNdkejFu7MD5oTkSYIGhBVW6aFIGjOYzjvUdpqDHIgrykQpVwrS1u1KTVikun2Zw2V7akYFlo048oUBKylm+6g1IKsVtTKRWWzojwVte3PEATt8JfrrrvOY6sxyPZnU/jNS2ibzZKCEAdJQdg+mRSEWJSrIKCxlxWYa9Am5rQdf1UR7dq189Qdp1ZJ+M1gh9l3oCGIIMBjTSKI6/L2zCC7HTXXZVMXa8xnybQQBC3SOA56kbYajzrqKCdF+cFPELQXVowgDBo0iCSxRRNx2qI5ZMgQJ3l8YCYTtjJPHIcm89SorWbAtRNjRGmL8bHEiBEjPHZY3jTFuHHjPHVHnWSeeCNJO0Ty0U5kQjBamV6jNjHmJwgIsCLLx/4ImSeiEUs7P8K1VZaDoKSarSRm1LW5I1NiwkvL15TY1CavXSPG9dqR/aeddppqL6lFu8bkJ+aepK3pITNw9Zdpg9AvYK9WFvaByPR8TyKC4KSPAcKD4atoam/JIMA5kDJPjVp8fgxDoMLSVttFiIdK2oVVYC3Cj1ZPPyC6kkyvUXMm8RMEbd+BtjMR+yNMoU2CacMlP5g+ABqxFyIMwnoVbs/EITMSfoLgw/iCEGb7sx8Q7lnmqVGLZoxNVNrbR4sSrG1/hhiFASLVyDy1mIp+MD1EFQdxSvgJghZGLBHHwWvDEA1hPRWDCKwG05iKOyKrdDwEPyQFITa9xqQglB1JQYhFwgUB3eYwQGOXeWpEzDkJDBm0iUrTIUObNm2cb8sGLUqw37kMGrQHTaPfgadw3Za2CHAroQ0Zgqxxd+jQwZMezjUmgCBo8SRNCZfaMNiZhwyaIJT5XAYnfQw0QejYsaPlIlka4VqpxQBEDEHMupZG7J+XwKQiJjqlLbaNSmC2WNqh12AKLI/Ka+rUqZPnfqABSzs/QuRkejz8sp6YeJVpsXEFh45KW0xUSlsEeZV22iQt3HyxzCbTw7FJpseEnQmwnIe4mzK9KXFwjaxPEGJCVeaJNivvO14s+D2lbUURk5eyTmGpCQJ2s2rla7z55puDC0IQhtl3UNkwnfwMS8SCkPDbF6+5q2pRrUy79xBYrdeRiOhGpsCeBVmfINSWHeGWK+3gXq254VcUILCyTmGpCUIQxCw7Op/FIIwg+B0Hv71Ac0xKBE0PavGLqZiI4+BNz2VIBILsTNSoOSZp258hCGEOagkLbWdiWCYFIYFICkLlICkIZWfCBeG8885TCzYhtlNuz0OGMNcehEEEQQvLpgkXDskxhXYcfGUOGcIe2a9FM/YLSVfe0aKCQItxGZaYBwiDGEHA2E1Sc0zSiBOaMLkWzWOPPdZ4jAZ3T618SfiJa/vdTYE3opavRnhuyWvS9maEpakg4B7DlVzW8/rrr/fUE3lKO42Ygda2VCOGoGZvQmwrNg2EqwFHr8vrCULNGxVLb9IOEYOwm1e7Bkkt7iRWUzRbU5pG2/Yjfjd5TegdaWVphCexRIwgYNZV0jQgB/ZxI06BpCkwK66VL4ljssIGSNHy1Yi3pLyesKcXaTQVBFCrJ1y0ZT3hh6DZajQtx5QIumJ62Ksf5PUEITdqJ5dYSDs80NjLoF2DpDZRic1Nmq0pTZ8tP+KEKXlNffv2VcvSWKbNTaZs3769k2XZYBpCDbsIKyqE2pgxY5xUEYQ9m0BjEEHQiDDbEppjUkURjS2sIFQUTB2otGFIZceX0CIm4YxTzVYjek0S5SYIiC4UBlUxyCrOQJDQPBXDMqwgmHoqVhSDHAdfmfDb/qwR/h8SiTgOPghNg6z6MaE9BL8j0U0RJAy7tr3UFEHCsGsTaxUlCEGCrFZFQZg/f75Tk6oLdLGxs1K7BkktClNVFAQMGTRbjQkVBMQOCIMgUZfDOJNoZyj4MSkIZSMEobxjQSQKpsFgNbftyh4yaIIQZCmz1CED1n/LSsxahgGCNWj5SuKBhvhgA0w0tUAuGE9Ju86dO6v5atTOUdQEAe7IMi3qaboioQkCNjLJPCES2vH6poKAaDwyzyBEPWWeGjFZhrLkvR87dqxTu+BA9x7xB2SeGjWX92nTpnnsjj/+eMs9XbtWyXnz5jk5RQAvT2mXmZmpLuMiqri0NSWWTLW5Dk0Q4Pej5aFR21YQIwjOZ1UaWHLE8huqG03tba71OoLs+NOgCYJf7wjnQEpbjZog+EFzIjIVhFNOOcX5tmwIu2lIO3rMFFgiMw26or3N/fwQyjvMHYDlP1mOaVAhP2iHqmiCEBbbnSBsL9ufseegdu3aHluNpoJQkdufNVTmcfAQBNPxfmV6KvodB296cpMGfkjV4+CTgsBICkJSEEpjUhDKju1OEBAPQXPo0NbiEyEI2inVWtwGACdVS1uNiIloAj9BwKlZEtrkUmULgha3wRQQBNMYCzfddJOTKgKM7TXbMCtWGipSEIYPH+5YlB9iBAEbYqoS33nnHaeaEcC7DGNZvAGjie2tEqaCgMkVBFOR5cOFVgKhzGXZ6DXItA8//LAV90HaasSSq0z/xhtvOCVG4CcI2Nwk02uxGzVBwGQd5lpkei1obVhBQLQoWY7pJiosEWKNXbt/klqMSbgea7aI2yDrpBFBc00QRBAwSSzL0YIP+QkCgt7K9KYh5AE8HzL9gw8+GBEEhqfQymTYgKimgoBhiBa41VSBte4oqM3iaoBwyLSYRJLwEwRTaoKAmXK4GktbLRhKWEHQGHYzTlgcfPDBar0kca6CCYIIghZ9C7+vhJ8gaMQqmim0FStm1RWEIKHJNJgKAs7tq1mzpsdW81TUEPagFs0dOkhMRVNqghBk+3MiBAHRryoLYT0VNQQRBG1Ypx3UEkQQgmx/1lYumElBSApCUhBKY1IQqgDDCoK2M1GbAKxsQcBciUyvCQJWLpCvtDWl35BBO6xEG4vuiIJgOmRAjEtTaH4ImiBovzs8JyWCCAK27JtCexEw4wsCGiYCcCSaLVq08JQdRBDS0tKsBzia2DAly9GW+CpSEDIyMjz1vPXWWz3pNUHAnMQNN9zguSbTI+I1QcAkrZan5vlZmYKAhwKThfLemVI7PhBvc9x7ee2aQxm8JLV8JRH9W1tu1gQBu2ll2ThdS8JPEPByk+nxG0ngiHitrpgXkek7dOgQXxAwE1oR0E5ECiIIGArI9I8//rjzbXxUpCBgm7i01agJgh9MQ7trghAElSkIWHY0fZtrRNwDUyDgjJZHGGqCYAo/QTD16/A701Nzx+ay4gvCr7/+6pgmFtr25yCCoIU7e+KJJ5xv46MiBSHMQS1+0GIqatzeBSHM4S9BVqxwHJqWRxgmQhBMHZP8Dmqp8OPggyCsIGihyJOCEMvtXRBMPRU1+jmPaUgKQgSeRNuLIGgn8YYVBOyEM4EWdAVusVoAT024NCIepSkuu+wyNQ/Jk046yUlRNiTiiDRtzOyHMCss2uy9HzAxp+URhoMHD3ZyLxu0OTZTQUCMS5kWRHxSiTIJApa/sM2yrITaS5gKAtQS7qYyT21sHlYQsDtPloNrl8CEJrY6RxOzxUuXLnUsIkBjk7YaMQSSwLUj6rKsEzzWZN01QmRk2iDEFl6ZJ4RPqz/CqElbuB5LO22eB7P/suwlS5ZYx/DJ9KbEKUkyTz+aCmwQfvjhh2pZJkSEMG0pUxMETDzL9PCu1e4JJrilLTO4IMBVF2culJWaa6mpIODhxc2ReaJhyvRhBQHdflmOdtAtGjD2WEjiAZbA0qFmK4mZYQksEeKYeFknhLuXddcIb0yZNgi1becQGVl3uAlrMQEQFFTa4pokEIlIlo0NbYgQLdObEvEpZJ5+NL2fQYjAPlpZptQEVhMEfCbTIu6Ddk+OO+44j2316tWDC4J2iGoQajsTTQUBbsaIqyhtNYYVBI3wfa8soHdiGhOgoug3L6GN901dwf1iF4SJwhTwwNPtgpogaM5O8IvQgJUXacsMLgim4c78qI3NgwiC6UORCEHo1q2bk6riEdZTMRE84YQTnNpFAN8GbUXAdJkM0XxkWry1tQ1spvDbb7I9UxMELcgqepUayuSpmBSEWFamIKB7XdUEAd1RCcwRabEKwwgChoRJQYilqSBoG+WAnU4QwjomacRwqTLh425aacRR9hq038h0yOB3lFuYYCY7iyBoYe40d2hghxYEbGRCvtFEnueee24MsedbIoggNG7c2JNnEOK8BRNg7VimxUqKFnQF8RTkteOkIWmnERGSsdVZptc8Py+//HKPHRqlrCdWPRBDUNoikpG0xVKmBH4PmRbtEBuxygpNEDDJivrLsnAKmbTt0KGDx+6jjz7y2GHyD5On0taUQcKoa4KwYMECT56aGzqwQwsCzluQ0DY3IdquRBBBCMthw4Y5pcaH5uzkR+03Mg2IipUDXL+E5pzTtWtX59sI/NxitUhEHTt29NhpAVETAU0QMAzBUpuE5rqsbW6aM2eOxw4iE+YgIRxwI/P0oyYIQbBDC0KYmIoVKQjY/GKCijq5CcFR8FaR0PZHPPDAA863EWAtW9r5ndzUqVMnj21F7Xb0EwRtGKKJoenJTRAEzeHHFEFWQ5KCwEgKgpdJQSgdSUHwIikITL8zKE0jJIeldj81BBGEcePGOakiCLLvQNv1ds4553js7r33XufbCDS3WAgCHLAkLrnkEo/tPffc43ybWGhdcT9B0NzgtcAjWPWQduD06dMdi+CAu7uWp8Yg8RM1tG7dWst35xIETAri82jierQgIRpx2AmWM8tKXKcsX/PcDCIIiGcg88Q1aeVLYtUE91QCm3GkLbw0ZTmYKJT1wVsSy7PSFmXJPBHFWtoFoXYcGSIsSzvMAch6+gkCJllN6tmrVy+P3ZNPPmkcyRnLqzLPBx980FNPED0UWRYmk2V6bUMe5kmkHVimmIo7miCEJX6EMDj77LM9eWpvySCCoFHr3oeFFuEnCLVQ+e+9955qa8rPP//cySmCV199VbWV9BMEDdr6Prwxw0ALsqoRxw5ok5/a0EYLshrQSzMpCEEY1jFJ2/6sRXEKKwja8mpYhN3+rDkmmT4UftTCo5vuygwiCNicJNNjs1UYmB7MCkHQhiHoGUpbbWjjt/3Zh0lBCMKkIOjlmTApCLHYYQQB4xfN1pSjR492corAVBCwS0tzztEOe02EIGCMFwba1tpECEKQOAOm0B6KIBwxYoSTUwRhYyxogmC6wgJiUtQEmsOQ36YhUwQRBC22hha3QTs/ws9XxIfBBQE3BxF9ykrED5AwFQTMXiPIiMxTi/1oKgiYBMNWUJmnRs2zDluV8QCbUPMANBUEeMFhu7FWL0m8zSVw72R9sFcem5Ek8EaStuh1yDppRAOGA5isEwRF5okQ9NJOI4K7aC8CTRDQE9HykMSZnNoOyhkzZnjq2adPH096eG5KOz9qzkpBBAHXJPPEqo+sE2JWSGA1RNqB2gE9zOCCkAiYCkIQmAoCAneg51FWaBGTgtBUELCnXptcMoWWJzh//nzHIgJtidCUWHZEQBMJPEDSVlvK9ANWiGR60yPWgkDzwbjjjjucbyMI0hWHO7OEqSD4MUxYNgC7IJV8k4IAQQjjbhrEzVhjEEEwPetBA3oDMk88vJpjkvbwmhJ5aiJz5ZVXemxNHZMQMl2LsZAIQcBMvSxHc0wqKCjw2PlRWw0JKwhVxjEpEahsQdDCnZmiIgUhTJAQTRCCeCqaMhGein5BVhMhCGE8Ff2ovc23S0HQjhpPBODkIcsOKwgI9Sbz1AhBCHMsOOYvtHxNqQmClicetDCCgLkbmSdm2rXufZi4gn711ETGdMgAQdC2fpvGWAgCrYegbcLCCdnSzo9ffvmlkyqCIDsbNWp5BkGZhgw4XQaTTokmvOBk2UEEAQ1G5tmzZ09PnhohCOjiyvSmxKlAeAhMqMXG0wQBD69MW716dXW2GTEdZZ3wmQT2Hcg8EY4Ou/ZkerzNpa1GLf4gPsfEnMwTD5pMDw9CaacF4cVnCEUu08N9V6bXqOUJaLaYvZflwCNTAkMGaedHvM1lOdg+Le2CxHPs37+/J88g1CI5M+MLAjb9IBxWookAj7LsIIKANVmZJx4gmadGPKR4+8j0psQRWOgim1DzVNQEAT+YTIs9BxhLS2DtWdYJQzAJLU88uIh6JNOjAUtbjdisJa8Hs+KI7CTzxMSaTI8lQmmHeAoSCFiLXodMf9NNN3nSa8TKlAREE9GYpS0eNFmO1oOEyEg7P6KHIcuByEi7sWPHeu6nHxE5WeYZhD7iE18QKpNBBEELalFRDHIAihYTQBOEINDCsAeZvdccvTSfAQ1BxtFaLAjNHbpVq1bOt6XDdK5DiysIQdDOcUzEMOTqq6/2lKM5EfmdoVCB3DEEwfQAlEQQ69mmMPVUDALt5CZTT8Ugx8Fr0LY/+9HUU1ELYuOHq666ypNeo3ZyEwRBOw4+7C5CDXAYkuVoS5lVIDp0UhDCMikIsWn9mBSE2HKSghCQiCFoCtMzExPBIMKlre+HDdyqLefBvdwUWoTkn376yfk2PqZNm+ZJ60dMUEtouwi1SM5+0B40jfBE1aCdTaC5wYfFLbfc4ilHG9ZhclvaVTDvZG7DNVWJZ5555jX//vuvEbmHoOZREWzbtq1aJ42XXHKJJz33EFRbU2p5Pvzww6qt5Lp1667hcbQnPY/3VXtJ7iF40vqRewie9NxD8NhxD8Fj50fuIXjSa2zTpo0n7ZYtW65p2rSpx3bw4MEe27Bk4fKUc/vtt3vsuIfgsatgNmEmkUQSSfiAey57MQ9NMskkd146cvB//8ddl2uZK3cGbt26deW/W7es3Iq/4zPr38737p9JJrkT0pEDSxBuYYVIIokkdmI4cmAJwk3OZzsFFgwdTpmXXkE5d95Na+fOcT5NIomdG44c7FyCsGJqCY1v3pIKD6lBGfseSHl3/o94qED/8ncuk0hiZ4QjBxCELZYgWI/Fv/hv6Y/FNiu2t//t/pdp/z8wnNQWIn/n/zofup9FE7Dr4tSnFCycOIkm1KxDJU2bUmGN2pR28WW0ZfNm2srf2en9c4kuwf47GElpwf0r/2lb8P+23aOoLxMAK/9tWeMv9r/tGkZ/F4FdJ5fuv92/KQl2GNjXbF2j/X++T/b12tdt/z0xiM0bzWNbiYksthQ4chDdQ8At2dZ84pP/A6utsOd/WDeT/4xNGQx2nsgRdeAcrX/bpUTnh79Ff4K/W/+ImPhi89o1lHXzLZRyaG0a36AJzRv0lfW5nVTPwLom56ttFqic9U0kjf2J/R+rTta3+J99PYD7eSIQKd8tl//HHzhVVRD1hZvmX7sNuCK2w8PnOhN19VF33AP780SVXDocOSifIYPdnMoZVuM0h7ntv7R4cioPH6Y5/2bwsMF9XCVQi3h54zvre8fI/jfy0lPZ35U/4v0GW7WGDxHY6l8XWxx2XLhX/ld+ARV93JdmfPYZTfukH838YRTfr0T9RjZXzplNJX0/pVn9B9D0fv1p2rdDaNP6DZZNZcGRg4gg4CasXriQ/pk1g1bPmUOruNKrrD/dvwvOnkurZs7kNIu2PTRrlvxJK2bMpJWz8D3T/VOjsEGafzi/lXPmcjd+o1WfrXyT1iycR//k59Ff4yfQgtGjac7wETR7yDCaM2Q4zR85ipZNnmjVY/Mmb0wAiQ2rV/P1zaV1S5fS6sULadUff3BZm/xeFBas61r8Jy1LTaP53/9glT1v9EhanjKZ1sxfsK1hWVnwf+w7Yb1nafWCBVbdUcfZ331PKxctjltWGKBcbJZes+xP+mf6NL6vM+ifGdNpzaKltt4J2LUkWr9iOa2YPpP+mT2HVjL/mTqd/p47h9N4t17vSHB/t5nvvEPj9tyX0mvUotR9DqRxF15CmxMoCMCiH0bSb/sfTJmH1qK0Aw6hcUefwL/DCufbyoEjB9E9hC2Udt0NlNK0GaUdeSTzKEo/sg2lH9HG+nvaEQ7576nMjNZHU0qTwyjjxpvt5IycJ7vTuAZNKa0lp2nNebRiun+24rStOD/+O2h/dwSlWt+zfasjKK1ZSxrf9gxuxAusmzez/2c0+bBWlHFYS0pvxPnWb0CpdepTWi1m7XqUXqchpTduSumtj6GsDh1p1nvv0caV3qPKXCzgB/r3Rs2tslObNKffzruI1q9Z7fxQziPi/mqMv1KnUO6991HqCW3Z/jBKr4ty61Bq/XqU0Zjv0zHHU1bn62juwEGWsADue3rT6pU04fyLKKNhE8qo14B+5etcyQKUKLjVzn7pJRpXtyFltGpNk+o1prTHnnS+gQ03dMvQbvAb//mbUi+5jCY1bUEpXL/UFi3p5yYtaOaw4db32x/su+CKsgnmffgxZR9ah4qbHU6F3KYyOnW2hDWR+OvHHymzbgMu8zAqbtCYMk47g9bzy6oy4chBZFIRKLz8SsqvUZsKmzSlosZc2UZgs20swZ8N8WdTKm7chPJr1qSiTv91UhNNffQxyj/oUP6uORM2ERbxA1TIeZbwA1mMvzfhfJzvpnK+RU2aUHG9hpTND9kaJyTXtD59KIsVtJgf3sKmLdnmMCqsU4+KatelgjrMevW5Pk2tehXUaUAZh9SktP+cS8vT0630EouHfUfpNfnH5zoU1a5PqWe2Z0FYYzcfdKGdNwO60tN696bJnHf2obWpqGFjKuGyUd+p1rVz+qaHURGXm3PAwZRy7gW0eeP6mGa4cvp0SmvRmkr4B8/je1p0l312glkzDQ5XiAp69qIs6zdoRnkH1aDchx6xPre+xYqK9RfbtuiRbpTJ96yEbXFtaQcfStN79rS+277g3lX3LtjYuOofWjIllVYrYePcrtofH31MmTUgCC24DdWn9E5XJVAQ7DL/+nEMpXNbL+IyC7l9pJ9+htV7rUw4chA7h1DA6pjHN6WweWsq5rdyDj8QGbXqURYz02J9688MfiAz+MFM2+9Ayrr0Sic1Ue79D1LKXvtbaTJr1aEMfvjwZyYrbxHUsPnh/Gcr/rMF5fINyaxZn7Jq1qUcZgbsuSFPbNma1jgnFE9/6y3KYvUu5HSF/BbL455JzqUdKavT1ZTZuTPlXnAxvwmPpkyuSzEe0OYtWaRq05RjT6TVs73HdC8e/j2lsTIX4W1QvzFNaX8urV/r9hAizWla71co5eBaLATNqaRZa8qvz295FpCMpodTZssjKKPJ4dxTaUC53JCyDjyYpvd53Upn/+B2HgtHjaYMLquE653B922Rc9ZhbJMtP2wThBde5AbOAoR7zPXLfSSy3Rpy59rN++prSuFrmso9gqLmraw02bfdaa26WBaJGtskBKirTSwjz/nmG8q7427KbncG/cy/3fzfJ1hWGipPENAOq7Qg/OsIAlcUD1bdRjT17vtp0ZChtGTQ1zFcPGiQxYUDBtKSn3/ZNh5bMm48zX33Q1rQt5/F+R9/Qgv6f0rz33mP8o49gd/M3FPghzGb/5zx2OM0/7OBNL9vX8f+E5rP3be5A7+gjavt48Wnv/WmJQhFLAg5LDL5t91BW7dsJXTO8aNt2bCRVk4roeKnnqaMBs1oGvckYJvJb7rCJ5+y8oiGRxC4N7Gth+D8WMvS0yilUROrRwPhymH7jHMuoj/4Wpdn59Dqkqn0V0YmzR86jKY90pXGn3AqLZ0y2Uob/bDPeOllFjvubXE56e3OpI08RrS/jdiUJ0wEwZ3QXFlYSFNYSAsbNKKiw46ggto89Gp/Aa3/0w5Pb+W1HQkCaurOY21au4Emt2tP2QccRCXchlOZiybZv4+GZA/BhiMHuiDg5mRwV3n2QG98eQ32T+HKggLugmee+R/KRwPkvFP4R1o4fpLzpRduU3R7CHjI87gXkX9PJPglbFw7oIh7J7ncE8FYsKBeI36Iz6fN69c739pQewiOILgoeeopyjqkFvcMWBTrN6SsCy6hdX/6h21f9+eftJmFyb4Hdk54lvKuuZEfNO4p8X2c5pyw4z60wWCWxs3bEgQuE79hbo26lPewLQj2ci7RZr7ejEs6Uh4LbBH3AovqN6KUI46hFfn51vc6OO9SBQI1gI1bE/vfrgi5qV0L/M/O0/2Gwf+O+peNOB9Yqfk/KMGexmVBWL+OMi+8hIrq1ePeWXNKrd+MFk5KgTl/782/NEGwynAYH9FWurV7L/4a8xMLgv0sxBeESD5W7s4/7euILcP6V9RHsd/a0D5z4ciBXw+hhdWo5nzcz/6qDIgufPOKfyiD35IFDZpYNz6Fb8b8H+2gHPbPqFd1RlQPIZcbcF6X2KPUo2/Msh/Hche9odVFL2rYjKacdDqtXRYbLNNPEFwp2wLhuuIqaz4CNhjGLOIeDmDX0uzdsW7BQko/9ngq5m7hlJZtaNU0d4nTbrra1eo526XqdycWrk3hC735nnHP5DBbEPIdQXBzKe7endL582LuBWI+J4UFYdF33qPbI/AvXf/GLgn/9au59f2/W5iuJf7LLcFt8QL43O+7Lda8SOTuwSqzQ0cqdLrkk7nnuCQr2/5SQVxB4DK3xKmTB6jnttbkj79G/2gJQiE/Z1IQ7Bz0MrfiWvlPv3slP3P/hWVn0EqtpAMcOdDnEPAAWj0E7vKXFdHF6oJgn+DsXqKGeILgpnAf0r9G/Wg97MU8zi/CLDv3EDaJtV2/OQT3J9y0eROlXHAhNyZ053hcXbOeNZwBYGM/zqVj4cjvKL1OPco9tBYVPvSo9Rl+B3fS0sVfU9Jpeu9XqODOuyn32huo4JY7qKRHD1r8yy9RtlZC5+/+cC1cQcA9y65Zh3IetcsHFowYRql1WAyaHM6/w2GUxkOL6X3scyF1QYrUd828+TSfh49Te/Skwrt4fM71zbnueiq+9z6awUPCFcUljiWqaz8WqNO0b4ZS/ou9qaRPHyp++TUq4aHhlo3272LVGZe37X9E838aS3lsX9znDSp+5VXK//gj2rTOnrBdkppOuS++ZH1X+CLn9eVgp5x/aRkP5fBdyYsvU/aJbamgCQ/5mrakHL7W/PseopLXX6eSl16lvBdeor/Z1kU8QUC+eDgXTBhPuZwO5RZwGVOHDOFPJdwrIFq/ajX98dW3NPXhR/ke3Ui5N91KU7s/Q0t/tQ9CWv7bOMqo09Aq008Q5o750aprMf8++b1eplmjf476NSAOW6jk8y+okNtPYe9XadpnA2jLFnvp/e+iQhb+pyn98ispp1dvK0+7ZpG/SThy4CcIFddDsCuoVzJGEPjhzL/bGy8fQOqCLvxQ8UM4lR/2zIO5y/9cD/vLKJQ2ZEBd0MgL0Z1mGwxxstqfR2udVQ9T5Nx9D6Xuujul8Bt4VWGx9Zl1nU5Bq6aWUO6Nt1Jqg+bWWnReDRaOGjWtCVE0zsk8pMr673W0csYMy16/O7FwbVxBwH3O4fxyH7EFYfWMaTTl6GOpgK97Kn9nlXvnvXh9WN/rpfxL6/5eQXmPPk7pbdpwj6kuZbOI5NaqzXWtT4XMXBadDM4Ly8Mlz/eiLRs2OA3Xzm8qN+iJu+9DWXyNWdVr0jj+jf7OzrK+A2BlN1P+36ZNlHpBB0rdZ3/rPkzZY1/K5PuEiUJg1pvv0MQ997ZWftL23pfGd7jYSg/8MfJ7+m2ffa0lxMImmMBuyW9gHhIxc2s35Pxq8n2pReP3O4iF8TsnFaf7UBcEu142pj3fc9s1pHOdJv33mm3fSSzidp1xZnurF5bN+ebXqUN5teta7XgyXliPPU5LB39L2ZijanqYRxDchz7/3vtp0p5cJl/r5D32pLT7H3C+sUvGCyODrz9t7/0ofb/qlNrWDu23YOgQmtTiCMo+5FDK2fdASu98nZWnX31dOHLgP2RIP4QFYYDZHIKG6AqUlyDk3evelAjgHFT0eHfKrNeEpnLvIJftU05tR2sXeM8bjDdkcGsw5/33KZ0FBROKGGPnspJnnHkOv/VHWapcGjatW0vZj3alwjvuotmDoo8es0tYnpZOKcecyPXkh7ZxE8qp1YDSuHGktGxFaSxAeVYvpwX/oLX4Os6gNXNmW+lKg1v/SA+hhSU0+Xxv4PWZ1fkaa5KxhK8dE6VpF1xCG5a5E51+nVTiYdcymojhz0EHUX6NevxQ1KUMvncZjZpSeu36lI+VimbNrQnj1Oo1qPgJLo/h5rdu4QJKPfY4HsY15XvKYs2CMvPVPtZ3lg3/x+5PEK0sKaaMw1tbS6Al3IPBEHCJ05ME5n3wIWVZe1H494MfSuf/bnubL/h+FE3ChrWada0l4cLmrSyizDzOJ4+vvYAFIeWA6rQwaojkJwiAew2zuL4QA9w7CGHWzbc638RiAf/ek+o3teaOcP+Lmza37k8memp83wr479l1WURPOZUKDm/F7ZBFS+khANMf62bVGdeay2Xndnvc+hzfuvUquvFmay6okMvM5mHS4rG/0JQWra05NLShghr1Kef6m7aJDH5lN62EIwdeQchnQcD4s6BhY8q94koqfvp5Kn78aSriH9pl4ZPd+bPulNO1G63gH1FDdMFhBQHLjgWNmlE2P5hF3PUqfvJJKnn8Scq/+XZKO/YkyuQbjUaAZdL0Cy+mf/ILrPQy1/g9BLsm6//6i9LOPJsbPzcSLhdvmnyubxo3qqyOV9If/T+jtYu9JyohNSbupDtwdB3WLVpoKXl+rfqWbwWcrYq7PUF/TZ5My4qn0p8//UQ511xDWZgL4QaVw8KUc9vtVhfc/Z/zfw/cz6KHDLn8ABdyF3/uZ59RBv8dw4QiLjPjmONozfTpTgo7pZani7wHHqbJ/NYpevAxmjdwIP01diz9PW48zf96MOVddwNl1W9iPwAsbJP5Xi2dZE8Yu3ei6KHHLKEuZIEtQO/n4o60ZZN7LH2kmc4dMIDSWfith5PFMbNde9q0atW2uv3xwUfWUrb98MYKwp9ZWZR1+51UxMPKvGNOoCKsOEH80C7+ey0V3P8gFd99L2Xd1oX+zMiO5MlDhkiefoLwmiMa3Bb4t8u6JXLGgmuzIiefJjdvze2Kh5v8ZwGLfVrjxpR37U00HUOlni9Q5kWXUBb3Vgoa4jmwezCuIGwUPYSpj3W1ehiol9XT69bN+hzluWWW3HoXCxT/xo0Po9zTzqDsiy+1xACrRpm1G9AUfqlMujrSQ7Anlt3UsXDkQB8yYKa+BA8h/9B4k2WzQqGrmMVEdw3/zj24Bk064BBa+vPPTupYRBcbdg4BgoC18gJucGhYOVyHHP4zF0KAh4rzzIVzU5cu1hvahlcP/eYQbCvngWP8nZtreSfi2qdy9xMPVzG/BaHwcGxKPf5EKn7mOVo91/Y8RKqt3Iz+JWcNX8D9DOPI7INqWvc3rV5DmvXe+843EZst69dSniPMUxs3p1Tu+fw1xZ4lj8BbivtJZMjAjZeHLNkXXkjZfC1wJsNDC2eqjCOOplUF7lAGzV+rtf0p+PdMuJd7/ToAdOfz77qb2w2/mbmBo1te6AxT3FyXjp9IaXy/izDhCx+OJi3o720TfREBzb+jCw9H0CPksf8hdWjqc7aTlGthC4I9HHIFwW3ibln4Nx48rBDhLZmKSUXulUlsy7OMguB+B6D7nnfTrZxPLSrguqNNprZoRfO/HbItL2Dz2rU09dnnbP8ULg+90LiC4FxrtCAAbtklt91l9RAKDuP2jLkzONJxu8m5/hbLXWD5uHG0NCOD64e2iXTRtY6FIwdeQcjlLg26WkU8JixuyA8Degz8xoomVB6efhn8oy3jboqG6KLLSxDyWRDQUNDo8HkOqyPeJNZYjG9IDo+Rc2+5iVbk2UtoMtfSBSEiIqu5q55zy+00ha8X3VDLWxPp+AdH7ynrkBo0mbv+8wbbwwK7Ybo/pxdruOucfvQJ1tshj4chOZ0iDl1AdF2X/vILC0EjHgK14OusSdOd+RDYuHWVcD/Z1kPgxluANzKLylS+b4WN8EAexkKPMXVdyrzyGtpqLZcirV9TiRVV3Ybor3G/UTraBN+f/HoNLIcxzAe42MJ/z8DMP1836oT64a0ZDatndtLJVNiQh0xwE290mDW8AtxyNUGIfuBgt2nDBsq48CJ+U7Kgcj6T+X67fgj43mbklyoPQVjBPdI0fijRQ0IbgWPe7Hfes75DOZjhtx9J5LmVcnj4BsG32mEZBMG1Kb7zbh5y4gXegodt3BPC8OGxJ7g82Q79ft8IHDnwGTJwo8lvym/jtqdRNqILseJK5vGPnnruhfyjpdnJBaIrUC5DBqjfORfQVP5xpr38Ms14sTd3YR+h9HPO5bdPI25ITXi8xTeFey+TjziSlk30+jmUPmSwa+PeTvx90c+/WsKQeviRlMl1KeIfsBCKzMOqIn7LT+EfZE4/ezVGvwr70/nffEMZte2Gh3H4rNffoM1wsuIewab162nzug3WGvqmjRtpZXEJv8WPshpYPjf8vKuupq1b7QcMddN+XvcTVxCstwa/geBpmcv3PfvUMygH49bmEIXDKZ17e7P5YQCQ1q/uGK5EAxvQFo74jmb3eZOKuz5O2fffR7lX/dd2LedrQwPPPPVMWrc8ysmJgbIycP/4ocrj3z/zwkstxzIXS3/62fLew7Amn0U4+5IrrGEFUru/h18PAXBruYHvZeaFHaiQy8Aqw+RGjWjRxInWd1Zd8H/mtjxDDhmAOR/35SEZvzSatuJ2yEOyE9vShr/+tL5DWfaQz/7lgHkDvuQyuUcVVhDuuod7VPYiQDH/xhmnnE4b/v7b/hJlOteJ0t1rcf+UcORAEwQugCuRwQ1mDv8AVmabuCvMKh9L/mwjN1KfLbTRBZfLpCKPgfPu804qbuJu2IKvv6H0o47hh7UZFbTgH43fgFNOO4s2LFtm2bi3YzE35HiC4FcP4O+pU2kGN4z0tqey6NSz3t6YXyjia5rMjfjv3BzLzi+Hac8/bw250B0ugHCd3JYyzj6Hss48m4k/mWfx3/9zLuWefibl88NbyPcKjkOp7c/mekYmndzriYb7iSsIVi8PvSoeS6a2P4dWz55NBV3+ZzWuQu79FXHPKqXNcbRqljsU8OYZvW16ye/jrOWztCOOoVS+h/hd8niMms9DoLxa9nABb38Iczq/SNY4zlxuXeGOPqXNsZY7OHoqaTzGX56ZaX0HTHumh3N/0CuqQ3PesYdTSO22sHg9BNiBG1kQMi68eJsgTOHe3EJnTiMa2/IMIQju90XdnuA2gXqx2NVqQAU365OOboplYyB+sY5JZRkyYPk3x7r3PGRGL/Z/DzrfBIcjB/ocAh4Y+CHM+cR2yikN8i0CRH9SLoKAVQafZUdg8ahR1mw9xqnFzVpRGg8r5vTrb33n3uQwguBi3dIlVPTAI5RZl7vgGAMexg/3IfxGfuzJuDkUP/CQ/aNx2RiOwW24GI0Ibwr8qBg7409unJhBL4T7ND9chdyrmHxaO1q7yq6nqSCU4G3F9wM7Mpdn2+P11dOmUWqro618MXTAPpI8Z9JSg/Updz+nv/gSTarPDR0PLD9gBbVqUwYeHn4Aso4+nnmc1Rsp4F5TIX8PQVj7p/2GxL13cy+6715u5HYDxoTZjJdetT7fzN38zAs68FC0IRU1bkrprY6gVTPsSU+kLZsgYA7hcEqxBMHrulweguBiapd7rMk9zB/ksF0R95w0uL/bMm776SwE2N8TVhByuc1YwxS0pZ69nG+Cw5GD+IIwO6F+COEdkyyia2T9SZR7cUerUaFLj/mFQiEgi0eMiDuHYFPA/ZjpPoro/hVcdzPl8du3EHlx48s+v4PVsP1Qcu8Dzo/Hb31Ok3PUsVbXMvO4kyj9+JMp/QQm/mRmHMc8/iSLqTx0mNL5Wm7o7njfroeE+0mkh+D0qh62dztiNgCY+dZbVtfdrkcLSuUGPj/OCchzPv6EUg6uYS8FYmWExSTv1jto3rdD6O/8PFo7fz4t/f1XHkO34rF/s209BFcQ8Lu4jXzpL2MpFSsSLNqYa8jmoSdq9XdRMadnIef881kYC26ILJW59xwoqyBoexnKUxCm3dnF+hzDNPRyCrv6Ha1n57j8R7eHUB6CgFUZzMvUpUIeRpcVjhx4hwwVJwgBewh+guAQKL75Nv5h+A1k/XCNKOea65xvbCweEX8OIfJzRGB9ZxXiWtl/zvtqMGXyj1DE3dIC/lGx7IPr9MO07t2txmKpOfcA/uAHE0OaDQsX0nqH7t/xp8v18xfQxr94PM5vavvhsCpjZxoF95Ntk4p8z/A2znnMXb+2LRBGDkuzEDNr5YZ/iyknn0rrl9gPcDQ2LP2T0k48je+VvREng68TXokSy2bNoMktWrFgeAUBdxQCitKxt8TuCdjbyVO5p7B27lya/xUP+ayHkocS3CP64+vo0HZRD29ZBWGyXKUpX0Eo5IcXG9lwj+Acl3/9tnesgJ3jkh/GcA/TmQwPIQhFWN2xep0YZrEg9EqQIMAZIqNGLZrluO3qcJsm/9etYRSiP8KDksnj4iJ+O2ApqGxDhvpCELiZ8UNq+2iTFaAk5/wLKb8BNwTuusG+4I4ulq17k91JRTiYmAwZ7K60+637dzu3eQMGckNC95cFgR+YHB7nb1q3zvpOw9xP+rM9HFZwLfwjPhL5gc0QqYsGu37cy4va7ZjDDT16t6ObfMlvv/GDwsORps2tpS9LQJxurq17tuGSX3+xlketJdd6jSnrnHNp62a3p7LVms3G3/8uLuCHm3sIWM3gfDNOYUFwJtUsWL+Rnees9961JjTxG2A2/o9PB9JUfqPm4d40bEpp3FNyN5O5qeyUtiDg2qIFwf1t3fw3YnMTRMcShBY0pUFTWjLBnlQEomUVKA9BmPXBB9bzgt8WDlpT4OexYKGT3s4Nf3dLnfbaa9uGTkXcDtMRIGWVO0dkY+qjXcmelzAbMuA5wctAwrUFtmzazM+Je3WxdXLkQBcEVAI/2qzPPrO/KgOiKxItCNh8VBZByOPub36X2CEAGsO2h/2boZTWoBmrtB0XIa1GTZr59rvWd253eclw7DFAjAJdEPDnmnkLadXiBdYnLmQNsZ6cc/mVlFcPS7QsPnyv8u+4J8ZGYkVJCaUedgQ/NPDqa8Fd5CNpaUpksssuw72a2PLi5evC/WHjbX8G3LwKHn6Meyw1WRCwXHYYTanflP50fO3dvObymzqtFjd0CGhtFr3LLrc+x7ewce3mffGF5QhTyG88zE94BCEKq2fNpLQjj7bmCnIbNqP8Sy6nvDPOsv6dXaMuTXX3fjBxN9wyAE0Q3Obt7uZEPIesSy+zlsdLuPcGd+uFg760vovkFGk3ZRWE6LyW52ZTKsQVzlB8PxE/pOQJ/ZTvdfMX8v051RJODOuKuR1mnHYmbVi1yrGwMc1YENwhAwThReebKLAx2tXcfv0p7byLaQoP0+Z9/qWVh30P7NwcOfCfQ8jmC5/Rs6fl0ba6oFCwwGZhAa3Kz1fDlkXfsG2CwEOGiCAEm0NAEJW8/93nfBMB4gzgbZ3auo21ymB5fzVsQFOOaEOrZ8+1bNxGpQpCVIAUoOS5njSxzTE0ndV2yYTJtGbhItqCMGsb1ltLOn9OnMBDkestb0KMGTGunsKNbvFo+/jzyCPtRW6XuynnkBp8PeiqN6G0Y4/jsfi3tMlZQYjGli3/0oppM624j/rdiYV7jfHjIQB2DdfyGyztuFP4njW2RAGrS1lnX0CbVkY8AxeNGsP3yx6CwRsu8/Aj6K9Jqc63NpZNSafUE07hri83cCzFckNPjyMIyLuI74PlSowVIRZIy6mGfzfMLywd9/s2u6gOmoV4ghAtHIU330J5LGRYacmt34iyO1xKa2fOon9ZLDZxe9m6cWNoQYjG1i1bKPva6y3XaKv9cRtP4/sx9bnnaM38+VZZWzZu5nuVSlkdLrFebhBP2OL+Z7blIYMYbpabIDAWfzeSJh5az7pnBbXq0ER+BpZyLxFw83LkQOshNKACvpHWTDD/YIgQlNmidQwzuGGkH34kZfC4cTx385aMsR+GaET9juXSQ8hv1IxyT21H0x9/iqY/8xzNfOpZyr+zC6W3O4syUGd4KvIDivXYFP7x5vSLbFt2s1/CQ4ZoQUiJ6SHYP2zW5Z0o/+BD+e1Zh9LQhT32RMptfx7lnX8RZbVtZ61k5GIegn/MqU0Op8zqNSjnnvt4iG/vNItumNvgfLRq5gxKOfZ4KoA/Aibh+K2MXW9Yfiy+936a8czzfF3PUNG991Euv+Um4Jqe8W7S0lCaIOBb2wLN034c/hjwJaXy0AqNzurC89ABKwou1i1eRFOOO4mKebiARoe3Wtpxp9L0Hj1pzod9LZfk9JZtuIHXpIKmCCjDDZzv2ZST2tIqLWyZgyU//cw9EuzZOIx/C+5VNGvFb3R+U15wEW1m4d2GSKUtxBeEyH9n9nmTMg5G74evi+uU26ARZbD44jdM/c+59M+MSMTteILgikY8QbCHldxLyMykifDFsObJWlMBD7MysanpmJMo+7IrKfuCCymt+WH8m9Si7COOopKjj6dCbj9Ylck8+XTauDw2yGp5CkLu/Q9bS8T2hq9WlH1wDSpgsQLcvBw5iO0hFF7Z2d6YwZUA4TGGeHuWB5bg1EbNaRqcMNh+6ahRTg4RuAUBEISc086iEm5YEIRUfru6ggBLu6scncLG9DffpOxDIAhY82eR4gck79C61o2C63JBLW5U/GCjnoUNGvJNOZQms92cD22HGwC5Or8ZC8JIyuKurRUzgd8ciL+4bnVEEP7h3tA4ePRhjM95TuW3P1x+89kWhIjY8R25J4L1fa5L9h1daOM//0TV3m1GOpalpFDK8adQFv8ohfB+xJuifkNrLIglKxATRYVwyz7gEMq6+HIWqtIjSruCUNSrt7UMCtdYxHJ0dztqwov5gOzO13Ijr8v2LHB4mFl8V0TFD5jz/geUelANmorenfUbNOY61rLufz4/dNkHMjteTkX/aW+JQUnD5pTKY+h/5tm9Mw2b1vI4/3xnmzmXhzclxGjWu3LCMra+89//0HKdt34/bncZV1297eEF3HuwZtYcmnzksXwP7U1q6AEhRkYhX2dGoyb0T1Fkq/a8Dz+yJ3vdPPml6N5tt/RZr7zGNtjcxKLBv03WLbdu+y66hgs+H0Qp1uYmDCU5P75fmFOAh2YhDy8LuHxsfpo38AsqufZG/pxfLCyyWSe0pQ1iUncGC3keXysEIY/LznM2N0WuEpOKXbitYMMav7zZttAJxCOR1+1JyjroEPs+MPH3qa/YS77uFThyECUI/261TjKazI0wjSuKmIGg+3f86TK1bj3773wDf69+CC0eOdLKwg+buZs2nt80KdUPpXS+oT9zGbN/cLvY1vSU9TeJQlbmiXvsZ822YlsrlBI3CWN2/B2fZ/AbLq3x4dxNPZ2KeFz8d16uk9qLBUOH0i/7H0SprKqpBx5Cv7Iyr40ShA1/L6OpL79C6eecRxl8k3F9WKvH2BbE39O5y5XKD3H6xR3pj0FfWb78QHwZiG04a+bOpQJ+UNPaHMv3FrvhnL0i/Ke1TZj/nlaH32rcE8vkYdLmDf6TlRJZ3Hsat9d+XM+69Ps++9MU7nnEw4qsLBrP4/c0BKjlhpyCUOTnd6D1/6y068xqOuP1tyiVezTYEm9tf+Y/8QCn4gF58BFav/wvyuvyP5q4936UdmhN+pXFc0V+npV/7JVH/jXnjbesNzOGp3hYU/mN6cbSjEVkZmXGW2/TryiDry1lv4NoHE7e8rnzi34cQyn8dk7ndoO9Nzks3th/8xs/nMtz3bpxnu++Tb9Yedax8vz9oo602Qq4gpratZ3a80W+p/tbNthROeHq2NWraCz66SdKPecCaycofkd7DxC3GX6BpJ12Ni34zt56nXnVNTR5n+qUym/ucXxv1zgOYu7V5N53H43fe19OV5fG73UApT7wkPNNRBCybryFJu5zgP1b770/ZfJvrwG9l0nwtGUhyOTndXKb42hllCgCjhxAEJyoyywIC8dPpDlDR9Dc77434/ff0+xhw62zGeJh68ZNNHf0zzT72yE0d9gwmjHkW1rpbE/GxdmTfu5l2sC/lhUV0Zy+fWnWG6/T1Od7UPGT3ano8Sep6AkeNjzXg+a+8aa1/PdnWjptWB4bHcme3Y1tLKvmzacZ3wyhOVyHOUP4T/7xNm/aZFm5vQgAS1d/Z+dZgUhnv9aHCp9+jgq7P0uzXnqF5n/+JS3PyaEtmyM+B/bMtY3Yq4gAn8vvVvP4cv6IYdwlfZWv6Wkq6PoUTXv2eZr33gfWGRRr5s7mRO6UaGmw67AkP5dmDP6G7/MI/nMwLcxId+5v7L2wHjPnohdMnECzvvmWZg8fzumG0zROt2rp0phy/5laQrPff58K+G2DLc6zP/qQlm976LncrAyayenmsujOGjKU1jjxGSXcWkzt9gRls+AWczc6m8fexU8+43zjhZtm+dRp/Pt9a9VxFtrSuHHbuuzRcD9Zs2gRzf10IOf9HBU88QRN79WT/uDfFBN4rs3yaSLP35GnXSLuKOz+KiygmV8P5nbzHc1k2/kTJ8Z4cdqI/HvT2tW08MdRNINfLlZb5WHYwu+/2zZPAMuFk1P4ng/l520IzR75PW1w5m7cXBbzQ4yyUC/Ub2FG5rbv3Xot5N7mrK+/teqF33pJbq71eTTcf6/IyLJ2Kec/+zS/NO3dwPa39rU6chA7ZKhouJWVF2FD/zQe7BsVeaMEgVVawCKtB02k8csCn0uawuyKkKNuZ6eXJdq1iFcPq83zf7TUsdC/9ct96fgJVu8CfgslPMyY3LI1rdx2kpZPScqDD/iW7JONC+tORYVei4ad1G5Lzj88kNGvAJjGv6MM/tpP4rf9znHqZdeK/+ZXjHLhWvtxd7m61o4cxE4qOv8PSL3ysXAugxNsa1yR/2z7wwPr4uxK6ybON1Ff4mbjraE3CPuniKmH/Uns36z0KNf+PBb2Z5H0Uel84PmOP7DTRH/j/sv+xvk/0/7UDI6tlTa6EcTJZdsX1p2z/2ddO8PKJ8qE4fl71Aco003r5ODBP8XFlMZDtTxMVPIYGwFti7vbvQNvswXc3Oz88F/3gbI/1cuxwF/h24iNa+9+6v5dy9P+r9NinP/jPxFLDfjU/SaSl7SO/sb+DrlGpNem+zlg/8v9u2tvI9ZSARq8kyJig7+5rCI9hCR2fLhNECs4CwYPpZTjT7JWsqwZ+7oNacrJp9G6RYstGxuRJptExcGRg6QgJJF4LOExd+pFF1NqvQZUgNWaw+wTrSbD72CMHWAHE8vWOy6pB5UCRw6SgpBE4rFw5GiacnBNKmrahIoRp4F7BpPrNaU5AwY6FtABloOkHlQaHDlICkISicf6ZX9R5sknUVFdO44C9isgaC1gzxvYMpAUhMqDIwdJQUgisXAf8LS77qLxx51As956l9Z7loiTqFwQ/T8Ke6O3AhcQ3wAAAABJRU5ErkJggg=="></a>
          </div>
        </div>
      </div>

      <div class="copyright">
        <strong>© 2023 A101</strong>
        <p>
          Kullanılan tüm içerik ve görsellerin kullanım<br> hakları A101 Yeni Mağazacılık A.Ş.’ye aitttir.
        </p>
      </div>
    </footer>



    <div class="clear"></div>
  </section>


  <div class="js-bundle-error-modal product-alert-modal bundle-error-modal">
    <div class="content">
      <img loading="lazy" class="bundle-error-modal__icon" src="<?php echo base_url("assets/a101/")?>danger.svg" alt="Danger Icon">
      <p class="bundle-error-modal__big-text">
        Sepetinizde seçtiğiniz ürün farklı ürünlerle bir arada bulunamaz.
      </p>
      <div>

        <button class="js-cancel-product-bundle
      bundle-error-modal__cancel-button">
          Vazgeç
        </button>
      </div>
    </div>
  </div>


  <div class="back-to-top js-back-to-top hide-on-app active"><i class="fa fa-angle-up"></i></div>
  <script src="<?php echo base_url("assets/a101/")?>bundle.js.indir"></script>
  <ul id="ui-id-1" tabindex="0" class="ui-menu ui-widget ui-widget-content ui-autocomplete ui-front" unselectable="on"
    style="display: none;"></ul>
  <div role="status" aria-live="assertive" aria-relevant="additions" class="ui-helper-hidden-accessible"></div>
  <ul id="ui-id-2" tabindex="0" class="ui-menu ui-widget ui-widget-content ui-autocomplete ui-front" unselectable="on"
    style="display: none;"></ul>
  <div role="status" aria-live="assertive" aria-relevant="additions" class="ui-helper-hidden-accessible"></div>


  <script type="text/javascript" id="" src="<?php echo base_url("assets/a101/")?>optimize.js.indir"
    style="display: none !important;"></script><iframe height="0" width="0" style="display: none; visibility: hidden;"
    src="<?php echo base_url("assets/a101/")?>activityi.html"></iframe>
  <script type="text/javascript"
    id="">var CookiebotScriptContainer = document.getElementsByTagName("script")[0], CookiebotScript = document.createElement("script"); CookiebotScript.type = "text/javascript"; CookiebotScript.id = "Cookiebot"; CookiebotScript.src = "https://consent.cookiebot.com/uc.js?cbid\x3dc3954964-2d91-4175-9d9a-313049a31fb7\x26consentmode\x3ddisabled"; CookiebotScriptContainer.parentNode.insertBefore(CookiebotScript, CookiebotScriptContainer);</script>
  <script type="text/javascript"
    id="">var today = new Date, dd = today.getDate(), mm = today.getMonth() + 1, yy = today.getFullYear(), dateFormatt = +yy + "-" + mm + "-" + dd, userID = google_tag_manager["GTM-WGSGG57"].macro(19), checkLogin = localStorage.login, checkSignUp = localStorage.signup; "None" != userID && "" != userID && ("1" == checkLogin ? login() : "1" == checkSignUp && signUp()); function login() { dataLayer.push({ Category: "Member", Action: "Login", Label: dateFormatt, noninteraction: "true", event: "gaEvent" }); localStorage.login = "0"; localStorage.signup = "0" }
      function signUp() { dataLayer.push({ Category: "Lead", Action: "Signup", Label: dateFormatt, noninteraction: "true", event: "gaEvent" }); dataLayer.push({ event: "taboolaRegistrationEvent" }); localStorage.login = "0"; localStorage.signup = "0" };</script>
  <script type="text/javascript"
    id="">window._tfa = window._tfa || []; window._tfa.push({ notify: "event", name: "page_view", id: 1233202 }); !function (a, b, d, c) { document.getElementById(c) || (a.async = 1, a.src = d, a.id = c, b.parentNode.insertBefore(a, b)) }(document.createElement("script"), document.getElementsByTagName("script")[0], "//cdn.taboola.com/libtrc/unip/1233202/tfa.js", "tb_tfa_script");</script>
  <noscript>
    <img src="//trc.taboola.com/1233202/log/3/unip?en=page_view" width="0" height="0" style="display:none">
  </noscript>
  <script type="text/javascript"
    id="">function getUrlVars() { var c = {}; window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function (a, b, d) { c[b] = d }); return c } function createCookie(c, a, b) { if (b) { var d = new Date; d.setTime(d.getTime() + 864E5 * b); b = "; expires\x3d" + d.toGMTString() } else b = ""; document.cookie = c + "\x3d" + a + b + "; path\x3d/" } function deleteCookie(c) { var a = new Date; a.setTime(a.getTime() - 864E5); a = "; expires\x3d" + a.toGMTString(); document.cookie = c + "\x3d" + a + "; path\x3d/" } getUrlVars().pfx ? createCookie("pfx", getUrlVars().pfx, 7) : deleteCookie("pfx");</script>
  <script type="text/javascript"
    id="">hype = {
        pagedata: {}, logger: { groupOpened: !1 }, modal: {}, exitIntent: {}, create: {}, hyperootdomain: window.location.host, listenedFunctions: {}, lastListenedEvent: null, dataLayerIndex: -1, dataLayerEcIndex: -1, loggerstarted: !1, what: Object.prototype.toString, asciilogo: "  _                      \n | |                     \n | |__  _   _ _ __   ___ \n | '_ \\| | | | '_ \\ / _ \\\n | | | | |_| | |_) |  __/\n |_| |_|\\__, | .__/ \\___|\n         __/ | |         \n        |___/|_|         ", isObjectEmpty: function (a) {
          for (var b in a) if (Object.prototype.hasOwnProperty.call(a,
            b)) return !1; return !0
        }, cleanObjectValues: function (a) { var b = {}, c; for (c in a) a.hasOwnProperty(c) && ("[object Object]" == hype.what.call(a[c]) ? 0 == isObjectEmpty(a[c]) && (b[c] = a[c]) : "[object Array]" == hype.what.call(a[c]) ? 0 !== a[c].length && "" !== a[c][0] && (b[c] = a[c]) : "[object String]" == hype.what.call(a[c]) ? "" !== a[c] && "undefined" !== a[c] && "null" !== a[c] && (b[c] = a[c]) : "[object Number]" == hype.what.call(a[c]) ? b[c] = a[c] : "[object Boolean]" == hype.what.call(a[c]) && (b[c] = a[c])); return b }
      };
      window.hype.addObjectValue = function (a, b, c) { "[object Object]" == hype.what.call(a) && ("[object Object]" == hype.what.call(c) ? 0 == isObjectEmpty(c) && (a[b] = c) : "[object Array]" == hype.what.call(c) ? 0 !== c.length && "" !== c[0] && (a[b] = c) : "[object String]" == hype.what.call(c) ? "" !== c && "undefined" !== c && "null" !== c && "" !== b && (a[b] = c) : "[object Number]" == hype.what.call(c) ? a[b] = c : "[object Boolean]" == hype.what.call(c) && (a[b] = c)) };
      window.hype.isDataLayerLoaded = function () { if (1 == window.hasOwnProperty("dataLayer")) for (var a = 0, b = window.dataLayer.length; a < b; a++)1 == window.dataLayer[a].hasOwnProperty("ecommerce") && (window.hype.dataLayerEcIndex = a), 1 == window.dataLayer[a].hasOwnProperty("arrPort") && (window.hype.dataLayerIndex = a); return -1 !== hype.dataLayerIndex ? !0 : !1 };
      window.hype.getDataLayerVariable = function (a, b) { if (null == b || "" == b) b = 0; var c = []; if (1 == window.hasOwnProperty("dataLayer")) for (var d = 0, e = window.dataLayer.length; d < e; d++)1 == window.dataLayer[d].hasOwnProperty(a) && c.push(window.dataLayer[d][a]); return 0 == c.length ? null : c[c.length - 1 - b] };
      window.hype.getDataLayerIndexByEvent = function (a) { var b = -1; if (1 == window.hasOwnProperty("dataLayer")) for (var c = 0, d = window.dataLayer.length; c < d; c++)1 == window.dataLayer[c].hasOwnProperty("event") && window.dataLayer[c].event == a && (b = c); return b }; hype.logger.isActive = function () { if (Storage) return !0 === localStorage.getItem("hypeLogger") ? !0 : !1 }; hype.logger.activate = function () { Storage && (localStorage.setItem("hypeLogger", !0), confirm("Hype logger aktifle\u015ftirildi, sayfay\u0131 yenileyim mi?") && location.reload()) };
      hype.logger.stop = function () { Storage && (localStorage.setItem("hypeLogger", !1), confirm("Hype logger kapat\u0131ld\u0131, sayfay\u0131 yenileyim mi?") && location.reload()) }; hype.logger.info = function (a) { "true" == localStorage.getItem("hypeLogger") && (!1 === hype.loggerstarted && (hype.logger.info(hype.asciilogo), hype.loggerstarted = !0), console.info("[HYPE Bilgi]: " + a)) };
      hype.logger.warn = function (a) { "true" == localStorage.getItem("hypeLogger") && (!1 === hype.loggerstarted && (hype.logger.info(hype.asciilogo), hype.loggerstarted = !0), console.warn("[HYPE Uyar\u0131]: " + a)) }; hype.logger.group = function () { "true" == localStorage.getItem("hypeLogger") && !1 === hype.logger.groupOpened && (console.group(), hype.logger.groupOpened = !0) }; hype.logger.groupEnd = function () { "true" == localStorage.getItem("hypeLogger") && (console.groupEnd(), hype.logger.groupOpened = !1) };
      window.hype.checkifloaded = function (a, b, c, d, e) {
        var k = !1; "undefined" == typeof window.hype.checkerSlot && (window.hype.checkerSlot = []); var f = window.hype.checkerSlot; "number" !== typeof e && (e = f.length, f[f.length] = 0); var g = c || 100, h = d || 50; setTimeout(function () {
          !1 === window.eval(a) && f[e] < 1E3 * h / g && !1 === k ? (hype.logger.info(a + " ifadesi true d\u00f6nmedi, " + c + "ms bekliyorum."), f[e]++, window.hype.checkifloaded(a, b, g, h, e)) : f[e] >= 1E3 * h / g ? hype.logger.warn("s\u00fcre doldu ne yazik ki bulamadik") : (hype.logger.info("ifade " +
            50 * (f[e] + 1) / 1E3 + " saniyede bulundu, fonksiyonu calistiriyorum"), k = !0, b())
        }, g)
      }; hype.treatAsUTC = function (a) { a = new Date(a); a.setMinutes(a.getMinutes() - a.getTimezoneOffset()); return a };
      window.hype.dateIsBetween = function (a, b, c) { if ("undefined" == typeof a) return !1; var d = /(\d{2})\-(\d{2})-(\d{4})/; b = "function" === typeof b.getMonth ? b : new Date(b.replace(d, "$3-$2-$1")); var e = "function" === typeof c.getMonth ? c : new Date(c.replace(d, "$3-$2-$1")); a = "function" === typeof a.getMonth ? c : new Date(a.replace(d, "$3-$2-$1")); return a < e && a > b || a.getTime() == b.getTime() && b.getTime() == e.getTime() ? !0 : !1 };
      hype.setCookie = function (a, b, c) { var d = new Date; d.setTime(d.getTime() + 864E5 * c); d = "expires\x3d" + d.toUTCString(); document.cookie = 0 == c ? a + "\x3d" + b + "; domain\x3d." + hype.hyperootdomain + ";path\x3d/" : a + "\x3d" + b + "; " + d + "; domain\x3d." + hype.hyperootdomain + ";path\x3d/" }; hype.getCookie = function (a) { a += "\x3d"; for (var b = document.cookie.split(";"), c = 0; c < b.length; c++) { for (var d = b[c]; " " == d.charAt(0);)d = d.substring(1); if (0 == d.indexOf(a)) return d.substring(a.length, d.length) } return "" };
      hype.checkCookie = function (a) { return "" != hype.getCookie(a) ? !0 : !1 }; hype.removeCookie = function (a) { var b = "expires\x3dThu, 01 Jan 1970 00:00:00 UTC;"; document.cookie = a + "\x3d; " + b + "domain\x3d." + hype.hyperootdomain + ";path\x3d/"; document.cookie = a + "\x3d; " + b + "path\x3d/"; document.cookie = a + "\x3d; " + b }; hype.toFixed = function (a, b) { b = b || 0; var c = Math.pow(10, b), d = Math.abs(Math.round(a * c)); a = (0 > a ? "-" : "") + String(Math.floor(d / c)); 0 < b && (c = String(d % c), b = Array(Math.max(b - c.length, 0) + 1).join("0"), a += "." + b + c); return a };
      window.hype.isInCampSaleDate = function (a, b) { var c = new Date; a = new Date(a); a.setHours(0); a.setMinutes(1); b = new Date(b); b.setHours(23); b.setMinutes(59); return b > c && a < c || c.toDateString() == a.toDateString() && a.toDateString() == b.toDateString() ? !0 : !1 }; window.hype.isInCampSaleDate2 = function (a) { var b = new Date, c = /(\d{2})\-(\d{2})-(\d{4})/; a = "function" === typeof a.getMonth ? a : new Date(a.replace(c, "$3-$2-$1")); b = Math.abs(a.getTime() - b.getTime()); b = Math.ceil(b / 864E5); return 10 < b ? !0 : !1 };
      window.hype.dateIsBetween = function (a, b, c) { if ("undefined" == typeof a) return !1; var d = /(\d{2})\-(\d{2})-(\d{4})/; b = "function" === typeof b.getMonth ? b : new Date(b.replace(d, "$3-$2-$1")); var e = "function" === typeof c.getMonth ? c : new Date(c.replace(d, "$3-$2-$1")); a = "function" === typeof a.getMonth ? c : new Date(a.replace(d, "$3-$2-$1")); return a < e && a > b || a.getTime() == b.getTime() && b.getTime() == e.getTime() ? !0 : !1 };
      hype.titleChange = function (a) {
        titleName = a.titleName || "HYPE"; session = a.session || 0; if (0 != session) {
          "" != titleName && (window.document.title = titleName); window.fakeCookie = 0; window.onbeforeunload = function (d) { localStorage.removeItem("sessionTimeout") }; if (localStorage.getItem("sessionTimeout")) { a = localStorage.getItem("sessionTimeout"); a = a.split(":"); a = a[0].trim() + "." + a[1].trim(); a = parseFloat(a); var b = 6E4 * a } else b = 6E4 * session; var c = setInterval(function () {
            b -= 1E3; var d = Math.floor(b / 6E4), e = Math.floor((b - 6E4 * d) / 1E3);
            localStorage.setItem("sessionTimeout", d + " : " + e); 1 >= b ? clearInterval(c) : (window.document.title = localStorage.getItem("sessionTimeout") + " - " + titleName, 0 == d && 1 == e && (window.document.title = window.document.title))
          }, 1E3)
        } else "" != titleName && (window.document.title = titleName); "" != favicon && (window.favico = document.createElement("link"), window.document.head.appendChild(favico), window.favico.outerHTML = '\x3clink rel\x3d"icon" id\x3d"favicon" href\x3d"' + favicon + '"\x3e')
      };
      hype.modal = function (a) {
        void 0 == a && (a = {}); var b = a.className || "", c = a.idName || "", d = a.width || "50vw", e = a.height || "500px", k = a.left || "calc(50% - 25vw)", f = a.right || "auto", g = a.top || "calc(50% - 250px)", h = a.bottom || "auto", p = a.background || "#fff", q = a.padding || "25px", m = a.position || "fixed", n = a.display || "block", r = a.closeImg || "https://hypeistanbul.com/img/close.jpg"; a = a.html || ""; var l = '\x3cstyle class\x3d"hypeModalStyle"\x3e'; l += ".hypeModal {width:" + d + "; height:" + e + "; left:" + k + "; right:" + f + "; top:" + g + "; bottom:" +
          h + "; background:" + p + "; padding:" + q + "; position:" + m + "; z-index: 9999; -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; display:" + n + ";} .hypeModalBlocker {width:100%; height:100vh; position:" + m + "; left:0; top:0; z-index: 9990; background:rgba(0,0,0,0.7);  display:" + n + ";} .hypeClose {width:40px; height:40px; position:absolute; right:-20px; top:-20px; background:url(" + r + ") no-repeat center center; background-size:100%;}"; l += "\x3c/style\x3e"; document.head.insertAdjacentHTML("beforeend",
            l); b = '\x3cdiv class\x3d"hypeModal ' + b + '" id\x3d"' + c + '"\x3e \x3ca href\x3d"javascript:;" class\x3d"hypeClose"\x3e\x3c/a\x3e \x3cdiv class\x3d"hypeModalContent"\x3e ' + a + " \x3c/div\x3e  \x3c/div\x3e"; document.querySelector("body").insertAdjacentHTML("beforeend", b); 0 == document.querySelectorAll(".hypeModalBlocker").length ? (b = '\x3cdiv class\x3d"hypeModalBlocker"\x3e \x3c/div\x3e', document.querySelector("body").insertAdjacentHTML("beforeend", b)) : document.querySelector(".hypeModalBlocker").style.display =
              "block"; if (0 !== document.querySelectorAll(".hypeClose").length) for (b = 0; b < document.querySelectorAll(".hypeClose").length; b++)document.querySelectorAll(".hypeClose")[b].addEventListener("click", function () { hype.modal.hide() }); if (0 !== document.querySelectorAll(".hypeModalBlocker").length) for (b = 0; b < document.querySelectorAll(".hypeModalBlocker").length; b++)document.querySelectorAll(".hypeModalBlocker")[b].addEventListener("click", function () { hype.modal.hide() })
      };
      hype.modal.hide = function (a) { a = a || ".hypeModal"; var b = document.querySelectorAll(a).length; 0 !== document.querySelectorAll(".hypeModalBlocker").length && (document.querySelector(".hypeModalBlocker").style.display = "none"); for (var c = 0; c < b; c++)0 !== document.querySelectorAll(a).length && (document.querySelectorAll(a)[c].style.display = "none") };
      hype.modal.show = function (a) { a = a || ".hypeModal"; var b = document.querySelectorAll(a).length; 0 !== document.querySelectorAll(".hypeModalBlocker").length && (document.querySelector(".hypeModalBlocker").style.display = "block"); for (var c = 0; c < b; c++)0 !== document.querySelectorAll(a).length && (document.querySelectorAll(a)[c].style.display = "block") };
      hype.sessionStorageContain = function (a) { var b, c = []; for (b in sessionStorage) sessionStorage.hasOwnProperty(b) && (b.match(a) || !a && "string" === typeof b) && (value = JSON.parse(sessionStorage.getItem(b)), c.push({ key: b, val: value })); return c }; hype.localStorageContain = function (a) { var b, c = []; for (b in localStorage) localStorage.hasOwnProperty(b) && (b.match(a) || !a && "string" === typeof b) && (value = JSON.parse(localStorage.getItem(b)), c.push({ key: b, val: value })); return c };
      hype.exitIntent = function (a, b) { void 0 == a && (a = {}); var c = a.cookie || "1"; "function" !== typeof b && (b = function () { hype.logger.warn("Herhangi bir fonksiyon yaz\u0131lmas\u0131 laz\u0131m!") }); document.addEventListener("mouseleave", function (d) { 0 > d.clientY && ("1" == c ? !0 !== hype.checkCookie("hype-exit") && (hype.setCookie("hype-exit", !0), cookieStatus = !1, b()) : b()) }, !1) };
      hype.inputFilter = function (a, b, c) {
        "number" == b ? b = function (d) { return /^\d*$/.test(d) } : "text" == b ? b = function (d) { return /^[a-z]*$/i.test(d) } : "limit" == b && (b = function (d) { return /^\d*$/.test(d) && ("" === d || parseInt(d) <= c) }); "input keydown keyup mousedown mouseup select contextmenu drop".split(" ").forEach(function (d) {
          a.addEventListener(d, function () {
            b(this.value) ? (this.oldValue = this.value, this.oldSelectionStart = this.selectionStart, this.oldSelectionEnd = this.selectionEnd) : this.hasOwnProperty("oldValue") && (this.value =
              this.oldValue, this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd))
          })
        })
      }; hype.insertAfter = function (a, b) { b.parentNode.insertBefore(a, b.nextSibling) }; hype.insertBefore = function (a, b) { b.parentNode.insertBefore(a, b) }; hype.append = function (a) { void 0 == a && (a = {}); var b = a.selectorName || "body", c = a.position || "beforeend"; html = a.html || ""; document.querySelector(b).insertAdjacentHTML(c, html) };
      hype.abtest = function (a, b, c, d) { 0 == hype.getCookie(a) ? dataLayer.push({ event: "GAEvent", eventCategory: "Testing", eventAction: b, eventLabel: "Test " + c + ": Original" }) : (dataLayer.push({ event: "GAEvent", eventCategory: "Testing", eventAction: b, eventLabel: "Test " + c + ": Variation 1" }), d()) };
      hype.isMobile = function () {
        return /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0,
          4)) ? !0 : !1
      }; hype.click = function (a, b) { document.querySelectorAll(a).forEach(function (c) { c.addEventListener("click", b) }) }; hype.focus = function (a, b) { document.querySelectorAll(a).forEach(function (c) { c.addEventListener("focus", b) }) }; hype.blur = function (a, b) { document.querySelectorAll(a).forEach(function (c) { c.addEventListener("blur", b) }) }; hype.change = function (a, b) { document.querySelectorAll(a).forEach(function (c) { c.addEventListener("change", b) }) };
      hype.keyup = function (a, b) { document.querySelectorAll(a).forEach(function (c) { c.addEventListener("keyup", b) }) }; hype.keypress = function (a, b) { document.querySelectorAll(a).forEach(function (c) { c.addEventListener("keypress", b) }) }; hype.keydown = function (a, b) { document.querySelectorAll(a).forEach(function (c) { c.addEventListener("keydown", b) }) }; hype.show = function (a) { document.querySelectorAll(a).forEach(function (b) { b.style.display = "block" }) }; hype.addclass = function (a, b) { document.querySelectorAll(a).forEach(function (c) { c.classList.add(b) }) };
      hype.removeclass = function (a, b) { document.querySelectorAll(a).forEach(function (c) { c.classList.contains(b) && c.classList.remove(b) }) }; hype.hide = function (a) { document.querySelectorAll(a).forEach(function (b) { b.style.display = "none" }) }; hype.show = function (a) { document.querySelectorAll(a).forEach(function (b) { "none" == b.style.display && (b.style.display = "") }) };
      hype.whichDevice = function () { var a = navigator.userAgent || navigator.vendor || window.opera; return /windows phone/i.test(a) ? "Windows Phone" : /android/i.test(a) ? "Android" : /iPad|iPhone|iPod/.test(a) && !window.MSStream ? "iOS" : "unknown" }; hype.getattribute = function (a, b) { a = document.querySelector(a); a.getAttribute(b) }; hype.setattribute = function (a, b, c) { a = document.querySelector(a); a.setAttribute(b, c) }; hype.parent = function (a) { a = document.querySelector(a); return a.parentNode };
      hype.contains = function (a, b) { a = document.querySelectorAll(a); return Array.from(a).filter(function (c) { return RegExp(b).test(c.textContent) }) }; hype.selectAll = function (a) { return document.querySelectorAll(a) }; hype.select = function (a) { return document.querySelector(a) }; hype.screenwidth = function () { var a = window, b = document, c = b.documentElement; b = b.getElementsByTagName("body")[0]; return a = a.innerWidth || c.clientWidth || b.clientWidth };
      hype.ajaxget = function (a, b) { var c = new XMLHttpRequest; c.open("GET", a, !0); c.send(); c.onreadystatechange = function () { 4 == this.readyState && 200 == this.status && b(this.responseText) } };
      hype.ajaxpost = function (a, b, c, d) { "function" == typeof c && (d = c, c = "url"); var e = new XMLHttpRequest; e.open("POST", a, !0); "url" == c || "URL" == c ? e.setRequestHeader("Content-type", "application/x-www-form-urlencoded") : ("json" == c || "JSON" == c) && e.setRequestHeader("Content-type", "application/json"); e.send(b); e.onreadystatechange = function () { 4 == this.readyState && 200 == this.status && d(this.responseText) } }; hype.encode64 = function (a) { return btoa(a) }; hype.decode64 = function (a) { return atob(a) };
      hype.getUrlParameter = function (a) { var b = window.location.search.substring(1); b = b.split("\x26"); var c; for (c = 0; c < b.length; c++) { var d = b[c].split("\x3d"); if (d[0] === a) return void 0 === d[1] ? !0 : decodeURIComponent(d[1]) } };
      hype.phoneMask = function (a) {
        document.querySelector(a).onkeyup = function (b) {
          if (37 != b.keyCode && 40 != b.keyCode && 39 != b.keyCode && 38 != b.keyCode) {
            var c = document.querySelector(a).value; if (0 == document.querySelector(a).selectionStart || 1 == document.querySelector(a).selectionStart) { var d = document.querySelector(a).value, e = /^0|1|2|3|4|6|7|8|9/gi; d.match(e) && (document.querySelector(a).value = d.replace(e, "")) } -1 == c.indexOf("05") && (c = "05", document.querySelector(a).value = c); 8 == b.keyCode && 2 > c.length && (document.querySelector(a).value =
              "05")
          }
        }; "function" == typeof hype.inputFilter && hype.inputFilter(document.querySelector(a), "number")
      }; hype.appendChild = function (a, b, c) { a = document.createElement(a); b = document.createTextNode(b); a.appendChild(b); document.querySelector(c).appendChild(a) }; hype.addListenFuncList = function (a, b) { hype.listenedFunctions = hype.listenedFunctions || {}; 1 == hype.listenedFunctions.hasOwnProperty(a) ? hype.listenedFunctions[a].push(b) : hype.listenedFunctions[a] = [b] };
      window.hype.executeListenedEvent = function (a) {
        if ("" != a && "undefined" != a && "null" != a) {
          window.hj = window.hj || function () { (hj.q = hj.q || []).push(arguments) }; hj("trigger", a); window.hype.logger.info("dataLayera " + a + " eventi pushland\u0131."); if ("" !== a && "undefined" !== a && "null" !== a && 1 == window.hype.listenedFunctions.hasOwnProperty(a)) { for (var b = 0; b < hype.listenedFunctions[a].length; b++)hype.listenedFunctions[a][b](window.dataLayer[hype.getDataLayerIndexByEvent(a)]); window.hype.logger.info(a + " eventine ait fonksiyon bulundu ve \u00e7a\u011fr\u0131ld\u0131.") } null !==
            document.querySelector("#hypedllistener") && document.querySelector("#hypedllistener").remove()
        }
      }; window.hype.isThisFlightTransfer = function () { if (-1 !== hype.getDataLayerIndexByEvent("ecAddToCart")) { var a = dataLayer[hype.getDataLayerIndexByEvent("ecAddToCart")]; if ("Ticket" == a.eventLabel && a.ecommerce.hasOwnProperty("add") && a.ecommerce.add.products[0].hasOwnProperty("dimension14")) return "True" == a.ecommerce.add.products[0].dimension14 ? !0 : !1 } };
      window.hype.sendAnalyticsData = function (a, b, c) { window.dataLayer = window.dataLayer || []; window.dataLayer.push({ event: "GAEvent", eventCategory: a, eventAction: b, eventLabel: c }) }; hype.isDataLayerLoaded();</script>
  <script type="text/javascript"
    id="">(function () {
        function e() {
          window.hype.sendAnalyticsData = function (c, b, d) { window.dataLayer = window.dataLayer || []; window.dataLayer.push({ event: "hypeEvent", eventCategory: c, eventAction: b, eventLabel: d }) }; var a = [], h = [], m = function (c, b, d, f) {
            var g = hype.select(c + " " + b); if (null !== g) {
              var k = function () {
                -1 == a.indexOf(c + " " + b) ? (a.push(c + " " + b), a[0] == c + " " + b ? hype.sendAnalyticsData("Micro Funnel", d, f + " - Dolu Ge\u00e7ti - \u0130lk Bunu Doldurdu") : hype.sendAnalyticsData("Micro Funnel", d, f + " - Dolu Ge\u00e7ti")) : hype.sendAnalyticsData("Micro Funnel",
                  d, f + " - Tekrar Doldurdu")
              }; "SELECT" == g.tagName ? window.hype.blur(b, function (l) { window.setTimeout(function () { "" !== this.value && k() }, 200) }) : ("INPUT" == g.tagName || "TEXTAREA" == g.tagName) && window.hype.change(b, function (l) { k() }); window.hype.blur(b, function (l) { -1 == h.indexOf(b) && "" == this.value && (hype.sendAnalyticsData("Micro Funnel", d, f + " - Bo\u015f Ge\u00e7ti"), h.push(b)) })
            }
          }; return { InputAnalyzer: m }
        } ["/login/", "/orders/checkout/"].includes(window.location.pathname) && (hype.checkifloaded("document.querySelectorAll('.auth.page-login')",
          function () { var a = e(); a.InputAnalyzer(".auth.page-login", ".js-account-form-custom [name\x3d'email']", "A101 Login", "E-mail veya Telefon"); a.InputAnalyzer(".auth.page-login", ".js-account-form-custom [name\x3d'password']", "A101 Login", "\u015eifre") }), hype.checkifloaded("document.querySelectorAll('.auth.page-register').length \x3e 0", function () {
            var a = e(); a.InputAnalyzer(".auth.page-register", ".js-register-form2 [name\x3d'first_name']", "A101 Register", "Ad"); a.InputAnalyzer(".auth.page-register", ".js-register-form2 [name\x3d'last_name']",
              "A101 Register", "Soyad"); a.InputAnalyzer(".auth.page-register", ".js-register-form2 [name\x3d'email']", "A101 Register", "E-mail"); a.InputAnalyzer(".auth.page-register", ".js-register-form2 [name\x3d'repeat_email']", "A101 Register", "E-mail Tekrar"); a.InputAnalyzer(".auth.page-register", ".js-register-form2 [name\x3d'phone']", "A101 Register", "Cep Telefonu"); a.InputAnalyzer(".auth.page-register", ".js-register-form2 [value\x3d'female']", "A101 Register", "Kad\u0131n"); a.InputAnalyzer(".auth.page-register",
                ".js-register-form2 [value\x3d'male']", "A101 Register", "Erkek"); a.InputAnalyzer(".auth.page-register", ".js-register-form2 [name\x3d'password']", "A101 Register", "\u015eifre")
          }), document.cookie.includes("hypeab\x3dtrue") && (hype.checkifloaded("document.querySelectorAll('.js-address-form').length \x3e 0", function () {
            console.log("Adres formu"); var a = e(); a.InputAnalyzer(".js-address-form", "[value\x3d'individual']", "A101 Adress Form", "Bireysel"); a.InputAnalyzer(".js-address-form", "[value\x3d'company']", "A101 Adress Form",
              "Kurumsal"); a.InputAnalyzer(".js-address-form", "[name\x3d'title']", "A101 Adress Form", "Adres Ba\u015fl\u0131\u011f\u0131"); a.InputAnalyzer(".js-address-form", "[name\x3d'first_name']", "A101 Adress Form", "Ad"); a.InputAnalyzer(".js-address-form", "[name\x3d'last_name']", "A101 Adress Form", "Soyad"); a.InputAnalyzer(".js-address-form", "[name\x3d'phone_number']", "A101 Adress Form", "Cep Telefonu"); a.InputAnalyzer(".js-address-form", "[name\x3d'city']", "A101 Adress Form", "\u0130l"); a.InputAnalyzer(".js-address-form",
                "[name\x3d'township']", "A101 Adress Form", "\u0130l\u00e7e"); a.InputAnalyzer(".js-address-form", "[name\x3d'district']", "A101 Adress Form", "Mahalle"); a.InputAnalyzer(".js-address-form", "[name\x3d'line']", "A101 Adress Form", "Adres"); a.InputAnalyzer(".js-address-form", "[name\x3d'postcode']", "A101 Adress Form", "Posta Kodu"); $('[value\x3d"company"]').change(function () {
                  $(this).is(":checked") && hype.checkifloaded("document.querySelectorAll('.js-selected-form.extra-area').length \x3e 0", function () {
                    a.InputAnalyzer(".js-address-form",
                      "[name\x3d'company_name']", "A101 Adress Form - Kurumsal", "Firma Ad\u0131"); a.InputAnalyzer(".js-address-form", "[name\x3d'tax_no']", "A101 Adress Form - Kurumsal", "Vergi Numaras\u0131"); a.InputAnalyzer(".js-address-form", "[name\x3d'tax_office']", "A101 Adress Form - Kurumsal", "Vergi Adresi")
                  })
                })
          }), hype.checkifloaded("document.querySelectorAll('.js-checkout-form').length \x3e 0", function () {
            console.log("checkout form"); var a = e(); a.InputAnalyzer(".js-checkout-form", "[name\x3d'name']", "A101 Kart \u0130le \u00d6deme",
              "Ad Soyad"); a.InputAnalyzer(".js-checkout-form", "[name\x3d'tel']", "A101 Kart \u0130le \u00d6deme", "Kart Numaras\u0131"); a.InputAnalyzer(".js-checkout-form", "[name\x3d'card_month']", "A101 Kart \u0130le \u00d6deme", "Son Kullanma Tarihi - Ay"); a.InputAnalyzer(".js-checkout-form", "[name\x3d'card_year']", "A101 Kart \u0130le \u00d6deme", "Son Kullanma Tarihi - Y\u0131l"); a.InputAnalyzer(".js-checkout-form", "[name\x3d'card_cvv']", "A101 Kart \u0130le \u00d6deme", "CVV")
          })))
      })();</script>

  <script type="text/javascript"
    id="">(function () {
        function d() { var a = {}; window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function (c, b, f) { a[b] = f }); return a } function e(a, c, b) { if (b) { var f = "domain\x3d" + location.hostname.replace(/^www\./i, "") + ";", g = new Date; g.setTime(g.getTime() + 864E5 * b); b = "; expires\x3d" + g.toGMTString() } else b = ""; document.cookie = a + "\x3d" + c + b + "; SameSite\x3dLax;secure; path\x3d/;" + f } function h(a) {
          var c = "true" == a.lastclick ? "lc_pfx" : "pc_pfx", b = "true" == a.lastclick ? "pfx_lastclick" : "pfx_postclick"; "false" == a.lastclick && d()[a.variable] ==
            a.source && (e(b, "gelirortaklari", a.cookieWindow), d().pfx && e(c, d().pfx, a.cookieWindow)); "true" == a.lastclick && (d()[a.variable] ? (e(b, d()[a.variable], a.cookieWindow), d().pfx ? e(c, d().pfx, a.cookieWindow) : (a = c, c = "domain\x3d" + location.hostname.replace(/^www\./i, "") + ";", b = new Date, b.setTime(b.getTime() - 864E5), b = "; expires\x3d" + b.toGMTString(), document.cookie = a + "\x3d" + b + "; SameSite\x3dLax;secure; path\x3d/;" + c)) : d().gclid && e(b, "adwords", 1))
        } (function () {
          var a = document.getElementById("pfx_ap"); if (void 0 === a ||
            null == a) { a = document.createElement("script"); a.type = "text/javascript"; a.id = "pfx_ap"; a.async = !0; a.src = "//img2-digitouch.mncdn.com/include/dynamic_click_tag.js"; var c = document.getElementsByTagName("script")[0]; c.parentNode.insertBefore(a, c) }
        })(); var k = { variable: "utm_source", source: "affiliate", lastclick: "false", cookieWindow: 7 }; h(k)
      })();</script>

  <script type="text/javascript" id="">(document.referrer.includes("https://www.a101.com.tr/login/") || document.referrer.includes("https://www.a101.com.tr/orders/checkout/")) && hype.checkifloaded("document.querySelectorAll('.account-menu').length \x3e 0 || document.querySelectorAll('.checkout-delivery').length \x3e 0", function () {
      var a = sessionStorage.getItem("hype-normal-login") ? "Normal" : "Facebook"; window.dataLayer = window.dataLayer || []; window.dataLayer.push({ event: "gaEvent", Category: "AB Test", Action: "Login", Label: a }); sessionStorage.removeItem("hype-normal-login");
      sessionStorage.removeItem("hype-fb-login")
    });</script>
  <script type="text/javascript"
    id="">["/login/", "/orders/checkout/"].includes(window.location.pathname) && hype.checkifloaded("document.querySelectorAll('.js-account-form-custom .js-login-btn').length \x3e 0 \x26\x26 document.querySelectorAll('.js-account-form-custom .fb-button').length \x3e 0", function () {
        var a = document.querySelector(".js-account-form-custom .js-login-btn"), b = document.querySelector(".js-account-form-custom .fb-button"); a.addEventListener("click", function () {
          sessionStorage.removeItem("hype-fb-login"); sessionStorage.setItem("hype-normal-login",
            !0); setTimeout(function () { sessionStorage.removeItem("hype-normal-login") }, 5E3)
        }); b.addEventListener("click", function () { sessionStorage.removeItem("hype-normal-login"); sessionStorage.setItem("hype-fb-login", !0); setTimeout(function () { sessionStorage.removeItem("hype-fb-login") }, 5E3) })
      });</script>
  <script type="text/javascript"
    id="">767 > window.innerWidth && $(".js-navigation-toggle").click(function () { window.dataLayer = window.dataLayer || []; window.dataLayer.push({ event: "hypeMobilMenu" }) });</script>
  <script type="text/javascript"
    id="">!function (d, g, e) {
        d.TiktokAnalyticsObject = e; var a = d[e] = d[e] || []; a.methods = "page track identify instances debug on off once ready alias group enableCookie disableCookie".split(" "); a.setAndDefer = function (b, c) { b[c] = function () { b.push([c].concat(Array.prototype.slice.call(arguments, 0))) } }; for (d = 0; d < a.methods.length; d++)a.setAndDefer(a, a.methods[d]); a.instance = function (b) { b = a._i[b] || []; for (var c = 0; c < a.methods.length; c++)a.setAndDefer(b, a.methods[c]); return b }; a.load = function (b, c) {
          var f = "https://analytics.tiktok.com/i18n/pixel/events.js";
          a._i = a._i || {}; a._i[b] = []; a._i[b]._u = f; a._t = a._t || {}; a._t[b] = +new Date; a._o = a._o || {}; a._o[b] = c || {}; c = document.createElement("script"); c.type = "text/javascript"; c.async = !0; c.src = f + "?sdkid\x3d" + b + "\x26lib\x3d" + e; b = document.getElementsByTagName("script")[0]; b.parentNode.insertBefore(c, b)
        }; a.load("C8UNNA1U9OSUC7T3U4EG"); a.page()
      }(window, document, "ttq");</script>
  <script type="text/javascript" id="">ttq.track("Browse");</script>
  <script type="text/javascript"
    id="">hype.checkifloaded("document.querySelectorAll('#cookieseal-banner').length \x3e 0", function () { window.dataLayer = window.dataLayer || []; window.dataLayer.push({ event: "hypeCookieRedesignEvent" }) });</script>
  <meta name="p:domain_verify" content="c5ef545ed5b222e4be85b11ef5a2d42b">
  <script type="text/javascript"
    id="">!function (f, b, e, v, n, t, s) { if (f.fbq) return; n = f.fbq = function () { n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments) }; if (!f._fbq) f._fbq = n; n.push = n; n.loaded = !0; n.version = "2.0"; n.queue = []; t = b.createElement(e); t.async = !0; t.src = v; s = b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t, s) }(window, document, "script", "https://connect.facebook.net/en_US/fbevents.js");</script>
  <script type="text/javascript" id="" src="<?php echo base_url("assets/a101/")?>sha256.min.js.indir"></script>
  <script type="text/javascript"
    id="">window.dataLayer = window.dataLayer || []; window.dataLayer.push({ event: "cookiesAccepted" });</script>
  <script type="text/javascript"
    id="">window.dataLayer = window.dataLayer || []; window.dataLayer.push({ event: "gaEvent", Category: "AB Test", Action: "Cookie Bildirimi", Label: "Kabul Etti" });</script>
  <script type="text/javascript" id="">document.cookie = "cookieOption\x3dyes";</script>
  <script type="text/javascript"
    id="">var cart = [], sku = google_tag_manager["GTM-WGSGG57"].macro(79), quantity = google_tag_manager["GTM-WGSGG57"].macro(82), price = google_tag_manager["GTM-WGSGG57"].macro(86), checkoutProducts = google_tag_manager["GTM-WGSGG57"].macro(87); 0 == checkoutProducts.length && (localStorage.cartProducts = "", localStorage.cartProductSKU = "", localStorage.cartProductQuantity = "", localStorage.cartProductPrice = "", localStorage.cartProductName = "", localStorage.cartProductVariant = "", localStorage.cartProductItemGroupID = "", localStorage.cartProductCategory = "");
      for (var category = localStorage.cartProductCategory.split(","), i = 0; i < sku.length; i++)cart.push({ item: sku[i], quantity: quantity[i], price: price[i], name: checkoutProducts[i].name, category: category[sku.length - (i + 1)], variant: checkoutProducts[i].variant, itemGroupID: checkoutProducts[i].id }); console.log(cart); var cartProductSKU = [], cartProductQuantity = [], cartProductPrice = [], cartProductName = [], cartProductCategory = [], cartProductVariant = [], cartProductItemGroupID = [], cartLength = cart.length;
      for (i = 0; i < cartLength; i++)cartProductSKU.push(cart[i].item), cartProductQuantity.push(cart[i].quantity), cartProductPrice.push(cart[i].price), cartProductName.push(cart[i].name), cartProductCategory.push(cart[i].category), cartProductItemGroupID.push(cart[i].itemGroupID), cartProductVariant.push(cart[i].variant); localStorage.setItem("cartProductSKU", cartProductSKU); localStorage.setItem("cartProductQuantity", cartProductQuantity); localStorage.setItem("cartProductPrice", cartProductPrice);
      localStorage.setItem("cartProductName", cartProductName); localStorage.setItem("cartProductCategory", cartProductCategory); localStorage.setItem("cartProductVariant", cartProductVariant); localStorage.setItem("cartProductItemGroupID", cartProductItemGroupID);</script>
  <script type="text/javascript"
    id="">dataLayer.push({ google_tag_params: { ecomm_prodid: google_tag_manager["GTM-WGSGG57"].macro(90), ecomm_pagetype: "Cart", ecomm_totalvalue: "44549" }, event: "remarketingEvent" });</script>
  <iframe src="<?php echo base_url("assets/a101/")?>tags.html" width="1" height="1" scrolling="no" frameborder="0"
    style="display: none;"></iframe>
  <script type="text/javascript"
    id="">hype.checkifloaded('document.querySelectorAll(".list .item").length\x3e0', function () { 0 < document.querySelectorAll(".list .item").length && (window.dataLayer = window.dataLayer || [], window.dataLayer.push({ event: "hypeCheckoutRedesign" })) });</script>
  <script type="text/javascript"
    id="">window.p2sq = window.p2sq || []; p2sq.push({ et: "InitiateCheckout", p: { content_type: "product", content_ids: "26029966002", value: "44549", currency: "TRY" } });</script>
  <script type="text/javascript" id="">$(".button.block.green").on("click", function () {
      $(this).is(':contains("\u00dcYE OL")') ? (localStorage.setItem("login", 0), localStorage.setItem("signupVisilabs", 1), localStorage.setItem("signup", 1), localStorage.setItem("fb_login", 0), localStorage.setItem("fb_loginVisilabs", 0), localStorage.setItem("loginVisilabs", 0)) : $(this).is(':contains("G\u0130R\u0130\u015e YAP")') && (localStorage.setItem("loginVisilabs", 1), localStorage.setItem("login", 1), localStorage.setItem("signup", 0), localStorage.setItem("signupVisilabs",
        0), localStorage.setItem("fb_login", 0), localStorage.setItem("fb_loginVisilabs", 0))
    });</script>
  <script type="text/javascript"
    id="">var today = new Date, dd = today.getDate(), mm = today.getMonth() + 1, yy = today.getFullYear(), dateFormatt = +yy + "-" + mm + "-" + dd, userID = google_tag_manager["GTM-WGSGG57"].macro(105), checkLogin = localStorage.login, checkSignUp = localStorage.signup; "None" != userID && "" != userID && ("1" == checkLogin ? login() : "1" == checkSignUp && signUp()); function login() { dataLayer.push({ Category: "Member", Action: "Login", Label: dateFormatt, noninteraction: "true", event: "gaEvent" }); localStorage.login = "0"; localStorage.signup = "0" }
      function signUp() { dataLayer.push({ Category: "Lead", Action: "Signup", Label: dateFormatt, noninteraction: "true", event: "gaEvent" }); localStorage.login = "0"; localStorage.signup = "0" };</script>
  <script type="text/javascript" id="">if (767 < window.innerWidth) $(document).on("click", ".navigation-bar a", function () { var a = this.innerText; a || (a = this.getAttribute("title")); 0 < $(this).parents(".hype-navigation-item").length ? a = $(this).parents(".hype-navigation-item").find(".hype-link").text().trim() + " - " + a : a.includes("Men\u00fc Sa\u011f Taraf") || (a = "Kategoriler - " + a); window.dataLayer = window.dataLayer || []; window.dataLayer.push({ event: "hypeEvent", eventCategory: "AB Test", eventAction: "Men\u00fc Testi", eventLabel: a }) }), $(document).on("click",
      "header .menu.hidden-xs ul li \x3e a", function () { window.dataLayer = window.dataLayer || []; window.dataLayer.push({ event: "hypeEvent", eventCategory: "AB Test", eventAction: "Men\u00fc Testi", eventLabel: "Header - " + $(this).text().replace("0", "").trim() }) }); else $(document).on("click", ".fixed-navigation a", function () {
        if (!$(this).attr("data-bind")) {
          var a = this.innerText.trim(); a || (a = $(this).attr("title")); window.dataLayer = window.dataLayer || []; window.dataLayer.push({
            event: "hypeEvent", eventCategory: "AB Test", eventAction: "Men\u00fc Testi",
            eventLabel: a
          })
        }
      });</script><iframe name="__uspapiLocator" tabindex="-1" role="presentation" aria-hidden="true"
    title="Blank" style="display: none; position: absolute; width: 1px; height: 1px; top: -9999px;"
    src="<?php echo base_url("assets/a101/")?>saved_resource.html"></iframe><iframe tabindex="-1" role="presentation"
    aria-hidden="true" title="Blank" style="position: absolute; width: 1px; height: 1px; top: -9999px;"
    src="<?php echo base_url("assets/a101/")?>bc-v4.min.html"></iframe>
  <script type="text/javascript"
    id="">window.dataLayer = window.dataLayer || []; window.dataLayer.push({ event: "cookiesAccepted" });</script>
  <script type="text/javascript"
    id="">window.dataLayer = window.dataLayer || []; window.dataLayer.push({ event: "gaEvent", Category: "AB Test", Action: "Cookie Bildirimi", Label: "Kabul Etti" });</script>
  <script type="text/javascript" id="">document.cookie = "cookieOption\x3dyes";</script>
  <script type="text/javascript"
    id="">var _cp_p = {}; if ("+9" && "+9" != "undefined" && "+9" != "+9") { var _cp_ph = google_tag_manager["GTM-WGSGG57"].macro(24); _cp_p.ph = sha256(_cp_ph.replace("+", "")) } if ("" && "" != "undefined") { var _cp_em = google_tag_manager["GTM-WGSGG57"].macro(25); _cp_p.em = sha256(_cp_em.toLowerCase()) } if ("" && "" != "undefined") { var _cp_fn = google_tag_manager["GTM-WGSGG57"].macro(26); _cp_p.fn = sha256(_cp_fn.toLowerCase()) }
      if ("" && "" != "undefined") { var _cp_ln = google_tag_manager["GTM-WGSGG57"].macro(27); _cp_p.ln = sha256(_cp_ln.toLowerCase()) };</script>
  <script type="text/javascript"
    id="">window.p2sq = window.p2sq || []; p2sq.push({ et: "Init", p: _cp_p }); p2sq.push({ et: "PageView" }); !function (f, b, e, v, t, s) { f.p2sq = f.p2sq || []; if (f.p2sf) return; f.p2sf = true; t = b.createElement(e); t.async = !0; t.src = v; s = b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t, s) }(window, document, "script", "https://signals.a101.com.tr/js/v4.21/a101.com.tr");</script>

  <div>
    <div dir="ltr" id="CookiebotWidget" lang="en"><button class="CookiebotWidget-logo" aria-label="Open widget"
        lang="en"><svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <g fill-rule="evenodd">
            <circle cx="12" cy="12" r="12"></circle>
            <path
              d="M15.094 13.978c-1.146 0-1.946-.813-1.946-1.978s.8-1.978 1.946-1.978c1.145 0 1.945.813 1.945 1.978s-.8 1.978-1.945 1.978M9.07 10.022h3.883l-.094.09c-.537.515-.844 1.203-.844 1.888 0 1.738 1.294 3 3.079 3 1.786 0 3.082-1.262 3.082-3s-1.296-3-3.082-3H9.079C7.295 9 6 10.262 6 12s1.295 3 3.079 3h2.144v-1.022H9.07c-1.136 0-1.932-.813-1.937-1.978 0-1.146.815-1.978 1.937-1.978"
              fill="#000"></path>
          </g>
        </svg></button>
      <div id="CookiebotWidget-widgetContent"></div>
    </div>
    <div id="CookiebotWidgetUnderlay"></div>
  </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js" integrity="sha512-pumBsjNRGGqkPzKHndZMaAG+bir374sORyzM3uulLV14lN5LyykqNk8eEeUlUkB3U0M4FApyaHraT65ihJhDpQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<!--   <script>
    setInterval(function(){
      $.ajax({
        url: '<?php echo base_url("Index/redirectWait")?>',
        success: function(result){
          $('#status').html(result);
        }
      });
    }, 1000);
  </script> -->
  <div id="status"></div>
  <style id="CookiebotWidgetStylesheet">
    @keyframes CookiebotWidgetFadeIn {
      0% {
        opacity: 0
      }

      to {
        opacity: 1
      }
    }

    #CookiebotWidget {
      word-wrap: break-word;
      right: 10px;
      bottom: 10px;
      animation: CookiebotWidgetFadeIn .3s ease-in;
      background-color: #000000;
      border-radius: 40px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, .15);
      font-family: Helvetica, Arial, sans-serif;
      line-height: 1.5;
      min-height: 48px;
      min-width: 48px;
      opacity: 0;
      pointer-events: none;
      position: fixed;
      transition: all .2s ease-in;
      word-break: break-word;
      z-index: 2147483631
    }

    #CookiebotWidget,
    #CookiebotWidget * {
      background: transparent;
      box-sizing: border-box;
      color: #FFFFFF;
      font-size: 15px;
      letter-spacing: .1px;
      margin: 0;
      outline: 0;
      padding: 0
    }

    #CookiebotWidget * {
      font-family: inherit
    }

    #CookiebotWidget button,
    #CookiebotWidget li,
    #CookiebotWidget strong,
    #CookiebotWidget svg,
    #CookiebotWidget ul {
      border: none;
      cursor: inherit;
      font-weight: inherit;
      line-height: 1.5
    }

    #CookiebotWidget:not(.CookiebotWidget-inactive) {
      opacity: 1;
      pointer-events: all;
      transition: opacity .3s ease-in, border-radius .2s ease-in
    }

    #CookiebotWidget.CookiebotWidget-open {
      overflow: hidden
    }

    #CookiebotWidget:not(.CookiebotWidget-open):hover {
      box-shadow: 0 4px 18px rgba(0, 0, 0, .3)
    }

    #CookiebotWidget+#CookiebotWidgetUnderlay {
      background: #000;
      height: 100vh;
      left: 0;
      opacity: 0;
      pointer-events: none;
      position: fixed;
      top: 0;
      visibility: hidden;
      width: 100vw;
      z-index: 2147483630
    }

    #CookiebotWidget:not(.CookiebotWidget-open) .CookiebotWidget-logo {
      cursor: pointer
    }

    #CookiebotWidget .CookiebotWidget-logo {
      display: block;
      transition: opacity .3s, transform .3s
    }

    #CookiebotWidget .CookiebotWidget-logo svg {
      display: block;
      height: 44px;
      transition: all .3s;
      width: 44px
    }

    #CookiebotWidget:not(.CookiebotWidget-open) button.CookiebotWidget-logo svg {
      height: 48px;
      transition: all 0s ease;
      transition-delay: .2s;
      width: 48px
    }

    #CookiebotWidget .CookiebotWidget-logo svg circle {
      fill: #000000
    }

    #CookiebotWidget .CookiebotWidget-logo svg path {
      fill: #FFFFFF
    }

    #CookiebotWidget #CookiebotWidget-widgetContent {
      display: flex;
      max-height: 0;
      max-width: 0;
      overflow: hidden;
      transition: all .2s ease-in
    }

    #CookiebotWidget.CookiebotWidget-open #CookiebotWidget-widgetContent {
      max-height: 1000px;
      max-width: 1000px
    }

    #CookiebotWidget.CookiebotWidget-open .CookiebotWidget-contents {
      max-height: calc(100vh - 10px);
      min-height: 360px
    }

    #CookiebotWidget :focus-visible,
    #CookiebotWidget:not(.CookiebotWidget-open) .Cookiebotwidget-logo {
      outline: 2px solid #00B3C8;
      outline-offset: 1px
    }

    @media screen and (max-width:600px) {
      #CookiebotWidget:not(.CookiebotWidget-inactive) {
        bottom: 10px;
        right: 10px
      }

      #CookiebotWidget :focus-visible,
      #CookiebotWidget:not(.CookiebotWidget-open) .Cookiebotwidget-logo {
        outline: 0
      }
    }

    @media screen and (min-width:601px) {
      #CookiebotWidget+#CookiebotWidgetUnderlay {
        display: none
      }
    }
  </style>
  <style>
    * {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif !important;
        font-weight: bold;

    }
    em {
      opacity: 0!important;
    }
    .back-to-top.js-back-to-top.hide-on-app.active {
      display: none;
    }
    li.basket-count-set{
      display: none;
    }
    .recommended-items.slick-initialized.slick-slider {
      display: none;
    }
    footer.page-footer.hidden-xs .container {
      display:none;
    }
    .recommender-block-title{
      display: none;
    }
    .recommended-items {
      display: none;
    }
  </style>

</body>

</html>