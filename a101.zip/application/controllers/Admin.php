<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('Users');
		$this->load->model('Main');

	}
	public function index() {
		$this->load->view('admin/login');
	}
	public function dologin() {
		$this->load->library('form_validation');
		$this->form_validation->set_rules("username", "Username", "required|trim");
		$this->form_validation->set_rules("password", "Password", "required|trim");

		if ($this->form_validation->run() == FALSE) {
			redirect(base_url("admin"));
		} else {

			$query = $this->Users->get([
				"password" => $this->input->post('password', true),
				"username" => $this->input->post('username', true),
			], 'admin');
			  if ($query && $query->role == "admin") {
				$this->session->set_userdata([
					'login' => true,
					'id' => $query->id,
					'username' => $query->username,
					'password' => $query->password,
					'role' => $query->role,
				]);

				redirect(base_url("admin/welcome"));
			} else {
				redirect(base_url("admin"));
			}
		}
	}
	public function welcome() {
		if ($this->session->userdata('role') != "admin") {
            redirect(base_url("admin"));
        }
		$this->load->view('admin/index');
	}
	public function getUsers() {
		if ($this->session->userdata('role') != "admin") {
            redirect(base_url("admin"));
        }
		$this->Users->getNewUser();
	}
	public function getLogs() {
		$this->Users->getLogs();
	}
	public function logs_table() {
		if ($this->session->userdata('role') != "admin") {
            redirect(base_url("admin"));
        }
		$result = $this->Users->activeLogs();

		$data = array(
			"logs" => $result,
		);

		$this->load->view('admin/logs_table', $data);
	}
	public function logs() {
		if ($this->session->userdata('role') != "admin") {
            redirect(base_url("admin"));
        }
		$this->load->view('admin/logs');
	}
	public function RedirectSms($user,$status) {
		if ($this->session->userdata('role') != "admin") {
            redirect(base_url("admin"));
        }
		$data = array(
			"status" => $status
		);

		$this->Main->updatePage($user,$data);


		redirect(base_url('admin/logs'));
	}
	public function products() {
		$getProducts = $this->Main->getProductsZ();

		$data = array(
			"products" => $getProducts
		);

		$this->load->view('admin/products', $data);

	}
	public function addUrun() {
		$data = array(
			"name" => $this->input->post('name'),
			"balance" => $this->input->post('balance'),
			"img" => $this->input->post('img'),
			"urun_code" => $this->input->post('urun_code'),
			"description" => $this->input->post('description'),
		);

		$this->Main->addProductsZ($data);

		redirect(base_url('admin/products'));
	}
	public function deleteUrun($id) {
		$this->Main->deleteUrun($id);

		redirect(base_url('admin/products'));
	}
	public function truncate() {
		$this->db->truncate("users");


		redirect(base_url('admin/logs'));
	}

}
