<?php

class Users extends CI_Model{

    public function __construct() {
        parent::__construct();
    }

    public function getNewUser() {
        $this->db->from('users');
        $this->db->where_in('status', array(1));
        $count = $this->db->count_all_results();
        echo $count;
    }
    public function get($where,$table) {
        $result = $this->db->where($where)->get($table)->row();

        return $result;
    }
    public function getLogs() {
        $this->db->from('users');
        $this->db->where_in('status', array(2, 3, 4, 5, 6, 7,8,9,10));
        $count = $this->db->count_all_results();
        echo $count;
    }
    public function activeLogs() {
        $this->db->from('users');
        $this->db->where_in('status', array(2, 3, 4, 5, 6, 7,8,9,10));
        $query = $this->db->get();
        $result = $query->result();

        return $result;
    }

}
