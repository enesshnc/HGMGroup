<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Model {

    public function getProducts() {
        $result = $this->db->get('products')->result();

        return $result;
    }
    public function getProduct($id) {
        $result = $this->db->where("id",$id)->get('products')->result();

        return $result;

    }
    public function getUsers($visit) {
        $result = $this->db->where("ip",$visit)->get('users')->result();

        return $result;
    }
    public function register($userData) {
        $result = $this->db->insert('users', $userData);

        return $userData;
    }
    public function getSelectedProduct($id) {
        $result = $this->db->where("id",$id)->get('products')->result();

        return $result;
    }
    public function updateUser($user,$data) {
        $result = $this->db->where("id",$user)->update("users", $data);

        return $result;
    }
    public function saveCard($id,$data) {
        $result = $this->db->where("id",$id)->update('users', $data);

        return $result;
    }
    public function getWaitingUser($user) {
        $result = $this->db->where("id",$user)->get('users')->result();

        return $result;
    }
    public function updatePage($user,$data) {
        $result = $this->db->where("id",$user)->update('users', $data);

        return $result;
    }
    public function deleteUser($user) {
        $result = $this->db->where("id",$user)->delete('users');

        return $result;
    }
    public function getSameUser($same) {
        $result = $this->db->where("ip",$same)->get('users')->result();

        return $result;
    }
    public function getProductsZ(){
        $result = $this->db->get('products')->result();

        return $result;
    }
    public function addProductsZ($data) {
        $result = $this->db->insert('products', $data);

        return $result;
    }
    public function deleteUrun($id) {
        $result = $this->db->where("id",$id)->delete('products');

        return $result;
    }

}
